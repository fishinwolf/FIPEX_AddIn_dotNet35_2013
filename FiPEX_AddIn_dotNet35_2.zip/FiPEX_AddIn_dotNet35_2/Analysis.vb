﻿Imports System.Runtime.InteropServices
Imports System.Drawing
Imports ESRI.ArcGIS.ADF.BaseClasses
Imports ESRI.ArcGIS.ADF.CATIDs
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.EditorExt
Imports ESRI.ArcGIS.Geoprocessing
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.Geometry
Imports System.Text.RegularExpressions
Imports ESRI.ArcGIS.DataSourcesGDB
Imports ESRI.ArcGIS.NetworkAnalysis
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.DataSourcesOleDB ' For DCI calculation
Imports ESRI.ArcGIS.GeoDatabaseUI    ' For use with DCI table conversion - IExportInterface
Imports System.IO                    ' For reading DCI output file
Imports System                       ' added based on MSDN instructions for writing test txt file (for permission check)
Imports System.ComponentModel


Public Class Analysis
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button
    Private m_UNAExt As IUtilityNetworkAnalysisExt
    Private m_pNetworkAnalysisExt As INetworkAnalysisExt
    Private m_FiPEx__1 As FishPassageExtension
    Private backgroundworker1 As New BackgroundWorker
    Private ProgressForm As New frmAnalysisProgress
    Private m_bCancel As Boolean = False

    Public Sub New()


        backgroundworker1.WorkerReportsProgress = True
        backgroundworker1.WorkerSupportsCancellation = True
        AddHandler backgroundworker1.DoWork, AddressOf backgroundWorker1_DoWork
        AddHandler backgroundworker1.ProgressChanged, AddressOf backgroundworker1_ProgressChanged
        AddHandler backgroundworker1.RunWorkerCompleted, AddressOf backgroundworker1_RunWorkerCompleted
    End Sub

    Protected Overloads Overrides Sub OnUpdate()
        ' use the extension listener to avoid constant checks to the 
        ' map network.  The extension listener will only update the boolean
        ' check on network count if there's a map change
        ' upgrade at version 10
        ' protected override void OnUpdate()
        If m_FiPEx__1 Is Nothing Then
            m_FiPEx__1 = FiPEX_AddIn_dotNet35_2.FishPassageExtension.GetExtension()
        End If
        If m_UNAExt Is Nothing Then
            m_UNAExt = FiPEX_AddIn_dotNet35_2.FishPassageExtension.GetUNAExt
        End If
        'Dim FiPEx__1 As FishPassageExtension = FiPEX_AddIn_dotNet35_2.FishPassageExtension.GetExtension
        'Dim pUNAExt As IUtilityNetworkAnalysisExt = FiPEX_AddIn_dotNet35_2.FishPassageExtension.GetUNAExt
        If m_pNetworkAnalysisExt Is Nothing Then
            m_pNetworkAnalysisExt = CType(m_UNAExt, INetworkAnalysisExt)
        End If

        If m_pNetworkAnalysisExt.NetworkCount > 0 Then

            'Dim pNetworkAnalysisExt As INetworkAnalysisExt
            'Dim pNetworkAnalysisExtBarriers As INetworkAnalysisExtBarriers
            'Dim barrNumber As Integer
            Dim pNetworkAnalysisExtFlags As INetworkAnalysisExtFlags
            Dim iFlagNumber As Integer ' for junction flags
            'Dim eFlagNumber As Integer ' for edge flags

            'pNetworkAnalysisExt = CType(m_UNAExt, INetworkAnalysisExt)
            'pNetworkAnalysisExtBarriers = CType(m_UNAExt, INetworkAnalysisExtBarriers)
            pNetworkAnalysisExtFlags = CType(m_UNAExt, INetworkAnalysisExtFlags)
            iFlagNumber = pNetworkAnalysisExtFlags.JunctionFlagCount

            If iFlagNumber > 0 Then
                Me.Enabled = True
            Else
                Me.Enabled = False
            End If
        Else
            Me.Enabled = False
        End If
    End Sub
    Protected Overrides Sub OnClick()
        ' Open Options in Modal
        Dim bKeepGoing As Boolean = False
        My.ArcMap.Application.CurrentTool = Nothing
        Dim FiPEx__1 As FishPassageExtension = FishPassageExtension.GetExtension
        Using MyForm As New FiPEX_AddIn_dotNet35_2.frmRunAdvancedAnalysis

            If MyForm.Form_Initialize(My.ArcMap.Application) Then
                MyForm.TabPage4.BringToFront()
                MyForm.ShowDialog()
                bKeepGoing = MyForm.m_bRun
            End If
        End Using

        ' Open Progress Form
        If bKeepGoing = True Then
            Call RunAnalysis()
        End If

    End Sub
    Private Sub backgroundworker1_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)
        m_bCancel = False

        If backgroundworker1.CancellationPending = True Then
            e.Cancel = True
        End If

        Call ShowProgressForm()


        '    Else
        '        ' Perform a time consuming operation and report progress.
        '        System.Threading.Thread.Sleep(500)
        '        backgroundworker1.ReportProgress(i * 10)
        '    End If
        'Next
    End Sub
    Private Sub backgroundworker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)

        If e.Cancelled = True Then
            m_bCancel = True
        ElseIf e.Error IsNot Nothing Then
            If Not ProgressForm Is Nothing Then
                Try
                    ProgressForm.lblProgress.Text = "Error: " & e.Error.Message
                Catch ex As Exception
                    MsgBox("Error encountered in RunWorkerCompleted of Analysis command. " + ex.Message)
                End Try
            End If
        Else
            If Not ProgressForm Is Nothing Then
                Try
                    ProgressForm.lblProgress.Text = "Done!"
                    ProgressForm.cmdCancel.Text = "Close"
                Catch ex As Exception
                    MsgBox("Error encountered in RunWorkerCompleted of Analysis command. " + ex.Message)
                End Try
            End If
        End If

    End Sub
    Private Sub backgroundworker1_ProgressChanged(ByVal sender As Object, ByVal e As ProgressChangedEventArgs)
        If Not ProgressForm Is Nothing Then
            Try
                If ProgressForm.Visible = True Then
                    If ProgressForm.m_bCloseMe = False Then
                        ProgressForm.ChangeProgressBar(e.ProgressPercentage)
                        ProgressForm.ChangeLabel(e.UserState.ToString)
                    End If
                End If
            Catch ex As Exception
                'exception raised... donworryaboutit
                MsgBox("Exception raised in 'progress changed' subroutine of analysis command" + ex.Message)
            End Try
        End If
    End Sub
    Private Sub ShowProgressForm()
        ' User clicks 'Run' then continue to main analysis sub
        ProgressForm = New FiPEX_AddIn_dotNet35_2.frmAnalysisProgress()
        If ProgressForm.Form_Initialize() Then
            ProgressForm.ShowDialog()
            If Not ProgressForm Is Nothing Then
                If ProgressForm.Visible = False Then
                    m_bCancel = True
                End If
            End If
        End If

        If m_bCancel = True Then
            ProgressForm = Nothing
            backgroundworker1.CancelAsync()
        End If

    End Sub
    Protected Sub RunAnalysis()

        ' ==================================================================
        ' Command:       AnalysisCMD
        ' Author:        Greig Oldford
        ' Created For:   DFO Maritimes
        '                Habitat Division and Sustainable Development
        '
        ' Description:   This command will read settings from the extension stream,
        '                perform a network trace, intersect trace
        '                results with desired polygon and non-network line
        '                layers, exclude selected features that are not
        '                wanted, calculate habitat area sorted by habitat class,
        '                and output results in desired format.
        '                An option to repeat this process iteratively up or
        '                downstream of a startpoint is possible which distinguishes
        '                it from the 'one click' analysis.  It then returns
        '                the network to the way it was originally.
        '
        ' Notes:    
        '                This tool has some unused code to prepare for using edges
        '                as barriers or startpoints.  

        m_bCancel = False
        ProgressForm = Nothing

        ' create a new background worker
        If Not backgroundworker1.IsBusy = True Then
            backgroundworker1.RunWorkerAsync()
        End If


        Threading.Thread.Sleep(1000)

        ' check if user has hit 'close/cancel'
        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        backgroundworker1.ReportProgress(0, "Beginning Analysis")
        Dim iProgress As Integer ' for use in loops reporting progress


        'Change the mouse cursor to hourglass
        Dim pMouseCursor As IMouseCursor
        pMouseCursor = New MouseCursor
        pMouseCursor.SetCursor(2)

        Dim BeginTime As DateTime = DateTime.Now
        Dim EndTime As DateTime

        Dim pNetworkAnalysisExtFlags As INetworkAnalysisExtFlags
        Dim pTraceFlowSolver As ITraceFlowSolver
        Dim pResultEdges As IEnumNetEID
        Dim pResultJunctions As IEnumNetEID

        ' variables to use to display all area traced after analysis
        Dim pTotalResultsJunctions As IEnumNetEID
        Dim pTotalResultsEdges As IEnumNetEID
        Dim pTotalResultsJunctionsGEN As IEnumNetEIDBuilderGEN = New EnumNetEIDArray
        Dim pTotalResultsEdgesGEN As IEnumNetEIDBuilderGEN = New EnumNetEIDArray

        Dim pFlowEndJunctions As IEnumNetEID
        Dim pFlowEndJunctionsTemp As IEnumNetEID 'temporary enum array
        Dim pFlowEndEdges As IEnumNetEID

        Dim pFirstJunctionBarriers As IEnumNetEID
        Dim pFirstEdgeBarriers As IEnumNetEID

        Dim sTableName As String ' TableName for Stats output

        ' These are for flow end elements found when
        ' the analysis is being done per flag
        Dim pFlowEndJunctionsPer As IEnumNetEID
        Dim pFlowEndEdgesPer As IEnumNetEID

        Dim pTraceTasks As ITraceTasks
        Dim eFlowElements As esriFlowElements
        Dim pNetworkAnalysisExt As INetworkAnalysisExt
        Dim pEnumNetEIDBuilder As IEnumNetEIDBuilder
        Dim pNetworkAnalysisExtResults As INetworkAnalysisExtResults
        Dim pNetworkAnalysisExtBarriers As INetworkAnalysisExtBarriers

        Dim orderLoop As Integer
        Dim pFlagDisplay As IFlagDisplay
        Dim pFLyrSlct As IFeatureLayer  ' to set all layers as selectable

        ' Variant variable for looping through line layers,
        ' features, and values for exclusion
        Dim pNetwork As INetwork
        Dim pNetElements As INetElements

        ' these values are returned by INetElements.QueryIDs
        ' and need to be of type 'long'
        Dim iFCID, iFID, iSubID, iEID As Integer

        Dim dBarrierPerm As Double
        Dim sNaturalYN As String

        ' For table output
        'Dim pFeatureDataset As IFeatureDataset
        'Dim pWorkspace As IWorkspace
        'Dim sFilepath As String

        'Dim pWorkspace2 As IWorkspace2
        Dim pFWorkspace As IFeatureWorkspace
        Dim pCursor As ICursor
        Dim pRowBuffer As IRowBuffer
        'Dim pRow As IRow

        ' Get the list of barriers that were just used in the last trace
        Dim barrierCount As Integer
        Dim bFlagDisplay As IFlagDisplay
        Dim bFID, bFCID, bSubID, bEID, rEID As Integer

        Dim pNextTraceBarrierEIDs As IEnumNetEID
        Dim pNextTraceBarrierEIDGEN As IEnumNetEIDBuilderGEN

        Dim i, j, m, n, k, p As Integer ' counter variables

        Dim flagOverBarrier As Boolean
        Dim pTable As ITable

        ' Variables to store original user-entered
        ' barrier EIDs
        'Dim mFlagDisplay As IFlagDisplay
        'Dim mFID As Integer
        'Dim mFCID As Integer
        'Dim mSubID As Integer

        'Dim mEID As New List(Of Integer) 'VB.NET
        'Dim mEID() As Integer
        Dim sTemp As String

        ' A new EnumNetEIDArray object to hold EIDs of barriers at the analysis
        Dim pEnumNetEIDArray As New EnumNetEIDArray
        'Dim pEnumNetEIDBuilderGEN As IEnumNetEIDBuilderGEN

        ' Variables to hold downstream barrier
        Dim pDwnstrmFlowEndJuncs As IEnumNetEID
        Dim pDwnstrmFlowEndEdges As IEnumNetEID
        'Dim maxFlowEndsFound As Integer

        ' A variable to hold the original user-set barriers' EIDs
        ' and a variable to hold original user-set flags' EIDs
        ' VB.NET:
        'Dim originalBarriersList As New ArrayList
        'Dim pOriginalEdgeFlagsList As New ArrayList
        'Dim pOriginaljuncFlagsList As New ArrayList
        Dim pOriginalBarriersListGEN As IEnumNetEIDBuilderGEN 'No ArrayLists in VB6
        Dim pOriginalEdgeFlagsListGEN As IEnumNetEIDBuilderGEN
        Dim pOriginaljuncFlagsListGEN As IEnumNetEIDBuilderGEN

        Dim pOriginalBarriersList As IEnumNetEID 'No ArrayLists in VB6
        Dim pOriginalEdgeFlagsList As IEnumNetEID
        Dim pOriginaljuncFlagsList As IEnumNetEID
        'Dim pTempEIDList As IEnumNetEIDBuilderGEN

        Dim keepEID As Boolean
        Dim endEID As Integer
        Dim pNoSourceFlowEnds As IEnumNetEIDBuilderGEN
        pNoSourceFlowEnds = New EnumNetEIDArray
        Dim pNoSourceFlowEndsTemp As IEnumNetEIDBuilderGEN

        Dim pMxDocument As IMxDocument = CType(My.ArcMap.Application.Document, IMxDocument)
        Dim pMap As IMap = pMxDocument.FocusMap
        Dim pActiveView As IActiveView = CType(pMap, IActiveView)

        ' to hold stats on the habitat - will be written to table at end of sub
        'Dim pHabStatsObject_2 As New StatisticsObject_2(Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
        'Dim pDCIStatsObject As New DCIStatisticsObject(Nothing, Nothing, Nothing, Nothing)
        Dim lHabStatsList As List(Of StatisticsObject_2) = New List(Of StatisticsObject_2)
        Dim lDCIStatsList As List(Of DCIStatisticsObject) = New List(Of DCIStatisticsObject)
        Dim lGLPKStatsList As List(Of GLPKStatisticsObject) = New List(Of GLPKStatisticsObject) ' for habitat stats for GLPK
        Dim lGLPKOptionsList As List(Of GLPKOptionsObject) = New List(Of GLPKOptionsObject) ' for options stats for GLPK
        Dim lGLPKOptionsListTEMP As List(Of GLPKOptionsObject) = New List(Of GLPKOptionsObject) ' for TEMP options stats for GLPK

        Dim sHabType As String

        Dim f_sOutID, f_sType As String ' To hold the (possibly) user-set ID and the 'type' of each flag
        Dim f_siOutEID As Integer
        Dim lBarrierAndSinkEIDs As List(Of BarrAndBarrEIDAndSinkEIDs) = New List(Of BarrAndBarrEIDAndSinkEIDs)
        Dim pBarrierAndSinkEIDs As New BarrAndBarrEIDAndSinkEIDs(Nothing, Nothing, Nothing)

        ' for pairing with DCI stats at the end of each flag's loop 

        ' ===================== GET EXTENSION SETTINGS ====================
        ' check if user has hit 'close/cancel'
        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            Exit Sub
        End If
        backgroundworker1.ReportProgress(5, "Getting FiPEx Option Settings")

        ' Declare settings variables and set defaults
        Dim sDirection As String = "up"     ' Analysis direction default to 'upstream'
        Dim iOrderNum As Integer = 1        ' the ordernum retrieved default to 1
        Dim bMaximum As Boolean = False     ' set maximum order yes/no default to no
        Dim bConnectTab As Boolean = False  ' Connectivity table default to 'no'
        Dim bBarrierPerm As Boolean = False ' Barrier perm field? 
        Dim bNaturalYN As Boolean = False   ' Natural Barrier y/n field?
        Dim bDCI As Boolean = False         ' Calculate DCI?
        Dim bDCISectional As Boolean = False ' Calculate DCI Sectional?
        Dim bDBF As Boolean = False         ' Include DBF output default 'no'
        Dim sGDB As String = ""             ' Output GDB for DBF output
        Dim sPrefix As String = ""          ' Prefix for output tables

        Dim bUpHab, bTotalUpHab, bDownHab, bTotalDownHab, bPathDownHab, bTotalPathDownHab As Boolean

        Dim iPolysCount As Integer = 0      ' number of polygon layers currently using
        Dim iLinesCount As Integer = 0      ' number of lines layers currently using
        Dim pLLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim pPLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim HabLayerObj As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property
        Dim lBarrierIDs As List(Of BarrierIDObj) = New List(Of BarrierIDObj)
        Dim pBarrierIDObj As New BarrierIDObj(Nothing, Nothing, Nothing, Nothing)

        Dim iBarrierIDs As Integer
        Dim sBarrierIDLayer, sBarrierIDField, sBarrierNaturalYNField, sBarrierPermField As String

        Dim bGLPKTables As Boolean
        Dim sGLPKModelDir As String
        Dim sGnuWinDir As String
        Dim uniqueBarrierEIDComparer As FindBarrierEIDPredicate

        'm_LLayersFields2.Clear() ' To be safe clear these
        'm_PLayersFields2.Clear() ' - issues during debugging found

        ' If settings have been set by the user then load them from the extension stream (stored in .mxd doc)
        If m_FiPEx__1.m_bLoaded = True Then

            sDirection = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("direction"))
            iOrderNum = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("ordernum"))     'May have problems here - need to convert to integer
            bMaximum = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("maximum"))
            'If they want the maximum then set ordernum to very large number (haven't found a better way yet)
            If bMaximum = True Then
                iOrderNum = 999
            End If
            bConnectTab = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("connecttab"))
            bBarrierPerm = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("barrierperm"))
            bNaturalYN = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("NaturalYN"))
            bDCI = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("dciyn"))
            bDCISectional = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("dcisectionalyn"))
            bDBF = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("bDBF"))
            sGDB = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sGDB"))
            sPrefix = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("TabPrefix"))

            bUpHab = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("UpHab"))
            bTotalUpHab = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("TotalUpHab"))
            bDownHab = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("DownHab"))
            bTotalDownHab = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("TotalDownHab"))
            bPathDownHab = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("PathDownHab"))
            bTotalPathDownHab = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("TotalPathDownHab"))

            iPolysCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numPolys"))

            HabLayerObj = New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property

            ' Populate a list of the layers to use and habitat summary fields.
            ' match any of the polygon layers saved in stream to those in listboxes 
            If iPolysCount > 0 Then
                For k = 0 To iPolysCount - 1
                    'sPolyLayer = m_FiPEX__1.pPropset.GetProperty("IncPoly" + k.ToString) ' get poly layer
                    HabLayerObj = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncPoly" + k.ToString)) ' get poly layer
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyClassField" + k.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyQuanField" + k.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyUnitField" + k.ToString))
                    End With

                    ' Load that object into the list
                    pPLayersFields.Add(HabLayerObj)  'what are the brackets about - this could be aproblem!!
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            Dim iCount1 As Integer = pPLayersFields.Count

            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    sTemp = pPLayersFields.Item(m).Layer
                    If pPLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for lacustrine layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If

            iLinesCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numLines"))
            Dim HabLayerObj2 As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property

            ' match any of the line layers saved in stream to those in listboxes
            If iLinesCount > 0 Then
                For j = 0 To iLinesCount - 1
                    'sLineLayer = m_FiPEX__1.pPropset.GetProperty("IncLine" + j.ToString) ' get line layer
                    HabLayerObj2 = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj2
                        '.Layer = sLineLayer
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncLine" + j.ToString))
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineClassField" + j.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineQuanField" + j.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineUnitField" + j.ToString))
                    End With
                    pLLayersFields.Add(HabLayerObj2)
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            iCount1 = pLLayersFields.Count
            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    If pLLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for river layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If

            ' Get the barrier ID Fields
            iBarrierIDs = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numBarrierIDs"))
            If iBarrierIDs > 0 Then
                For j = 0 To iBarrierIDs - 1
                    sBarrierIDLayer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("BarrierIDLayer" + j.ToString))
                    sBarrierIDField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("BarrierIDField" + j.ToString))
                    sBarrierPermField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("BarrierPermField" + j.ToString))
                    sBarrierNaturalYNField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("BarrierNaturalYNField" + j.ToString))
                    pBarrierIDObj = New BarrierIDObj(sBarrierIDLayer, sBarrierIDField, sBarrierPermField, sBarrierNaturalYNField)
                    lBarrierIDs.Add(pBarrierIDObj)
                Next
            End If

            bGLPKTables = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("bGLPKTables"))
            sGLPKModelDir = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sGLPKModelDir"))
            sGnuWinDir = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sGnuWinDir"))

            'TEMP HARDCODING
            bGLPKTables = False
            sGLPKModelDir = "c:\GunnsModel\"
            'sGnuWinDir = "c:\GnuWin32\"

        Else
            ' TODO: Pop-up form with current settings
            ' Add a button on form that loads options
            ' upon close, if options form within for has been opened
            ' then keep looping
            Dim sMessage As String = "Please set analysis options in menu and re-run tool"
            System.Windows.Forms.MessageBox.Show(sMessage, "Parameters Missing")
            Exit Sub
        End If

        '======================================
        ' Can use a 3 dimensional Array to populate statistics
        ' These are multiple recordsets with rows and columns,
        ' stacked on top of each other.  The OrderNum determines
        ' the 3rd dimension
        'Dim statsArray3D(iOrderNum, 4, 1) As Double 'VB.NET

        ' IF THE FOLLOWING DOCKWIN CODE IS ONLY NEEDED IN THE CALCSTATS SECTION
        ' THEN THIS CODE COULD BE DELETED

        '' Output Form (will replace dockable window)
        'Dim pResultsForm As New FiPEx.frmResults
        'pResultsForm.Show()

        'Create Dockable Window
        'If bDockWin = True Then
        '    Dim u As New UID
        '    u.Value = "{5904bd54-d8ec-4dd8-b1e1-9adcb6558d26}"

        '    pDockWin = m_DockWinMgr.GetDockableWindow(u)
        '    pDockWin.Show(True)
        '    pDockWin.Dock(esriDockFlags.esriDockShow)

        ' If pDockwin works, try to link in and clear the listbox
        ' sample code from http://edndoc.esri.com/arcobjects/9.2/NET/ViewCodePages/e439cf8c-778b-4fdb-b4c4-fab51a546ac6ClearLoggingCommand.vb.htm
        'If pDockWin IsNot Nothing Then
        '    Dim containedBox As System.Windows.Forms.ListBox = TryCast(pDockWin.UserData, System.Windows.Forms.ListBox)
        '    containedBox.Items.Clear()
        'End If

        'End If

        'MsgBox("Debug:1")

        ' =============== SAVE ORIGINAL GEONet SETTINGS =========================
        ' check if user has hit 'close/cancel'
        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        backgroundworker1.ReportProgress(8, "Saving Current Geometric Network Flags and Barriers")


        pNetworkAnalysisExt = CType(m_UNAExt, INetworkAnalysisExt)
        Dim pGeometricNetwork As IGeometricNetwork = pNetworkAnalysisExt.CurrentNetwork
        pGeometricNetwork = pNetworkAnalysisExt.CurrentNetwork

        pNetwork = pGeometricNetwork.Network
        pNetElements = CType(pNetwork, INetElements)

        ' QI for the ITraceTasks interface using IUtilityAnalysisExt
        pTraceTasks = CType(m_UNAExt, ITraceTasks)

        ' update extension with the results
        ' QI for the INetworkAnalysisExtResults interface using IUTilityNetworkAnalysisExt
        pNetworkAnalysisExtResults = CType(m_UNAExt, INetworkAnalysisExtResults)

        ' clear any leftover results from previous calls to the cmd
        pNetworkAnalysisExtResults.ClearResults()

        ' QI the Flags and barriers
        pNetworkAnalysisExtFlags = CType(m_UNAExt, INetworkAnalysisExtFlags)
        pNetworkAnalysisExtBarriers = CType(m_UNAExt, INetworkAnalysisExtBarriers)

        ' Was using ArrayList because of advantage of 'count' and 'add' properties
        ' but EnumNetEIDBuilderGEN addition to 9.2 has this functionality
        pOriginalBarriersListGEN = New EnumNetEIDArray
        pOriginalEdgeFlagsListGEN = New EnumNetEIDArray
        pOriginaljuncFlagsListGEN = New EnumNetEIDArray

        Dim iOriginalJunctionBarrierCount As Integer
        iOriginalJunctionBarrierCount = pNetworkAnalysisExtBarriers.JunctionBarrierCount

        ' Save the barriers
        For i = 0 To pNetworkAnalysisExtBarriers.JunctionBarrierCount - 1
            ' Use bFlagDisplay to retrieve EIDs of the barriers for later
            bFlagDisplay = CType(pNetworkAnalysisExtBarriers.JunctionBarrier(i), IFlagDisplay)
            bEID = pNetElements.GetEID(bFlagDisplay.FeatureClassID, bFlagDisplay.FID, bFlagDisplay.SubID, esriElementType.esriETJunction)
            pOriginalBarriersListGEN.Add(bEID)
            'originalBarriersList(i) = bEID
        Next

        ' QI to and get an array object that has 'count' and 'next' methods
        pOriginalBarriersList = CType(pOriginalBarriersListGEN, IEnumNetEID)

        ' Save the flags
        i = 0
        For i = 0 To pNetworkAnalysisExtFlags.JunctionFlagCount - 1
            ' Use the bFlagDisplay to retrieve the EIDs of the junction flags
            bFlagDisplay = CType(pNetworkAnalysisExtFlags.JunctionFlag(i), IFlagDisplay)
            bEID = pNetElements.GetEID(bFlagDisplay.FeatureClassID, bFlagDisplay.FID, bFlagDisplay.SubID, esriElementType.esriETJunction)
            pOriginaljuncFlagsListGEN.Add(bEID)
            'pOriginaljuncFlagsList(i) = bEID
        Next

        ' QI to and get an array interface that has 'count' and 'next' methods
        'pOriginaljuncFlagsList = 
        pOriginaljuncFlagsList = CType(pOriginaljuncFlagsListGEN, IEnumNetEID)

        ' ******** NO EDGE FLAG SUPPORT YET *********
        i = 0
        For i = 0 To pNetworkAnalysisExtFlags.EdgeFlagCount - 1

            ' Use the bFlagDisplay to retrieve EIDs of the Edge flags for later
            bFlagDisplay = CType(pNetworkAnalysisExtFlags.EdgeFlag(i), IFlagDisplay)
            bEID = pNetElements.GetEID(bFlagDisplay.FeatureClassID, bFlagDisplay.FID, bFlagDisplay.SubID, esriElementType.esriETEdge)
            pOriginalEdgeFlagsListGEN.Add(bEID)
            'pOriginalEdgeFlagsList(i) = bEID
        Next

        ' QI to and get an array interface that has 'count' and 'next' methods
        pOriginalEdgeFlagsList = CType(pOriginalEdgeFlagsListGEN, IEnumNetEID)
        ' ******************************************

        ' If there are no flags set exit sub
        If pNetworkAnalysisExtFlags.JunctionFlagCount = 0 Then
            'If pNetworkAnalysisExtFlags.EdgeFlagCount = 0 Then
            MsgBox("There are no flags set on junctions.  Please Set flags only on network junctions.")
            Exit Sub
            'End If
        End If

        ' =============== FLAG CONSISTENCY CHECK ====================
        ' Check for consistency that flags are all on barriers or all on non-barriers.
        Dim sFlagCheck As String
        sFlagCheck = flagcheck(pOriginalBarriersList, pOriginalEdgeFlagsList, pOriginaljuncFlagsList)
        '    MsgBox "FlagCheck may be null and crash..."
        '    MsgBox "sFlagcheck: " + sFlagCheck
        If sFlagCheck = "error" Then
            Exit Sub
        End If
        ' ============= END FLAG CONSISTENCY CHECK ==================

        ' Make sure all the layers in the TOC are selectable
        For i = 0 To pMap.LayerCount - 1
            If pMap.Layer(i).Valid = True Then
                If TypeOf pMap.Layer(i) Is IFeatureLayer Then
                    pFLyrSlct = CType(pMap.Layer(i), IFeatureLayer)
                    pFLyrSlct.Selectable = True
                End If
            End If
        Next
        i = 0

        ' =================== GET WORKSPACE ========================
        ' Prepare for creating output tables

        'Dim pWorkspaceName As IWorkspaceName = New WorkspaceName
        Dim sConnectTabName As String = ""

        ' =============== For DCI Table Output =====================

        ' obtain reference to current geometric network
        ' and get all participating point feature classes so only
        ' those are included in the barriers list. 
        pGeometricNetwork = pNetworkAnalysisExt.CurrentNetwork

        ' Get all simple edges participating in the geometric network
        Dim pEnumSimpLineFCs As ESRI.ArcGIS.Geodatabase.IEnumFeatureClass = pGeometricNetwork.ClassesByType(esriFeatureType.esriFTSimpleEdge)
        ' No complex edge support yet... 
        Dim pEnumCompLineFCs As ESRI.ArcGIS.Geodatabase.IEnumFeatureClass = pGeometricNetwork.ClassesByType(esriFeatureType.esriFTComplexEdge)

        Dim pFeatureClass As IFeatureClass
        Dim pFeatureLayer As IFeatureLayer
        Dim bEdgeMatch As Boolean ' load all layers in TOC to the lstbox
        Dim sHabTableName As String
        Dim lFCIDs As New List(Of FCIDandNameObject) ' to hold FCIDs of included line layers
        Dim lAllFCIDs As New List(Of FCIDandNameObject) ' to hold FCIDs of included line layers
        Dim pFCIDandNameObject As New FCIDandNameObject(Nothing, Nothing)
        Dim pMetricsObject As New MetricsObject(Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
        Dim lMetricsObject As New List(Of MetricsObject)
        Dim iLineFCID, iPolyFCID As Integer
        Dim bLineFCIDFound, bPolyFCIDFound As Boolean
        Dim pLayer As ILayer
        Dim lLLayersFieldsDCI As New List(Of LayerToAdd)
        Dim lAllLayersFieldsGLPK As New List(Of LayerToAdd)

        Dim lGLPKUniqueEIDs As List(Of Integer)
        Dim sDCITableName, sMetricTableName As String
        Dim sFeatureLayerName As String
        Dim sGLPKHabitatTableName, sGLPKOptionsTableName, sGLPKConnectTabName As String
        ' Need to get the FC Id's of the line layers because
        ' names might change and there might be duplicate names, names
        ' that repeat but are different FC's, (weird stuff like that)
        ' NOTE: this should have been done in Options code and stored in Extension settings.
        ' check if user has hit 'close/cancel'
        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        backgroundworker1.ReportProgress(10, "Getting participating layers from the Table of Contents")

        'MsgBox("Debug:2")
        i = 0
        j = 0
        m = 0
        For i = 0 To pLLayersFields.Count - 1
            For j = 0 To pMap.LayerCount - 1
                If pMap.Layer(j).Valid = True And TypeOf pMap.Layer(j) Is IFeatureLayer Then
                    pLayer = pMap.Layer(j)
                    pFeatureLayer = CType(pLayer, IFeatureLayer)
                    sFeatureLayerName = pLLayersFields(i).Layer
                    If pFeatureLayer.Name = sFeatureLayerName Then
                        'Note: there are a number of options for FC ID's - this one seems most reasonable.
                        iLineFCID = pFeatureLayer.FeatureClass.FeatureClassID
                        If iLineFCID <> -1 Then ' check that this is not a shapefile
                            'Check that this FCID isn't already in the list
                            bLineFCIDFound = False
                            pFCIDandNameObject = New FCIDandNameObject(Nothing, Nothing)
                            If lFCIDs.Count > 0 Then
                                For m = 0 To lFCIDs.Count - 1
                                    If lFCIDs(m).FCID = iLineFCID Then
                                        bLineFCIDFound = True
                                    End If
                                Next
                                If bLineFCIDFound = False Then
                                    pFCIDandNameObject.FCID = iLineFCID
                                    pFCIDandNameObject.Name = pFeatureLayer.Name
                                    lFCIDs.Add(pFCIDandNameObject)
                                    lAllFCIDs.Add(pFCIDandNameObject)
                                End If
                            Else
                                pFCIDandNameObject.FCID = iLineFCID
                                pFCIDandNameObject.Name = pFeatureLayer.Name
                                lFCIDs.Add(pFCIDandNameObject)
                                lAllFCIDs.Add(pFCIDandNameObject)
                            End If
                        End If ' not a shapefile or coverage
                    End If
                End If
            Next
        Next

        ' Add the polygon layers to the ALL FCIDs list\
        ' this is use later in the predicate search to get unique 
        ' feature classes to draw out from the master habitat object

        'MsgBox("Debug:3")
        i = 0
        j = 0
        m = 0
        For i = 0 To pPLayersFields.Count - 1
            For j = 0 To pMap.LayerCount - 1
                If pMap.Layer(j).Valid = True And TypeOf pMap.Layer(j) Is IFeatureLayer Then
                    pLayer = pMap.Layer(j)
                    pFeatureLayer = CType(pLayer, IFeatureLayer)
                    If pFeatureLayer.Name = pPLayersFields(i).Layer Then
                        'Note: there are a number of options for FC ID's - this one seems most reasonable.
                        iPolyFCID = pFeatureLayer.FeatureClass.FeatureClassID
                        If iPolyFCID <> -1 Then ' check that this is not a shapefile
                            'Check that this FCID isn't already in the list
                            bPolyFCIDFound = False
                            pFCIDandNameObject = New FCIDandNameObject(Nothing, Nothing)
                            If lAllFCIDs.Count > 0 Then
                                For m = 0 To lAllFCIDs.Count - 1
                                    If lAllFCIDs(m).FCID = iPolyFCID Then
                                        bPolyFCIDFound = True
                                    End If
                                Next
                                If bPolyFCIDFound = False Then
                                    pFCIDandNameObject.FCID = iPolyFCID
                                    pFCIDandNameObject.Name = pFeatureLayer.Name
                                    lAllFCIDs.Add(pFCIDandNameObject)
                                End If
                            Else
                                pFCIDandNameObject.FCID = iPolyFCID
                                pFCIDandNameObject.Name = pFeatureLayer.Name
                                lAllFCIDs.Add(pFCIDandNameObject)
                            End If
                        End If ' not a shapefile or coverage
                    End If
                End If
            Next
        Next

        ' ============== Begin DBF Table Preparation =======================
        ' 1.0 If tables are to be output in DBF format
        '   2.0 For each of the line layers included
        '     2.1 Get a table name (tablename function)
        '     2.2 Add that table name to a list for use... 
        '     2.3 Set up the fields for that table
        '     2.4 Create that table (PrepDBFOutTable Subroutine)
        '     2.5 Add the table to the TOC in ArcMap
        '     3.0a If the flag is not on a barrier
        '       3.1a Get a table name and add it to a list ("flagadjacent habitat")
        '       3.2a Create the table and add it to the TOC in ArcMap
        '       4.0a If the total impounded/impacted habitat is wanted
        '          4.1a Create fields and table for those statistics
        '       3.0b Else if the flag is on a barrier
        '       4.0b If the total impounded/impacted habitat is wanted
        '         4.1b Create fields and table for those statistics
        ' **** Repeat above process for each polygon layer ****

        'MsgBox("Debug:4")
        If bDBF = True Then

            ' Get the path to the database
            pFWorkspace = GetWorkspace(sGDB)
            If pFWorkspace Is Nothing Then
                System.Windows.Forms.MessageBox.Show("Could not get reference to output workspace.  " _
                + "Please check output geodatabase in options menu", "Output Workspace Error")
                Exit Sub
            End If

            ' Change the active tab in the TOC to 'source'
            ' to show tables
            Dim pTOC As IContentsView
            pTOC = pMxDocument.ContentsView(1)
            pMxDocument.CurrentContentsView = pTOC

            If bDCI = True Then

                'MsgBox("Debug:5")
                ' Make sure that each of the included line layers are members of the 
                ' geometric network (and simple line feature classes). This is because
                ' lines are not currently intersected (only polygons).  

                'Initial set of feature class
                pEnumSimpLineFCs.Reset()
                pFeatureClass = pEnumSimpLineFCs.Next
                i = 0
                j = 0
                If lFCIDs.Count > 0 Then
                    Do Until pFeatureClass Is Nothing
                        For i = 0 To lFCIDs.Count - 1
                            If lFCIDs(i).FCID = pFeatureClass.FeatureClassID Then
                                For j = 0 To pLLayersFields.Count - 1
                                    If pLLayersFields(j).Layer = lFCIDs(i).Name Then
                                        lLLayersFieldsDCI.Add(pLLayersFields(j))
                                    End If
                                Next 'j
                            End If
                        Next 'i
                        pFeatureClass = pEnumSimpLineFCs.Next
                    Loop
                End If

            End If
            ' ============== End for DCI Output ===============

            'MsgBox("Debug:6")
            ' For GLPK Filter out the lines that are not part of the network 
            ' as above, but keep all polygons included in the analysis
            lAllLayersFieldsGLPK = New List(Of LayerToAdd)
            If bGLPKTables = True Then
                'Initial set of feature class
                pEnumSimpLineFCs.Reset()
                pFeatureClass = pEnumSimpLineFCs.Next
                i = 0
                j = 0
                If lAllFCIDs.Count > 0 Then
                    Do Until pFeatureClass Is Nothing
                        For i = 0 To lAllFCIDs.Count - 1
                            If lAllFCIDs(i).FCID = pFeatureClass.FeatureClassID Then
                                For j = 0 To pLLayersFields.Count - 1
                                    If pLLayersFields(j).Layer = lAllFCIDs(i).Name Then
                                        lAllLayersFieldsGLPK.Add(pLLayersFields(j))
                                    End If
                                Next 'j                              
                            End If
                        Next 'i
                        pFeatureClass = pEnumSimpLineFCs.Next
                    Loop
                End If
                j = 0
                For j = 0 To pPLayersFields.Count - 1
                    lAllLayersFieldsGLPK.Add(pPLayersFields(j))
                Next 'j
            End If


            'Else ' If there is no DBF Table Output

            '' Still need the table names for output to dockable window
            '' Will use names to title each section of dockable window
            '' -------------------------------------------------------
            '' 1.0 For each line layer included
            '' 1.1 Get the name of the layer for TITLE for each output block
            '' 2.0a If the flag is not on a barrier
            ''   2.1a Add the word 'Accessible' before the title
            ''   2.2a Add this name to a list of titles for 'unimpacted/adjacent habitat'
            ''   3.0a If total impacted is needed
            ''     3.1a Add 'TtlAffctd' before the title and add it to a title list
            ''         of 'impacted/impounded habitat'
            '' 2.0b Else if the flag is on a barrier
            ''   3.0b If total impacted is needed 
            ''     3.1b Add 'TtlAffctd' before the title and add it to a title list
            ''          of 'impacted/impounded habitat'
            '' **** Repeat this for polygon layers included ****

            'For i = 0 To pLLayersFields.Count - 1
            '    lTableNames.Add(pLLayersFields(i).Layer)

            '    If sFlagCheck = "nonbarr" Then
            '        'sTableName = "FlagAdjacentHabitat" + pLLayersFields(i).Layer
            '        'lFlagTabNamesUImp.Add(sTableName)
            '        If bTotalHab = True Then
            '            sTableName = "TotalHabitat_" + pLLayersFields(i).Layer
            '            lFlagTabNamesImp.Add(sTableName)
            '        End If
            '    ElseIf sFlagCheck = "barriers" Then

            '        If bTotalHab = True Then
            '            sTableName = "TotalHabitat_" + pLLayersFields(i).Layer
            '            lBarTabNamesTtlImp.Add(sTableName)
            '        End If
            '    End If
            'Next

            '' Get names for all polygon layers using
            'For i = 0 To pPLayersFields.Count - 1
            '    lTableNames.Add(pPLayersFields(i).Layer)

            '    If sFlagCheck = "nonbarr" Then
            '        'sTableName = "FlagAdjacentHabitat" + pPLayersFields(i).Layer
            '        'lFlagTabNamesUImp.Add(sTableName)
            '        If bTotalHab = True Then
            '            sTableName = "TotalHabitat_" + pPLayersFields(i).Layer
            '            lFlagTabNamesImp.Add(sTableName)
            '        End If
            '    ElseIf sFlagCheck = "barriers" Then
            '        If bTotalHab = True Then
            '            sTableName = "TotalHabitat_" + pPLayersFields(i).Layer
            '            lBarTabNamesTtlImp.Add(sTableName)
            '        End If
            '    End If
            'Next ' polygon layer
        End If ' DBF layers are included

        ' ========================== Begin Traces ====================

        'MsgBox("Debug:7")
        ' check if user has hit 'close/cancel'
        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        backgroundworker1.ReportProgress(10, "Beginning Network Traces")

        barrierCount = pNetworkAnalysisExtBarriers.JunctionBarrierCount
        Dim pSymbol As ISymbol
        Dim pJuncFlagDisplay As IJunctionFlagDisplay
        Dim sOutID As String 'ID of flag for output table
        Dim pAllFlowEndBarriersGEN As IEnumNetEIDBuilderGEN = New EnumNetEIDArray
        Dim pAllFlowEndBarriers As IEnumNetEID
        Dim pNextOriginalJuncFlagGEN As IEnumNetEIDBuilderGEN = New EnumNetEIDArray
        Dim pNextOriginalJuncFlag As IEnumNetEID
        Dim fEID As Integer ' to hold the flag ID for the next flag
        Dim pUID As New UID
        Dim pEnumLayer As IEnumLayer
        ' for connectivity info:
        Dim pBarrierAndDownstreamEID As New BarrierAndDownstreamID(Nothing, Nothing)
        Dim pGLPKBarrAndDownEID As New GLPKBarrierAndDownstreamEID(Nothing, Nothing)
        Dim lConnectivity As New List(Of BarrierAndDownstreamID)
        Dim lGLPKConnectivity As New List(Of GLPKBarrierAndDownstreamEID)
        Dim sFlowEndID, sHabDir, sTableType, sType As String
        Dim dDCIp, dDCId, dPerm As Double ' holds DCIp and DCId stats, 9999 if error
        Dim bNoPerm As Boolean ' holds trigger to check if a single barrier does have a zero permeability
        Dim bNaturalY As Boolean = False ' holds trigger to check if any barrier is labeled as 'Natural' - 
        ' determines how output DCI file is read

        Dim pDownConnectedJunctions, pDownConnectedEdges As IEnumNetEID
        Dim pSubtractUpJunctions, pSubtractUpEdges As IEnumNetEID
        Dim pConnectedJunctions, pConnectedEdges As IEnumNetEID
        Dim pIDAndType As New IDandType(Nothing, Nothing)
        Dim pGLPKOptionsObject As New GLPKOptionsObject(Nothing, Nothing, Nothing, Nothing)
        Dim iMaxOptionNum As Integer = 0

        pUID.Value = "{E156D7E5-22AF-11D3-9F99-00C04F6BC78E}"

        pEnumLayer = pMap.Layers(pUID, True)

        ' =========== GET SYMBOLS ============


        Dim pFlagSymbol, pBarrierSymbol As ISimpleMarkerSymbol
        Dim pSimpleMarkerSymbol As ISimpleMarkerSymbol = New SimpleMarkerSymbol
        Dim pRgbColor As IRgbColor = New RgbColor

        ' For the Flag marker
        With pRgbColor
            .Red = 0
            .Green = 255
            .Blue = 0
        End With
        pSimpleMarkerSymbol = New SimpleMarkerSymbol
        With pSimpleMarkerSymbol
            .Color = pRgbColor
            .Style = esriSimpleMarkerStyle.esriSMSSquare
            .Outline = True
            .Size = 10
        End With

        ' Result is a global variable containing a flag marker
        pFlagSymbol = pSimpleMarkerSymbol

        pRgbColor = New RgbColor

        ' Set the barrier symbol color and parameters
        With pRgbColor
            .Red = 255
            .Green = 0
            .Blue = 0
        End With

        pSimpleMarkerSymbol = New SimpleMarkerSymbol

        With pSimpleMarkerSymbol
            .Color = pRgbColor
            .Style = esriSimpleMarkerStyle.esriSMSX
            .Outline = True
            .Size = 10
        End With


        ' Result is a global variable containing a barrier marker
        pBarrierSymbol = pSimpleMarkerSymbol

        ' ============= END GET SYMBOLS ==============

        iProgress = 10
        Dim iProgressIncrementFactor As Integer
        Try
            iProgressIncrementFactor = Convert.ToInt16(30 / pOriginaljuncFlagsList.Count)
        Catch ex As Exception
            MsgBox("Error Converting ProgressIncrementFactor")
        End Try

        ' For each order
        '   If this is the first iteration
        '     If this is a "Non Barrier" analysis
        '       For each original junction flag
        '       Clear all flags
        '       Get the element ID of the flag
        '       Get the user ID's of the flag
        '       Display the flag / Set as flag in geonet
        '       Run the TraceFlowSolverSetup Sub (setup network)
        '       Run the trace on all flags to get the set of barriers first
        '       encountered.
        '         If no results were returned
        '         Create empty objects for returned edges and junctions
        '       Make trace results a selection
        '       Get the features stopping the trace 
        '       Filter the features stopping the trace (no sinks/sources/non-barriers)
        '       If the current flag is on a point with field that matches

        lHabStatsList = New List(Of StatisticsObject_2) ' set the habitat stats list

        pOriginaljuncFlagsList.Reset()
        For i = 0 To pOriginaljuncFlagsList.Count - 1
            ' check if user has hit 'close/cancel'
            If m_bCancel = True Then
                backgroundworker1.CancelAsync()
                backgroundworker1.Dispose()
                Exit Sub
            End If
            backgroundworker1.ReportProgress(10, "Performing Network Traces " & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & (pOriginaljuncFlagsList.Count).ToString)

            'MsgBox("Debug:8")
            ' reset the counter
            orderLoop = 0
            bNaturalY = False

            ' reset statistics lists
            lConnectivity = New List(Of BarrierAndDownstreamID)
            lDCIStatsList = New List(Of DCIStatisticsObject)

            ' reset the flow end elements tracker (barriers tracker)
            ' this variable prevents infinite looping but can be reset
            ' for each original flag.  
            pAllFlowEndBarriersGEN = New EnumNetEIDArray
            pAllFlowEndBarriers = CType(pAllFlowEndBarriersGEN, IEnumNetEID)

            fEID = pOriginaljuncFlagsList.Next
            pNextOriginalJuncFlagGEN = New EnumNetEIDArray
            pNextOriginalJuncFlagGEN.Add(fEID)
            pNextOriginalJuncFlag = CType(pNextOriginalJuncFlagGEN, IEnumNetEID)

            For orderLoop = 0 To iOrderNum

                'MsgBox("Debug:9")
                If orderLoop = 0 Then

                    ' Change variable on first iteration for filtering next
                    pFlowEndJunctions = pNextOriginalJuncFlag
                ElseIf orderLoop > 0 Then
                    If pFlowEndJunctions.Count = 0 Or pFlowEndJunctions Is Nothing Then
                        Exit For
                    End If
                End If

                'MsgBox("Debug:10")
                pNoSourceFlowEnds = New EnumNetEIDArray

                ' ================ RUN TRACE ON ONE FLAG AT A TIME ======================
                ' check if user has hit 'close/cancel'
                If m_bCancel = True Then
                    backgroundworker1.CancelAsync()
                    backgroundworker1.Dispose()
                    Exit Sub
                End If
                If iProgress < 50 Then
                    iProgress = iProgress + 1
                End If
                backgroundworker1.ReportProgress(iProgress, "Performing Network Traces " & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                         "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                         "Direction: " & sDirection)

                'MsgBox("Debug:11")
                pFlowEndJunctions.Reset()
                For j = 0 To pFlowEndJunctions.Count - 1

                    ' this variable holds trace flow ends that are not sources
                    pNoSourceFlowEndsTemp = New EnumNetEIDArray

                    iEID = pFlowEndJunctions.Next()

                    ' ============ FILTER BARRIERS (eliminate barriers where flags will be) ===
                    ' For each of the original barriers
                    '   For each of the flow end junctions from the last trace
                    '     If the original barrier is NOT on a flow end junction 
                    '     Add it to a list to use in the upcoming trace.
                    ' DO NOT NEED TO DO THIS IN CASE THIS IS A 'NONBARR' ANALYSIS
                    ' AND ORDERLOOP = 0.  LOGIC THO?

                    p = 0
                    'reset / initialize OriginalBarriers list
                    pOriginalBarriersList.Reset()
                    ' clear the previous list
                    pNextTraceBarrierEIDGEN = New EnumNetEIDArray

                    For p = 0 To pOriginalBarriersList.Count - 1
                        bEID = pOriginalBarriersList.Next
                        flagOverBarrier = False

                        ' If the EID of the end-of-flow junctions do not equal
                        ' that of the barriers set in the last trace then keep
                        ' that barrier for the next trace.
                        If bEID = iEID Then
                            flagOverBarrier = True
                        End If
                        'Next

                        ' For each barrier from the previous trace, add that barrier to a list
                        ' of barriers for the next trace if it doesn't overlap with one of the
                        ' flags for the next trace
                        If Not flagOverBarrier Then
                            ' add the barrier to a list of barriers to use in the next trace
                            pNextTraceBarrierEIDGEN.Add(bEID) 'VB.NET
                        End If
                    Next

                    'QI to get 'next' and 'count'
                    pNextTraceBarrierEIDs = CType(pNextTraceBarrierEIDGEN, IEnumNetEID)
                    ' ====================== END FILTER BARRIERS =============================

                    'MsgBox("Debug:12")
                    ' ========================== SET BARRIERS  ===============================
                    m = 0
                    pNextTraceBarrierEIDs.Reset()
                    pNetworkAnalysisExtBarriers.ClearBarriers()

                    For m = 0 To pNextTraceBarrierEIDs.Count - 1
                        bEID = pNextTraceBarrierEIDs.Next
                        pNetElements.QueryIDs(bEID, esriElementType.esriETJunction, bFCID, bFID, bSubID)

                        ' Display the barriers as a JunctionFlagDisplay type
                        pFlagDisplay = New JunctionFlagDisplay
                        pSymbol = CType(pBarrierSymbol, ISymbol)
                        With pFlagDisplay
                            .FeatureClassID = bFCID
                            .FID = bFID
                            .Geometry = pGeometricNetwork.GeometryForJunctionEID(bEID)
                            .Symbol = pSymbol
                        End With

                        ' Add the flags to the logical network
                        pJuncFlagDisplay = CType(pFlagDisplay, IJunctionFlagDisplay)
                        pNetworkAnalysisExtBarriers.AddJunctionBarrier(pJuncFlagDisplay)
                    Next
                    ' ========================== END SET BARRIERS ===========================

                    ' ========================== SET FLAG ====================================

                    'MsgBox("Debug:13")
                    pNetworkAnalysisExtFlags.ClearFlags()
                    pNetElements.QueryIDs(iEID, esriElementType.esriETJunction, iFCID, iFID, iSubID)

                    ' Display the flags as a JunctionFlagDisplay type
                    pFlagDisplay = New JunctionFlagDisplay
                    pSymbol = CType(pFlagSymbol, ISymbol)
                    With pFlagDisplay
                        .FeatureClassID = iFCID
                        .FID = iFID
                        .Geometry = pGeometricNetwork.GeometryForJunctionEID(iEID)
                        .Symbol = pSymbol
                    End With

                    ' Add the flags to the logical network
                    pJuncFlagDisplay = CType(pFlagDisplay, IJunctionFlagDisplay)
                    pNetworkAnalysisExtFlags.AddJunctionFlag(pJuncFlagDisplay)


                    ' ====================== RUN TRACE IN DIRECTION OF ANALYSIS ====================
                    '                            TO GET FLOW END ELEMENTS

                    'MsgBox("Debug:14")
                    'prepare the network solver
                    pTraceFlowSolver = TraceFlowSolverSetup()
                    If pTraceFlowSolver Is Nothing Then
                        System.Windows.Forms.MessageBox.Show("Could not set up the network. Check that there is a network loaded.", "TraceFlowSolver setup error.")
                        Exit Sub
                    End If

                    eFlowElements = esriFlowElements.esriFEJunctionsAndEdges

                    'Return the features stopping the trace
                    If sDirection = "up" Then
                        pTraceFlowSolver.FindFlowEndElements(esriFlowMethod.esriFMUpstream, eFlowElements, pFlowEndJunctionsPer, pFlowEndEdgesPer)
                    Else
                        pTraceFlowSolver.FindFlowEndElements(esriFlowMethod.esriFMDownstream, eFlowElements, pFlowEndJunctionsPer, pFlowEndEdgesPer)
                    End If
                    ' ============================ END RUN TRACE  ===============================

                    'MsgBox("Debug:15")
                    ' ================= GET BARRIER ID AND METRICS ===================
                    ' Gets the ID of the current flag?
                    pIDAndType = New IDandType(Nothing, Nothing)

                    pIDAndType = GetBarrierID(iFCID, iFID, lBarrierIDs)

                    sOutID = pIDAndType.BarrID

                    'If sOutID = "145" Then
                    '    MsgBox("!!!")
                    'End If

                    sType = pIDAndType.BarrIDType
                    If sType <> "Sink" And orderLoop = 0 And sFlagCheck = "nonbarr" Then
                        sType = "Flag - Node"
                    ElseIf sType <> "Sink" And orderLoop = 0 And sFlagCheck = "barrier" Then
                        sType = "Flag - barrier"
                    End If

                    If bBarrierPerm = True Then
                        dBarrierPerm = GetBarrierPerm(iFCID, iFID, lBarrierIDs)
                    Else
                        dBarrierPerm = 0
                    End If
                    If bNaturalYN = True Then
                        sNaturalYN = GetNaturalYN(iFCID, iFID, lBarrierIDs)
                    Else
                        sNaturalYN = "F"
                    End If

                    If sNaturalYN = "T" Then
                        bNaturalY = True
                    End If

                    If bGLPKTables = True Then

                        'MsgBox("Debug:16")
                        ' first add 'do nothing option', cost of zero
                        ' If orderloop is zero and the analysis type is 'nonbarr' then
                        ' assign a passability of 100% to the 'sink' (start-point)
                        If orderLoop = 0 And sFlagCheck = "nonbarr" Then
                            pGLPKOptionsObject = New GLPKOptionsObject(iEID, 1, 1, 0)
                            lGLPKOptionsList.Add(pGLPKOptionsObject)
                        Else
                            pGLPKOptionsObject = New GLPKOptionsObject(iEID, 1, dBarrierPerm, 0)
                            lGLPKOptionsList.Add(pGLPKOptionsObject)
                        End If

                        lGLPKOptionsListTEMP = GetGLPKOptions(iFCID, iFID, lBarrierIDs, iEID)
                        m = 0
                        For m = 0 To lGLPKOptionsListTEMP.Count - 1
                            lGLPKOptionsList.Add(lGLPKOptionsListTEMP(m))
                        Next


                    End If

                    ' Will save this sOutID and sType for later use, if this is orderloop zero (flag)
                    ' because will need to insert the DCI Metric at the end of this flag loop
                    ' else if it's a barrier in a greater order loop we're visiting, then keep
                    ' track of their id's for later use.  
                    If orderLoop = 0 Then
                        f_sOutID = sOutID
                        f_siOutEID = iEID
                        f_sType = sType
                    Else
                        pBarrierAndSinkEIDs = New BarrAndBarrEIDAndSinkEIDs(f_siOutEID, iEID, sOutID)
                        lBarrierAndSinkEIDs.Add(pBarrierAndSinkEIDs)
                    End If

                    pMetricsObject = New MetricsObject(f_sOutID, f_siOutEID, sOutID, iEID, sType, "Permeability", dBarrierPerm)
                    lMetricsObject.Add(pMetricsObject)

                    ' ================ END GET IDS AND METRICS =============

                    ' Before the next stage, save the iFID variable because it may 
                    ' get reset in FILTER FLOW END ELEMENTS and it is used to label 
                    ' sinks in the form output
                    Dim sFID As String = iFID.ToString


                    ' =========================== FILTER FLOW END ELEMENTS (no sources) =================
                    ' Filter first flow end elements so that only barriers are included
                    ' 
                    ' 1) For each flow-stopping element 
                    '   2) For each original barrier set by the user
                    '     3) If there is a match 
                    '       4) If they have not already been encountered before
                    '         (need this check in case trace was on indeterminate flow - 
                    '          to avoid infinite looping)
                    '         5)Add them to a list to use as FLAGS later
                    'If this is orderloop zero
                    ' then it's okay to reset the 
                    pAllFlowEndBarriers = CType(pAllFlowEndBarriersGEN, IEnumNetEID)
                    pFlowEndJunctionsPer.Reset()
                    p = 0

                    'MsgBox("Debug:17")
                    For p = 0 To pFlowEndJunctionsPer.Count - 1

                        keepEID = False 'initializw
                        endEID = pFlowEndJunctionsPer.Next
                        m = 0
                        pOriginalBarriersList.Reset()
                        For m = 0 To pOriginalBarriersList.Count - 1
                            If endEID = pOriginalBarriersList.Next Then
                                keepEID = True ' set true if found
                                pAllFlowEndBarriers.Reset()
                                For k = 0 To pAllFlowEndBarriers.Count - 1
                                    If endEID = pAllFlowEndBarriers.Next Then
                                        keepEID = False ' set false if already on master list
                                    End If
                                Next
                            End If
                        Next

                        If keepEID = True Then
                            pAllFlowEndBarriersGEN.Add(endEID) ' This variable does not get reset - used
                            ' to crosscheck in case of infinite loop problem
                            pNoSourceFlowEnds.Add(endEID) 'This variable gets reset each 
                            ' order loop

                            If bConnectTab = True Or bGLPKTables = True Then
                                ' this is for a running tally of connectivity:
                                ' first get the "barrierID" (set in Options by user)
                                '     using the getbarrierid sub which requires the 
                                '     fcid and fid from queryids method
                                pNetElements.QueryIDs(endEID, esriElementType.esriETJunction, iFCID, iFID, iSubID)

                                Dim pIDAndType2 As New IDandType(Nothing, Nothing)
                                pIDAndType2 = GetBarrierID(iFCID, iFID, lBarrierIDs)
                                sFlowEndID = pIDAndType2.BarrID

                                If bConnectTab = True Then
                                    ' TEMPORARY CODE UNTIL DCI MODEL IS UPDATED
                                    If orderLoop = 0 Then
                                        'pBarrierAndDownstreamEID = New BarrierAndDownstreamID(sFlowEndID, "Sink")
                                        ' updated March 14, 2012 to use EID's for connectivity table
                                        '    rather than user-set ID's
                                        pBarrierAndDownstreamEID = New BarrierAndDownstreamID(endEID.ToString, "Sink")
                                    Else
                                        'pBarrierAndDownstreamEID = New BarrierAndDownstreamID(sFlowEndID, sOutID)
                                        ' updated March 14, 2012 to use EID's for connectivity table
                                        '    rather than user-set ID's
                                        pBarrierAndDownstreamEID = New BarrierAndDownstreamID(endEID.ToString, iEID.ToString)

                                    End If

                                    lConnectivity.Add(pBarrierAndDownstreamEID)
                                End If

                                If bGLPKTables = True Then
                                    pGLPKBarrAndDownEID = New GLPKBarrierAndDownstreamEID(endEID, iEID)
                                    lGLPKConnectivity.Add(pGLPKBarrAndDownEID)
                                End If

                            End If

                            'NoSourceFlowEnds will have to
                            ' be changed to NoSourceJncFlowEnds in the future
                            ' and NoSourceEdgFlowEnds to differentiate
                            pNoSourceFlowEndsTemp.Add(endEID) ' This is a temporary variable.
                        End If
                    Next 'flowend element

                    ' if the following are needed then have to do upstream trace
                    If bUpHab = True Or bDCI = True Or bDownHab = True Then

                        'MsgBox("Debug:18")
                        pTraceFlowSolver.FindFlowElements(esriFlowMethod.esriFMUpstream, eFlowElements, pResultJunctions, pResultEdges)

                        If pResultJunctions Is Nothing Then
                            ' junctions were not returned -- create an empty enumeration
                            pEnumNetEIDBuilder = New EnumNetEIDArray
                            pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                            pEnumNetEIDBuilder.ElementType = esriElementType.esriETJunction
                            pResultJunctions = CType(pEnumNetEIDBuilder, IEnumNetEID)
                        End If

                        If pResultEdges Is Nothing Then
                            ' edges were not returned -- create an empty enumeration
                            pEnumNetEIDBuilder = New EnumNetEIDArray
                            pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                            pEnumNetEIDBuilder.ElementType = esriElementType.esriETEdge
                            pResultEdges = CType(pEnumNetEIDBuilder, IEnumNetEID)
                        End If

                        If bUpHab = True Or bDCI = True Or bGLPKTables = True Then
                            ' Get results as selection
                            pNetworkAnalysisExtResults.CreateSelection(pResultJunctions, pResultEdges)

                            ' ============== INTERSECT FEATURES ================
                            ' check if user has hit 'close/cancel'
                            If m_bCancel = True Then
                                backgroundworker1.CancelAsync()
                                backgroundworker1.Dispose()
                                Exit Sub
                            End If
                            If iProgress < 50 Then
                                iProgress = iProgress + 1
                            End If
                            backgroundworker1.ReportProgress(iProgress, "Performing Network Traces (Intersecting Features) " & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                         "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                         "Direction: " & sDirection)

                            'MsgBox("Debug:19")
                            Call IntersectFeatures()
                            'MsgBox("Debug:20")

                            ' ---- EXCLUDE FEATURES -----
                            pEnumLayer.Reset()
                            ' Look at the next layer in the list
                            pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                            Do While Not pFeatureLayer Is Nothing ' these two lines must be separate
                                If pFeatureLayer.Valid = True Then
                                    If pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryLine Or _
                                    pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolygon Or _
                                    pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolyline Then ' or there will be an empty object ref
                                        ExcludeFeatures(pFeatureLayer)
                                    End If
                                End If
                                pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                            Loop
                            ' ---- END EXCLUDE FEATURES -----

                            ' ============ SAVE FOR HIGHLIGHTING ==================
                            ' Get results to display as highlights at end of sub
                            pResultJunctions.Reset()
                            k = 0
                            For k = 0 To pResultJunctions.Count - 1
                                pTotalResultsJunctionsGEN.Add(pResultJunctions.Next)
                            Next
                            pResultEdges.Reset()
                            For k = 0 To pResultEdges.Count - 1
                                pTotalResultsEdgesGEN.Add(pResultEdges.Next)
                            Next

                            ' use results for DCI if needed
                            If bDCI = True Then
                                Call calculateDCIStatistics(lDCIStatsList, lLLayersFieldsDCI, iEID, dBarrierPerm, sNaturalYN, orderLoop)
                            End If

                            If bGLPKTables = True Then
                                Call calculateGLPKStatistics(lGLPKStatsList, lAllLayersFieldsGLPK, iEID, orderLoop)
                            End If

                            ' use results for Upstream habitat if needed
                            If bUpHab = True Then
                                sHabType = "Immediate"
                                sHabDir = "upstream"
                                Call calculateStatistics_2(lHabStatsList, sOutID, iEID, sType, f_sOutID, f_siOutEID, sFlagCheck, sHabType, sHabDir)
                            End If
                            'MsgBox("Debug:20a")

                        End If '  If bUpHab = True Or bDCI = True Or bGLPKTables = True

                        ' need to do a "connected" trace and subtract upstream trace results from it
                        If bDownHab = True Then
                            ' check if user has hit 'close/cancel'
                            If m_bCancel = True Then
                                backgroundworker1.CancelAsync()
                                backgroundworker1.Dispose()
                                Exit Sub
                            End If
                            If iProgress < 50 Then
                                iProgress = iProgress + 1
                            End If
                            backgroundworker1.ReportProgress(iProgress, "Performing Network Traces " & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                         "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                         "Direction: Immediate Downstream ")

                            ' Store upstream elements from last trace to use to subtract from connected 
                            pSubtractUpJunctions = pResultJunctions
                            pSubtractUpEdges = pResultEdges

                            pMap.ClearSelection() ' clear selection

                            'MsgBox("Debug:21")
                            pTraceFlowSolver.FindFlowElements(esriFlowMethod.esriFMConnected, eFlowElements, pResultJunctions, pResultEdges)

                            If pResultJunctions Is Nothing Then
                                ' junctions were not returned -- create an empty enumeration
                                pEnumNetEIDBuilder = New EnumNetEIDArray
                                pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                                pEnumNetEIDBuilder.ElementType = esriElementType.esriETJunction
                                pResultJunctions = CType(pEnumNetEIDBuilder, IEnumNetEID)
                            End If

                            If pResultEdges Is Nothing Then
                                ' edges were not returned -- create an empty enumeration
                                pEnumNetEIDBuilder = New EnumNetEIDArray
                                pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                                pEnumNetEIDBuilder.ElementType = esriElementType.esriETEdge
                                pResultEdges = CType(pEnumNetEIDBuilder, IEnumNetEID)
                            End If

                            pConnectedJunctions = pResultJunctions
                            pConnectedEdges = pResultEdges

                            ' Subtract the upstream edges and junctions from the connected edges and junctions list
                            pDownConnectedJunctions = DownStreamConnected(pSubtractUpJunctions, pConnectedJunctions)
                            pDownConnectedEdges = DownStreamConnected(pSubtractUpEdges, pConnectedEdges)

                            ' Get results as selection
                            'MsgBox("Debug:21")
                            pNetworkAnalysisExtResults.CreateSelection(pDownConnectedJunctions, pDownConnectedEdges)

                            ' Get results to display as highlights at end of sub
                            pDownConnectedJunctions.Reset()
                            k = 0
                            For k = 0 To pDownConnectedJunctions.Count - 1
                                pTotalResultsJunctionsGEN.Add(pDownConnectedJunctions.Next)
                            Next
                            pDownConnectedEdges.Reset()
                            For k = 0 To pDownConnectedEdges.Count - 1
                                pTotalResultsEdgesGEN.Add(pDownConnectedEdges.Next)
                            Next

                            ' ============== INTERSECT FEATURES ================
                            ' check if user has hit 'close/cancel'
                            If m_bCancel = True Then
                                backgroundworker1.CancelAsync()
                                backgroundworker1.Dispose()
                                Exit Sub
                            End If
                            If iProgress < 50 Then
                                iProgress = iProgress + 1
                            End If
                            backgroundworker1.ReportProgress(iProgress, "Performing Network Traces (Intersecting features) " & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                         "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                         "Direction: Immediate Downstream ")

                            'MsgBox("Debug:22")
                            Call IntersectFeatures()
                            'MsgBox("Debug:23")

                            ' ---- EXCLUDE FEATURES -----
                            pEnumLayer.Reset()
                            ' Look at the next layer in the list
                            pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                            Do While Not pFeatureLayer Is Nothing ' these two lines must be separate
                                If pFeatureLayer.Valid = True Then
                                    If pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryLine Or _
                                    pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolygon Or _
                                    pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolyline Then ' or there will be an empty object ref
                                        ExcludeFeatures(pFeatureLayer)
                                    End If
                                End If
                                pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                            Loop
                            ' ---- END EXCLUDE FEATURES -----

                            sHabType = "Immediate"
                            sHabDir = "downstream"

                            'MsgBox("Debug:24")
                            Call calculateStatistics_2(lHabStatsList, sOutID, iEID, sType, f_sOutID, f_siOutEID, sFlagCheck, sHabType, sHabDir)
                            'MsgBox("Debug:25")
                        End If
                    End If  ' bUpHab = True Or bDCI = True Or bDownHab = True 

                    ' If Downstream Path Habitat desired
                    If bPathDownHab = True Then
                        ' check if user has hit 'close/cancel'
                        If m_bCancel = True Then
                            backgroundworker1.CancelAsync()
                            backgroundworker1.Dispose()
                            Exit Sub
                        End If
                        If iProgress < 50 Then
                            iProgress = iProgress + 1
                        End If
                        backgroundworker1.ReportProgress(iProgress, "Performing Network Traces " & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                         "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                         "Direction: Path Downstream ")
                        'MsgBox("Debug:26")
                        pMap.ClearSelection() ' clear selection
                        ' perform downstream trace
                        pTraceFlowSolver.FindFlowElements(esriFlowMethod.esriFMDownstream, eFlowElements, pResultJunctions, pResultEdges)

                        If pResultJunctions Is Nothing Then
                            ' junctions were not returned -- create an empty enumeration
                            pEnumNetEIDBuilder = New EnumNetEIDArray
                            pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                            pEnumNetEIDBuilder.ElementType = esriElementType.esriETJunction
                            pResultJunctions = CType(pEnumNetEIDBuilder, IEnumNetEID)
                        End If

                        If pResultEdges Is Nothing Then
                            ' edges were not returned -- create an empty enumeration
                            pEnumNetEIDBuilder = New EnumNetEIDArray
                            pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                            pEnumNetEIDBuilder.ElementType = esriElementType.esriETEdge
                            pResultEdges = CType(pEnumNetEIDBuilder, IEnumNetEID)
                        End If

                        ' ============ SAVE FOR HIGHLIGHTING ==================
                        ' Get results to display as highlights at end of sub
                        pResultJunctions.Reset()
                        k = 0
                        For k = 0 To pResultJunctions.Count - 1
                            pTotalResultsJunctionsGEN.Add(pResultJunctions.Next)
                        Next
                        pResultEdges.Reset()
                        For k = 0 To pResultEdges.Count - 1
                            pTotalResultsEdgesGEN.Add(pResultEdges.Next)
                        Next

                        ' Get results as selection
                        pNetworkAnalysisExtResults.CreateSelection(pResultJunctions, pResultEdges)

                        ' =================== INTERSECT FEATURES =============
                        ' check if user has hit 'close/cancel'
                        If m_bCancel = True Then
                            backgroundworker1.CancelAsync()
                            backgroundworker1.Dispose()
                            Exit Sub
                        End If
                        If iProgress < 50 Then
                            iProgress = iProgress + 1
                        End If
                        backgroundworker1.ReportProgress(iProgress, "Performing Network Traces (Intersecting features) " & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                         "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                         "Direction: Path Downstream ")
                        'MsgBox("Debug:27")
                        Call IntersectFeatures()
                        'MsgBox("Debug:28")
                        ' ---- EXCLUDE FEATURES -----
                        pEnumLayer.Reset()
                        ' Look at the next layer in the list
                        pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                        Do While Not pFeatureLayer Is Nothing ' these two lines must be separate
                            If pFeatureLayer.Valid = True Then
                                If pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryLine Or _
                                pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolygon Or _
                                pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolyline Then ' or there will be an empty object ref
                                    ExcludeFeatures(pFeatureLayer)
                                End If
                            End If
                            pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                        Loop
                        ' ---- END EXCLUDE FEATURES -----

                        pActiveView.Refresh() ' refresh the view
                        sHabType = "Path"
                        sHabDir = "downstream"
                        'MsgBox("Debug:29")
                        Call calculateStatistics_2(lHabStatsList, sOutID, iEID, sType, f_sOutID, f_siOutEID, sFlagCheck, sHabType, sHabDir)
                        'MsgBox("Debug:30")
                    End If ' Downstream Path Habitat desired

                    ' If any total tables desired clear all barriers and run traces. 
                    If bTotalUpHab = True Or bTotalDownHab = True Then

                        ' check if user has hit 'close/cancel'
                        If m_bCancel = True Then
                            backgroundworker1.CancelAsync()
                            backgroundworker1.Dispose()
                            Exit Sub
                        End If
                        If iProgress < 50 Then
                            iProgress = iProgress + 1
                        End If
                        backgroundworker1.ReportProgress(iProgress, "Performing Network Traces " & ControlChars.NewLine & _
                                         "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                     "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                     "Direction: Total Upstream (used to help get Total Downstream)")
                        'MsgBox("Debug:31")
                        pNetworkAnalysisExtBarriers.ClearBarriers()
                        pTraceFlowSolver = TraceFlowSolverSetup()

                        'prepare the network solver
                        If pTraceFlowSolver Is Nothing Then Exit Sub
                        eFlowElements = esriFlowElements.esriFEJunctionsAndEdges

                        pMap.ClearSelection() ' clear selection
                        ' perform UPSTREAM trace
                        pTraceFlowSolver.FindFlowElements(esriFlowMethod.esriFMUpstream, eFlowElements, pResultJunctions, pResultEdges)

                        If pResultJunctions Is Nothing Then
                            ' junctions were not returned -- create an empty enumeration
                            pEnumNetEIDBuilder = New EnumNetEIDArray
                            pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                            pEnumNetEIDBuilder.ElementType = esriElementType.esriETJunction
                            pResultJunctions = CType(pEnumNetEIDBuilder, IEnumNetEID)
                        End If

                        If pResultEdges Is Nothing Then
                            ' edges were not returned -- create an empty enumeration
                            pEnumNetEIDBuilder = New EnumNetEIDArray
                            pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                            pEnumNetEIDBuilder.ElementType = esriElementType.esriETEdge
                            pResultEdges = CType(pEnumNetEIDBuilder, IEnumNetEID)
                        End If

                        ' ============ SAVE FOR HIGHLIGHTING ==================
                        ' Get results to display as highlights at end of sub
                        pResultJunctions.Reset()
                        k = 0
                        For k = 0 To pResultJunctions.Count - 1
                            pTotalResultsJunctionsGEN.Add(pResultJunctions.Next)
                        Next
                        pResultEdges.Reset()
                        For k = 0 To pResultEdges.Count - 1
                            pTotalResultsEdgesGEN.Add(pResultEdges.Next)
                        Next


                        If bTotalUpHab = True Then

                            ' Get results as selection
                            'MsgBox("Debug:31")
                            pNetworkAnalysisExtResults.CreateSelection(pResultJunctions, pResultEdges)

                            ' check if user has hit 'close/cancel'
                            If m_bCancel = True Then
                                backgroundworker1.CancelAsync()
                                backgroundworker1.Dispose()
                                Exit Sub
                            End If
                            If iProgress < 50 Then
                                iProgress = iProgress + 1
                            End If
                            backgroundworker1.ReportProgress(iProgress, "Performing Network Traces (intersecting features)" & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                         "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                         "Direction: Total Upstream")

                            ' =================== INTERSECT FEATURES =============
                            Call IntersectFeatures()
                            'MsgBox("Debug:32")
                            ' ---- EXCLUDE FEATURES -----
                            pEnumLayer.Reset()
                            ' Look at the next layer in the list
                            pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                            Do While Not pFeatureLayer Is Nothing ' these two lines must be separate
                                If pFeatureLayer.Valid = True Then
                                    If pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryLine Or _
                                    pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolygon Or _
                                    pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolyline Then ' or there will be an empty object ref
                                        ExcludeFeatures(pFeatureLayer)
                                    End If
                                End If
                                pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                            Loop
                            ' ---- END EXCLUDE FEATURES -----

                            pActiveView.Refresh() ' refresh the view
                            sHabType = "Total"
                            sHabDir = "upstream"
                            'MsgBox("Debug:33")
                            Call calculateStatistics_2(lHabStatsList, sOutID, iEID, sType, f_sOutID, f_siOutEID, sFlagCheck, sHabType, sHabDir)
                            'MsgBox("Debug:34")
                        End If

                        If bTotalDownHab = True Then
                            ' check if user has hit 'close/cancel'
                            If m_bCancel = True Then
                                backgroundworker1.CancelAsync()
                                backgroundworker1.Dispose()
                                Exit Sub
                            End If
                            If iProgress < 50 Then
                                iProgress = iProgress + 1
                            End If
                            backgroundworker1.ReportProgress(iProgress, "Performing Network Traces " & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                         "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                         "Direction: Total Downstream (subtracting upstream from 'connected' trace)")
                            'MsgBox("Debug:35")
                            ' Store current results for cross-ref and subtraction.
                            pSubtractUpJunctions = pResultJunctions
                            pSubtractUpEdges = pResultEdges

                            pMap.ClearSelection() ' clear selection

                            ' find connected
                            pTraceFlowSolver.FindFlowElements(esriFlowMethod.esriFMConnected, eFlowElements, pResultJunctions, pResultEdges)

                            If pResultJunctions Is Nothing Then
                                ' junctions were not returned -- create an empty enumeration
                                pEnumNetEIDBuilder = New EnumNetEIDArray
                                pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                                pEnumNetEIDBuilder.ElementType = esriElementType.esriETJunction
                                pResultJunctions = CType(pEnumNetEIDBuilder, IEnumNetEID)
                            End If

                            If pResultEdges Is Nothing Then
                                ' edges were not returned -- create an empty enumeration
                                pEnumNetEIDBuilder = New EnumNetEIDArray
                                pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                                pEnumNetEIDBuilder.ElementType = esriElementType.esriETEdge
                                pResultEdges = CType(pEnumNetEIDBuilder, IEnumNetEID)
                            End If


                            ' ============ SAVE FOR HIGHLIGHTING ==================
                            ' Get results to display as highlights at end of sub
                            pResultJunctions.Reset()
                            k = 0
                            For k = 0 To pResultJunctions.Count - 1
                                pTotalResultsJunctionsGEN.Add(pResultJunctions.Next)
                            Next
                            pResultEdges.Reset()
                            For k = 0 To pResultEdges.Count - 1
                                pTotalResultsEdgesGEN.Add(pResultEdges.Next)
                            Next

                            ' ========= SUBTRACT UPSTREAM FROM ALL CONNECTED =======
                            pConnectedJunctions = pResultJunctions
                            pConnectedEdges = pResultEdges

                            ' Subtract the upstream edges and junctions from the connected edges and junctions list
                            pDownConnectedJunctions = DownStreamConnected(pSubtractUpJunctions, pConnectedJunctions)
                            pDownConnectedEdges = DownStreamConnected(pSubtractUpEdges, pConnectedEdges)


                            ' Get results as selection
                            pNetworkAnalysisExtResults.CreateSelection(pDownConnectedJunctions, pDownConnectedEdges)

                            ' =================== INTERSECT FEATURES =============
                            'MsgBox("Debug:36")
                            Call IntersectFeatures()
                            'MsgBox("Debug:37")
                            ' ---- EXCLUDE FEATURES -----
                            pEnumLayer.Reset()
                            ' Look at the next layer in the list
                            pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                            Do While Not pFeatureLayer Is Nothing ' these two lines must be separate
                                If pFeatureLayer.Valid = True Then
                                    If pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryLine Or _
                                    pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolygon Or _
                                    pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolyline Then ' or there will be an empty object ref
                                        ExcludeFeatures(pFeatureLayer)
                                    End If
                                End If
                                pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                            Loop
                            ' ---- END EXCLUDE FEATURES -----
                            pActiveView.Refresh() ' refresh the view

                            sHabType = "Total"
                            sHabDir = "downstream"
                            'MsgBox("Debug:38")
                            Call calculateStatistics_2(lHabStatsList, sOutID, iEID, sType, f_sOutID, f_siOutEID, sFlagCheck, sHabType, sHabDir)
                            'MsgBox("Debug:39")
                        End If
                    End If ' bTotalUpHab = True Or bTotalDownHab = True 

                    If bTotalPathDownHab = True Then
                        ' check if user has hit 'close/cancel'
                        If m_bCancel = True Then
                            backgroundworker1.CancelAsync()
                            backgroundworker1.Dispose()
                            Exit Sub
                        End If
                        If iProgress < 50 Then
                            iProgress = iProgress + 1
                        End If
                        backgroundworker1.ReportProgress(iProgress, "Performing Network Traces " & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count) & ControlChars.NewLine & _
                                         "Current Barrier 'Order': " & orderLoop.ToString & " of " & iOrderNum.ToString & " (max)." & ControlChars.NewLine & _
                                         "Direction: Path Downstream")
                        'MsgBox("Debug:40")
                        pMap.ClearSelection() ' clear selection

                        pNetworkAnalysisExtBarriers.ClearBarriers()
                        pTraceFlowSolver = TraceFlowSolverSetup()

                        ' perform UPSTREAM trace
                        pTraceFlowSolver.FindFlowElements(esriFlowMethod.esriFMDownstream, eFlowElements, pResultJunctions, pResultEdges)

                        If pResultJunctions Is Nothing Then
                            ' junctions were not returned -- create an empty enumeration
                            pEnumNetEIDBuilder = New EnumNetEIDArray
                            pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                            pEnumNetEIDBuilder.ElementType = esriElementType.esriETJunction
                            pResultJunctions = CType(pEnumNetEIDBuilder, IEnumNetEID)
                        End If

                        If pResultEdges Is Nothing Then
                            ' edges were not returned -- create an empty enumeration
                            pEnumNetEIDBuilder = New EnumNetEIDArray
                            pEnumNetEIDBuilder.Network = pNetworkAnalysisExt.CurrentNetwork.Network
                            pEnumNetEIDBuilder.ElementType = esriElementType.esriETEdge
                            pResultEdges = CType(pEnumNetEIDBuilder, IEnumNetEID)
                        End If

                        ' ============ SAVE FOR HIGHLIGHTING ==================
                        ' Get results to display as highlights at end of sub
                        pResultJunctions.Reset()
                        k = 0
                        For k = 0 To pResultJunctions.Count - 1
                            pTotalResultsJunctionsGEN.Add(pResultJunctions.Next)
                        Next
                        pResultEdges.Reset()
                        For k = 0 To pResultEdges.Count - 1
                            pTotalResultsEdgesGEN.Add(pResultEdges.Next)
                        Next

                        ' Get results as selection
                        pNetworkAnalysisExtResults.CreateSelection(pResultJunctions, pResultEdges)
                        ' =================== INTERSECT FEATURES =============
                        'MsgBox("Debug:41")
                        Call IntersectFeatures()
                        'MsgBox("Debug:42")
                        ' ---- EXCLUDE FEATURES -----
                        pEnumLayer.Reset()
                        ' Look at the next layer in the list
                        pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                        Do While Not pFeatureLayer Is Nothing ' these two lines must be separate
                            If pFeatureLayer.Valid = True Then
                                If pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryLine Or _
                                pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolygon Or _
                                pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolyline Then ' or there will be an empty object ref
                                    ExcludeFeatures(pFeatureLayer)
                                End If
                            End If
                            pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
                        Loop
                        ' ---- END EXCLUDE FEATURES -----

                        pActiveView.Refresh() ' refresh the view
                        sHabType = "Total Path"
                        sHabDir = "downstream"
                        'MsgBox("Debug:43")
                        Call calculateStatistics_2(lHabStatsList, sOutID, iEID, sType, f_sOutID, f_siOutEID, sFlagCheck, sHabType, sHabDir)
                        'MsgBox("Debug:44")
                    End If ' bTotalPathDownHab = true


                    'End If ' calculate total impacted
                    pNetworkAnalysisExtFlags.ClearFlags()   ' clear the flags

                    ' clear selection
                    pMap.ClearSelection()

                    ' refresh the view
                    pActiveView.Refresh()

                Next 'flag
                ' ================= END RUN TRACE ON ONE FLAG AT A TIME =================

                ' change the flowEndJunctions to an array
                ' that no longer has sources, or non-barriers.
                pFlowEndJunctions = New EnumNetEIDArray
                pFlowEndJunctions = CType(pNoSourceFlowEnds, IEnumNetEID)

                ' Store the first flow end elements
                ' THESE VARS MAY NOT BE USED ANYMORE
                If orderLoop = 0 And sFlagCheck = "nonbarr" Then
                    pFirstJunctionBarriers = pFlowEndJunctions
                ElseIf orderLoop = 0 And sFlagCheck = "barriers" Then
                    pFirstJunctionBarriers = pOriginaljuncFlagsList
                End If

                pFirstEdgeBarriers = pFlowEndEdges

                ' Clear the barriers.
                pNetworkAnalysisExtBarriers.ClearBarriers()

                'End If ' orderloop = x
            Next ' orderloop

            iProgress = 50

            ' ======= CREATE and WRITE TO TABLES ========
            ' Use the stats object list to write 
            ' rows to the table. 
            If bDBF = True Then
                'MsgBox("Debug:45")
                ' check if user has hit 'close/cancel'
                If m_bCancel = True Then
                    backgroundworker1.CancelAsync()
                    backgroundworker1.Dispose()
                    Exit Sub
                End If
                If iProgress < 70 Then
                    iProgress = iProgress + 1
                End If
                backgroundworker1.ReportProgress(iProgress, "Creating Output Tables" & ControlChars.NewLine & _
                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count))

                ' ============== DCI, Habitat aND Metric Table Name ========
                If bDCI = True Then
                    ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Creating Output Tables" & ControlChars.NewLine & _
                                                                 "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count & ControlChars.NewLine & _
                                                                                                                             "Table: DCI Analysis"))
                    sDCITableName = TableName("DCI", pFWorkspace, sPrefix)
                    'MsgBox("Debug:46")
                    PrepDCIOutTable(sDCITableName, pFWorkspace)
                End If

                If bConnectTab = True Then
                    ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Creating Output Tables" & ControlChars.NewLine & _
                                                                "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count & ControlChars.NewLine & _
                                                                                                                            "Table: Connectivity"))
                    'MsgBox("Debug:47")
                    sConnectTabName = TableName("connectivity", pFWorkspace, sPrefix)

                    If sConnectTabName = "Cancel" Then
                        Exit Sub
                    End If
                    PrepConnectivityTables(pFWorkspace, sConnectTabName)
                End If

                If bGLPKTables = True Then
                    ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Creating Output Tables" & ControlChars.NewLine & _
                                                               "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count & ControlChars.NewLine & _
                                                                                                                           "Table: Habitat (For GLPK Optimization)"))

                    'MsgBox("Debug:48")
                    sGLPKHabitatTableName = TableName("GLPKHabitat", pFWorkspace, sPrefix)
                    PrepGLPKHabTable(sGLPKHabitatTableName, pFWorkspace)

                    ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Creating Output Tables" & ControlChars.NewLine & _
                                                               "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count & ControlChars.NewLine & _
                                                                                                                           "Table: Options (For GLPK Optimization)"))

                    'MsgBox("Debug:49")
                    sGLPKOptionsTableName = TableName("GLPKOptions", pFWorkspace, sPrefix)
                    PrepGLPKOptionsTable(sGLPKOptionsTableName, pFWorkspace)

                    ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Creating Output Tables" & ControlChars.NewLine & _
                                                               "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count & ControlChars.NewLine & _
                                                                                                                           "Table: Connectivity (For GLPK Optimization)"))
                    sGLPKConnectTabName = TableName("GLPKconnectivity", pFWorkspace, sPrefix)
                    If sGLPKConnectTabName = "Cancel" Then
                        Exit Sub
                    End If
                    'MsgBox("Debug:50")
                    PrepGLPKConnectivityTable(pFWorkspace, sGLPKConnectTabName)
                End If

                ' If this is the first flag visited - don't need another table 
                ' for every flag visited - can append if it's the second flag or higher. 
                If i = 0 Then
                    ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Creating Output Tables" & ControlChars.NewLine & _
                                                              "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count & ControlChars.NewLine & _
                                                                                                                          "Table: Habitat"))
                    'MsgBox("Debug:51")
                    sTableType = "Habitat"
                    sHabTableName = TableName(sTableType, pFWorkspace, sPrefix)
                    Call PrepHabitatTable(sHabTableName, pFWorkspace)

                    ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Creating Output Tables" & ControlChars.NewLine & _
                                                              "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count & ControlChars.NewLine & _
                                                                                                                          "Table: Metrics"))
                    sTableType = "Metrics"
                    sMetricTableName = TableName(sTableType, pFWorkspace, sPrefix)
                    Call PrepMetricTable(sMetricTableName, pFWorkspace)
                    'MsgBox("Debug:52")

                End If
                ' ============== End New DCI, Hab and Metric Table Name ==========



                If bConnectTab = True Then
                    ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Writing To Output Tables" & ControlChars.NewLine & _
                                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count & ControlChars.NewLine & _
                                                                                                                         "Table: Connectivity"))
                    'MsgBox("Debug:53")
                    pTable = pFWorkspace.OpenTable(sConnectTabName)
                    j = 0
                    For j = 0 To lConnectivity.Count - 1
                        pRowBuffer = pTable.CreateRowBuffer
                        pRowBuffer.Value(1) = lConnectivity(j).BarrID
                        pRowBuffer.Value(2) = lConnectivity(j).DownstreamBarrierID

                        pCursor = pTable.Insert(True)
                        pCursor.InsertRow(pRowBuffer)
                    Next
                End If

                'If bGLPKTables = True Then
                '    pTabl2e = pFWorkspace.OpenTable(sConnectTabName)
                '    j = 0
                '    For j = 0 To lConnectivity.Count - 1
                '        pRowBuffer = pTable.CreateRowBuffer
                '        pRowBuffer.Value(2) = lConnectivity(j).DownstreamBarrierID
                '        pRowBuffer.Value(1) = lConnectivity(j).BarrID

                '        pCursor = pTable.Insert(True)
                '        pCursor.InsertRow(pRowBuffer)
                '    Next
                'End If


                If bDCI = True Then
                    ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Writing To Output Tables" & ControlChars.NewLine & _
                                                             "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count & ControlChars.NewLine & _
                                                                                                                         "Table: DCI Statistics (for output to 'R' Stats Software)"))
                    'MsgBox("Debug:54")
                    ' ==== BEGIN WRITE TO DCI TABLE =====
                    ' convert to generic
                    'Dim lConnectTabName As New List(Of String)
                    'lConnectTabName.Add(sConnectTabName)
                    pTable = pFWorkspace.OpenTable(sDCITableName)
                    j = 0
                    bNoPerm = False ' NoPerm false means there aren't any barriers encountered in 
                    ' this list yet that have less than one permeability
                    For j = 0 To lDCIStatsList.Count - 1
                        pRowBuffer = pTable.CreateRowBuffer
                        pRowBuffer.Value(1) = lDCIStatsList(j).Barrier
                        pRowBuffer.Value(2) = lDCIStatsList(j).Quantity
                        pRowBuffer.Value(3) = lDCIStatsList(j).BarrierPerm
                        If lDCIStatsList(j).BarrierPerm < 1 Then
                            bNoPerm = True
                        End If
                        pRowBuffer.Value(4) = lDCIStatsList(j).BarrierYN

                        pCursor = pTable.Insert(True)
                        pCursor.InsertRow(pRowBuffer)
                    Next
                    ' ===== END WRITE TO DCI TABLE =======

                    ' ====== BEGIN DCI CALCULATION ======
                    ' TEMPORARY CHECK - if DCI Table has no rows then the 
                    ' DCI model will fail.  If there are no barriers then 
                    ' in UpdateResultsDCI function the DCIp and DCId will be
                    ' set to 100.   ' check if user has hit 'close/cancel'
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Calculating DCI" & ControlChars.NewLine & _
                                                            "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count))

                    Dim iDCIRowCountTEMP As Integer
                    iDCIRowCountTEMP = pTable.RowCount(Nothing)

                    ' this code is awkward 
                    If iDCIRowCountTEMP = 0 Or bNoPerm = False Then
                        UpdateResultsDCI(iDCIRowCountTEMP, dDCIp, dDCId, bNaturalY)
                    ElseIf iDCIRowCountTEMP > 0 Then
                        DCIShellCall(sDCITableName, sConnectTabName, pFWorkspace)
                        UpdateResultsDCI(iDCIRowCountTEMP, dDCIp, dDCId, bNaturalY)
                    End If

                    ' Insert a row into the Metrics Object List
                    ' using pair of ID and Type for flag saved earlier
                    pMetricsObject = New MetricsObject(f_sOutID, f_siOutEID, f_sOutID, f_siOutEID, f_sType, "DCIp", dDCIp)
                    lMetricsObject.Add(pMetricsObject)
                    pMetricsObject = New MetricsObject(f_sOutID, f_siOutEID, f_sOutID, f_siOutEID, f_sType, "DCId", dDCId)
                    lMetricsObject.Add(pMetricsObject)

                    ' Update the metrics object with the sectional DCI
                    If bDCISectional = True Then
                        ' check if user has hit 'close/cancel'
                        If m_bCancel = True Then
                            backgroundworker1.CancelAsync()
                            backgroundworker1.Dispose()
                            Exit Sub
                        End If
                        If iProgress < 70 Then
                            iProgress = iProgress + 1
                        End If
                        backgroundworker1.ReportProgress(iProgress, "Calculating DCI Sectional" & ControlChars.NewLine & _
                                                                "User Flag " & (i + 1).ToString & " of " & Convert.ToString(pOriginaljuncFlagsList.Count))
                        'MsgBox("Debug:55")
                        ' read output table if it exists
                        ' and add sectional DCIs to the metrics object
                        'UpdateResultsDCISectional()

                        ' Read the DCI Model Directory from the document properties
                        Dim sDCIModelDir As String = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sDCIModelDir"))
                        'Dim bDCISectional As Boolean = Convert.ToBoolean(m_FiPEX__1.pPropset.GetProperty("dcisectionalyn"))

                        ' Read the file and return two values - line one and line two from output
                        Dim ErrInfo As String

                        Dim objReader As StreamReader
                        Dim sLine As String
                        Dim iPosit As Integer
                        Dim dDCIs As Double
                        Dim iBarrierEID As Integer

                        Dim iLoopCount As Integer = 0
                        iLoopCount = 0
                        Try
                            If iDCIRowCountTEMP > 1 Then
                                objReader = New StreamReader(sDCIModelDir + "/DCI.all.sections.csv")
                                Do Until objReader.EndOfStream = True
                                    iLoopCount = iLoopCount + 1
                                    sLine = objReader.ReadLine()
                                    ' If the first line says ERROR then write this, otherwise write nothing
                                    ' because the first line of a successful DCI will say "Value" - skip.  
                                    ' Using FINDME to get to the position at top of results box.  
                                    If iLoopCount = 1 Then

                                        If sLine = "ERROR" Then
                                            Exit Do
                                        End If
                                    Else
                                        ' separate barrier from DCIs value
                                        Dim sLineArray(1) As String
                                        sLineArray = sLine.Split(",")

                                        ' separate barrier label 
                                        sLineArray(0) = sLineArray(0).Trim("""")
                                        If sLineArray(0) <> "sink" Then
                                            sLineArray(0) = sLineArray(0).TrimEnd("s")
                                            sLineArray(0) = sLineArray(0).TrimEnd("_")
                                            iBarrierEID = Convert.ToInt16(sLineArray(0))
                                        Else
                                            iBarrierEID = f_siOutEID
                                        End If
                                        dDCIs = Convert.ToDouble(sLineArray(1))

                                        'Have to retrieve the barrier label now, too
                                        pNetElements.QueryIDs(iBarrierEID, esriElementType.esriETJunction, iFCID, iFID, iSubID)
                                        pIDAndType = New IDandType(Nothing, Nothing)
                                        pIDAndType = GetBarrierID(iFCID, iFID, lBarrierIDs)
                                        sOutID = pIDAndType.BarrID

                                        ' Insert new metric into metrics object list
                                        pMetricsObject = New MetricsObject(f_sOutID, f_siOutEID, sOutID, iBarrierEID, f_sType, "DCI Sectional", Math.Round(dDCIs, 2))
                                        lMetricsObject.Add(pMetricsObject)
                                    End If
                                Loop
                                objReader.Close()
                            Else ' if there are no barriers encountered
                                dDCIs = 100
                            End If
                        Catch Ex As Exception
                            ErrInfo = Ex.Message
                            MsgBox("Error reading Sectional DCI output file. " + ErrInfo)
                        End Try

                    End If ' output to DCI sectional = True
                End If 'output to DCI = True
                ' ======= END DCI CALCULATION =======

                If bGLPKTables = True Then
                    ' ===== BEGIN GLPK TABLES WRITE =====
                    'MsgBox("Debug:56")
                    pTable = pFWorkspace.OpenTable(sGLPKHabitatTableName)
                    j = 0
                    'bNoPe2wrm = False ' NoPerm false means there aren't any barriers encountered in 
                    '' this list yet that have less than one permeability
                    For j = 0 To lGLPKStatsList.Count - 1
                        pRowBuffer = pTable.CreateRowBuffer
                        pRowBuffer.Value(0) = lGLPKStatsList(j).Barrier
                        pRowBuffer.Value(1) = Math.Round(lGLPKStatsList(j).Quantity)
                        pCursor = pTable.Insert(True)
                        pCursor.InsertRow(pRowBuffer)
                    Next

                    pTable = pFWorkspace.OpenTable(sGLPKOptionsTableName)
                    'lGLPKUniqueEIDs = New List(Of Integer)

                    j = 0
                    For j = 0 To lGLPKOptionsList.Count - 1

                        'If Not lGLPKUniqueEIDs.Contains(lGLPKOptionsList(j).BarrierEID) Then
                        '    lGLPKUniqueEIDs.Add(lGLPKOptionsList(j).BarrierEID)
                        'End If
                        If lGLPKOptionsList(j).BarrierPerm <> 9999 And lGLPKOptionsList(j).OptionCost <> 9999 Then
                            pRowBuffer = pTable.CreateRowBuffer
                            pRowBuffer.Value(0) = lGLPKOptionsList(j).BarrierEID
                            pRowBuffer.Value(1) = lGLPKOptionsList(j).OptionNum
                            ' keep track of max options for use in input to GLPK Model
                            If iMaxOptionNum < lGLPKOptionsList(j).OptionNum Then
                                iMaxOptionNum = lGLPKOptionsList(j).OptionNum
                            End If
                            pRowBuffer.Value(2) = Math.Round(lGLPKOptionsList(j).BarrierPerm, 2)
                            'pRowBuffer.Value(3) = Math.Round(lGLPKOptionsList(j).OptionCost, 2)
                            pRowBuffer.Value(3) = Math.Round(lGLPKOptionsList(j).OptionCost)
                            pCursor = pTable.Insert(True)
                            pCursor.InsertRow(pRowBuffer)

                        End If
                    Next

                    'j = 0
                    'For j = 0 To lGLPKUniqueEIDs.Count - 1
                    '    pRowBuffer = pTable.CreateRowBuffer
                    '    pRowBuffer.Value(0) = lGLPKOptionsList(j).BarrierEID
                    '    pRowBuffer.Value(1) = 1
                    '    pRowBuffer.Value(2) = Math.Round(lGLPKOptionsList(j).BarrierPerm, 2)
                    '    pRowBuffer.Value(3) = 0

                    '    pCursor = pTable.Insert(True)
                    '    pCursor.InsertRow(pRowBuffer)
                    'Next

                    pTable = pFWorkspace.OpenTable(sGLPKConnectTabName)
                    j = 0
                    For j = 0 To lGLPKConnectivity.Count - 1
                        pRowBuffer = pTable.CreateRowBuffer
                        pRowBuffer.Value(0) = lGLPKConnectivity(j).DownstreamBarrierEID
                        pRowBuffer.Value(1) = lGLPKConnectivity(j).BarrEID
                        pRowBuffer.Value(2) = 1

                        pCursor = pTable.Insert(True)
                        pCursor.InsertRow(pRowBuffer)
                    Next

                    ' ===== END GLPK TABLES WRITE =======

                    ' ===== BEGIN GLPK CALCULATION =====
                    ' check if user has hit 'close/cancel'
                    'MsgBox("Debug:57")
                    If m_bCancel = True Then
                        backgroundworker1.CancelAsync()
                        backgroundworker1.Dispose()
                        Exit Sub
                    End If
                    If iProgress < 70 Then
                        iProgress = iProgress + 1
                    End If
                    backgroundworker1.ReportProgress(iProgress, "Performing Optimization Analysis" & ControlChars.NewLine & _
                                                     "User Flag " & (i + 1).ToString & " of " & (pOriginaljuncFlagsList.Count).ToString)

                    GLPKShellCall(sGLPKHabitatTableName, sGLPKOptionsTableName, sGLPKConnectTabName, iMaxOptionNum, f_siOutEID, pFWorkspace, iProgress)
                    'MsgBox("Debug:58")
                End If ' GLPK is on
                ' ===== END GLPK CALCULATION =======


            End If ' output to dbf = true

            ' REset barriers?
            ' clear current barriers
            pNetworkAnalysisExtBarriers.ClearBarriers()

            'pEdgeFlagDisplay = New IEdgeFlagDisplay
            '               Reset things the way the user had them
            ' ========================= RESET BARRIERS ===========================
            'MsgBox("Debug:59")
            m = 0
            pOriginalBarriersList.Reset()
            For m = 0 To pOriginalBarriersList.Count - 1
                bEID = pOriginalBarriersList.Next
                pNetElements.QueryIDs(bEID, esriElementType.esriETJunction, bFCID, bFID, bSubID)

                ' Display the barriers as a JunctionFlagDisplay type
                pFlagDisplay = New JunctionFlagDisplay
                pSymbol = CType(pBarrierSymbol, ISymbol)
                With pFlagDisplay
                    .FeatureClassID = bFCID
                    .FID = bFID
                    .Geometry = pGeometricNetwork.GeometryForJunctionEID(bEID)
                    .Symbol = pSymbol
                End With

                ' Add the flags to the logical network
                pJuncFlagDisplay = CType(pFlagDisplay, IJunctionFlagDisplay)
                pNetworkAnalysisExtBarriers.AddJunctionBarrier(pJuncFlagDisplay)
            Next
            ' ====================== END RESET BARRIERS ===========================

        Next ' Flag /sink

        'MsgBox("Debug:60")
        If bDBF = True Then
            ' check if user has hit 'close/cancel'
            If m_bCancel = True Then
                backgroundworker1.CancelAsync()
                backgroundworker1.Dispose()
                Exit Sub
            End If
            backgroundworker1.ReportProgress(iProgress + 10, "Writing to DBF Tables")

            ' ================ BEGIN WRITE TO METRICS TABLE ===============
            ' Insert DCI values into the 'Metrics' table
            pTable = pFWorkspace.OpenTable(sMetricTableName)
            j = 0
            For j = 0 To lMetricsObject.Count - 1

                pRowBuffer = pTable.CreateRowBuffer
                pRowBuffer.Value(1) = lMetricsObject(j).Sink
                pRowBuffer.Value(2) = lMetricsObject(j).SinkEID
                pRowBuffer.Value(3) = lMetricsObject(j).ID
                pRowBuffer.Value(4) = lMetricsObject(j).BarrEID
                pRowBuffer.Value(5) = lMetricsObject(j).Type
                pRowBuffer.Value(6) = lMetricsObject(j).MetricName
                pRowBuffer.Value(7) = lMetricsObject(j).Metric

                pCursor = pTable.Insert(True)
                pCursor.InsertRow(pRowBuffer)

            Next
            ' ============ END INSERT DCI's to METRICS TABLE ==================
            'MsgBox("Debug:61")
            ' ============ BEGIN INSERT STATS INTO HABITAT TABLES =============
            pTable = pFWorkspace.OpenTable(sHabTableName)
            j = 0
            For j = 0 To lHabStatsList.Count - 1

                pRowBuffer = pTable.CreateRowBuffer
                pRowBuffer.Value(1) = lHabStatsList(j).Sink
                pRowBuffer.Value(2) = lHabStatsList(j).SinkEID
                pRowBuffer.Value(3) = lHabStatsList(j).bID
                pRowBuffer.Value(4) = lHabStatsList(j).bEID
                pRowBuffer.Value(5) = lHabStatsList(j).bType
                pRowBuffer.Value(6) = lHabStatsList(j).Layer
                pRowBuffer.Value(7) = lHabStatsList(j).Direction
                pRowBuffer.Value(8) = lHabStatsList(j).TotalImmedPath
                pRowBuffer.Value(9) = lHabStatsList(j).UniqueClass
                pRowBuffer.Value(10) = lHabStatsList(j).ClassName
                pRowBuffer.Value(11) = lHabStatsList(j).Quantity
                pRowBuffer.Value(12) = lHabStatsList(j).Unit

                pCursor = pTable.Insert(True)
                pCursor.InsertRow(pRowBuffer)
            Next
        End If ' write to DBF is True

        ' ======== END WRITE TO TABLES ====

        ' clear current barriers
        pNetworkAnalysisExtBarriers.ClearBarriers()

        Dim pEdgeFlagDisplay As IEdgeFlagDisplay

        '               Reset things the way the user had them
        ' ========================= RESET BARRIERS ===========================
        ' check if user has hit 'close/cancel'
        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        backgroundworker1.ReportProgress(iProgress + 10, "Resetting Flags And Barriers")

        m = 0
        pOriginalBarriersList.Reset()
        For m = 0 To pOriginalBarriersList.Count - 1
            bEID = pOriginalBarriersList.Next
            pNetElements.QueryIDs(bEID, esriElementType.esriETJunction, bFCID, bFID, bSubID)

            ' Display the barriers as a JunctionFlagDisplay type
            pFlagDisplay = New JunctionFlagDisplay
            pSymbol = CType(pBarrierSymbol, ISymbol)
            With pFlagDisplay
                .FeatureClassID = bFCID
                .FID = bFID
                .Geometry = pGeometricNetwork.GeometryForJunctionEID(bEID)
                .Symbol = pSymbol
            End With

            ' Add the flags to the logical network
            pJuncFlagDisplay = CType(pFlagDisplay, IJunctionFlagDisplay)
            pNetworkAnalysisExtBarriers.AddJunctionBarrier(pJuncFlagDisplay)
        Next
        ' ====================== END RESET BARRIERS ===========================
        'MsgBox("Debug:62")
        ' Clear current flags
        pNetworkAnalysisExtFlags.ClearFlags()

        ' ======================== RESET FLAGS ================================
        ' restore all EDGE flags
        m = 0
        pOriginalEdgeFlagsList.Reset()
        For m = 0 To pOriginalEdgeFlagsList.Count - 1

            iEID = pOriginalEdgeFlagsList.Next
            ' Query the corresponding user ID's to the element ID
            pNetElements.QueryIDs(iEID, esriElementType.esriETEdge, iFCID, iFID, iSubID)

            ' Display the flags as a JunfctionFlagDisplay type
            pFlagDisplay = New EdgeFlagDisplay
            pSymbol = CType(pFlagSymbol, ISymbol)
            With pFlagDisplay
                .FeatureClassID = iFCID
                .FID = iFID
                .Geometry = pGeometricNetwork.GeometryForEdgeEID(iEID)
                .Symbol = pSymbol
            End With

            ' Add the flags to the logical network
            pEdgeFlagDisplay = CType(pFlagDisplay, IEdgeFlagDisplay)
            pNetworkAnalysisExtFlags.AddEdgeFlag(pEdgeFlagDisplay)
        Next

        ' restore all JUNCTION Flags
        m = 0
        pOriginaljuncFlagsList.Reset()
        For m = 0 To pOriginaljuncFlagsList.Count - 1

            iEID = pOriginaljuncFlagsList.Next
            ' Query the corresponding user ID's to the element ID
            pNetElements.QueryIDs(iEID, esriElementType.esriETJunction, iFCID, iFID, iSubID)

            ' Display the flags as a JunfctionFlagDisplay type
            pFlagDisplay = New JunctionFlagDisplay
            pSymbol = CType(pFlagSymbol, ISymbol)
            With pFlagDisplay
                .FeatureClassID = iFCID
                .FID = iFID
                .Geometry = pGeometricNetwork.GeometryForJunctionEID(iEID)
                .Symbol = pSymbol
            End With

            ' Add the flags to the logical network
            pJuncFlagDisplay = CType(pFlagDisplay, IJunctionFlagDisplay)
            pNetworkAnalysisExtFlags.AddJunctionFlag(pJuncFlagDisplay)

        Next

        'MsgBox("Debug:63")
        ' Create a result highlight of all areas traced
        pTotalResultsEdges = CType(pTotalResultsEdgesGEN, IEnumNetEID)
        pTotalResultsJunctions = CType(pTotalResultsJunctionsGEN, IEnumNetEID)
        pNetworkAnalysisExtResults.ResultsAsSelection = False
        pNetworkAnalysisExtResults.SetResults(pTotalResultsJunctions, pTotalResultsEdges)
        pNetworkAnalysisExtResults.ResultsAsSelection = True

        ' =========================== END RESET FLAGS =====================
        ' Bring results form to front
        'pResultsForm.BringToFront()
        'pResultsForm.txtRichResults.Select(0, 0)
        EndTime = DateTime.Now
        'pResultsForm.lblBeginTime.Text = "Begin Time: " & BeginTime
        'pResultsForm.lblEndTime.Text = "End Time: " & EndTime

        Dim TotalTime As TimeSpan
        TotalTime = EndTime - BeginTime

        'pResultsForm.lblTotalTime.Text = "Total Time: " & TotalTime.Hours & "hrs " & TotalTime.Minutes & "minutes " & TotalTime.Seconds & "seconds"
        'pResultsForm.lblDirection.Text = "Analysis Direction: " + sDirection
        'If iOrderNum <> 999 Then
        '    'pResultsForm.lblOrder.Text = "Order of Analysis: " & CStr(iOrderNum)
        'Else
        '    'pResultsForm.lblOrder.Text = "Order of Analysis: Max"
        'End If

        'If Not pAllFlowEndBarriers Is Nothing Then
        '    If pAllFlowEndBarriers.Count <> 0 Then
        '        pResultsForm.lblNumBarriers.Text = "Number of Barriers Analysed: " & CStr(pAllFlowEndBarriers.Count + pOriginaljuncFlagsList.Count)
        '    Else
        '        pResultsForm.lblNumBarriers.Text = "Number of Barriers Analysed: 1"
        '    End If
        'End If

        ' ================== BEGIN WRITE TO OUTPUT FORM =================
        'MsgBox("Debug:64")
        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        backgroundworker1.ReportProgress(70, "Prepping Output Form")

        ' Output Form (will replace dockable window)
        Dim pResultsForm3 As New FiPEX_AddIn_dotNet35_2.frmResults_3
        pResultsForm3.Show()

        'Dim table As DataTable = New DataTable("Summary Results")
        'Dim column As DataColumn = New DataColumn("Sink ID", GetType(System.String))
        'Table.Columns.Add(column)

        'column = New DataColumn("bID", GetType(System.String))
        'table.Columns.Add(column)
        'column = New DataColumn("Type", GetType(System.String))
        'table.Columns.Add(column)

        ' the habitat stats list contains quantities for each class used
        ' if classes are used.  Otherwise they contain totals.  
        ' will need to re-read user settings in order to determine what CAN go into 
        ' the output.

        ' Logic Flow's gotta be - check our settings and what traces are being done. 
        ' give the user the available options
        ' given their choice determine how the summary table is made.  

        ' If ANY of the habitat trace types are checked, then the Habstatslist will have content. 
        ' Otherwise just the MetricsStatsObject will no matter what

        ' CASE 1: User wants classes, user wants totals.  
        ' So if the user wants to include classes in their output summary table
        ' then the classes can be taken from lHabStatsList and 
        ' IF the user is calculating DCI then 
        ' the total value can be grabbed from the lDCIStatList object. 
        ' However, in this case (user WANTS classes included in output) the 
        '  can be taken from the DCI hab list and probably SHOULD be because
        ' it's being looped through anyway - why loop through a second list? just
        ' grab a running total/tally from the first list as we move through.

        ' Hab stats will NOT be used if no traces are checked, but at least one always should be 

        ' Need to check IF there are HABITAT CLASSES set.
        '  YES
        '     LOOP through all columns
        '       check IF HAB CLASS is there
        '         NO
        '           ADD it as a COLUMN
        '       
        ' For now, only the total habitat will be included in the output
        ' for area and length. 
        '  If the user is using classes then they will have to be summed
        ' no matter what, it will have to be summed for each trace type done.  

        ' The easiest way to is to check the length of each object
        ' if it's not empty, then use it. 

        Dim pSinkAndDCIS As New SinkandDCIs(Nothing, Nothing, Nothing, Nothing)
        Dim lSinkAndDCIS As New List(Of SinkandDCIs)
        Dim pSinkIDAndTypes As New SinkandTypes(Nothing, Nothing, Nothing)
        Dim lSinkIDandTypes As New List(Of SinkandTypes)


        i = 0
        Dim bSinkThere, bDCIpMatch, bDCIdMatch, bEntered As Boolean
        Dim row As DataRow
        'Dim pSinkTable As DataTable = New DataTable("Sink Table")

        'column = New DataColumn("Sink", GetType(System.String))
        'pSinkTable.Columns.Add(column)
        ''pSinkTable.PrimaryKey = column
        'column = New DataColumn("Type", GetType(System.String))
        'pSinkTable.Columns.Add(column)


        ' this bit gets a list of the unique sinks from the 
        ' metrics object list
        ' and it populates a datatable with unique sinks list
        For i = 0 To lMetricsObject.Count - 1
            j = 0
            bSinkThere = False
            For j = 0 To lSinkIDandTypes.Count - 1
                If lSinkIDandTypes(j).SinkEID = lMetricsObject(i).SinkEID Then
                    bSinkThere = True
                End If
            Next
            If bSinkThere = False Then
                pSinkIDAndTypes = New SinkandTypes(lMetricsObject(i).SinkEID, lMetricsObject(i).Sink, lMetricsObject(i).Type)
                lSinkIDandTypes.Add(pSinkIDAndTypes)
                'row = pSinkTable.NewRow()
                'row.ItemArray = New Object() {lMetricsObject(i).SinkEID, lMetricsObject(i).Type}
                'pSinkTable.Rows.Add(row)
            End If
        Next

        ' ===================================
        'lHabStatsList

        ' = lHabStatsList(j).Sink
        ' = lHabStatsList(j).bID
        ' = lHabStatsList(j).bType
        ' = lHabStatsList(j).Layer
        ' = lHabStatsList(j).Direction
        ' = lHabStatsList(j).TotalImmedPath
        ' = lHabStatsList(j).UniqueClass
        ' = lHabStatsList(j).ClassName
        ' = lHabStatsList(j).Quantity
        ' = lHabStatsList(j).Unit


        'Dim pMetricsTable As DataTable = New DataTable("Metrics Table")

        'Dim sTempstring As String
        'If bDCI = True Then
        '    column = New DataColumn("DCIp", GetType(System.Double))
        '    table.Columns.Add(column)
        '    column = New DataColumn("DCId", GetType(System.Double))
        '    table.Columns.Add(column)

        '    column = New DataColumn("Sink", GetType(System.String))
        '    pMetricsTable.Columns.Add(column)
        '    column = New DataColumn("DCIp", GetType(System.Double))
        '    pMetricsTable.Columns.Add(column)
        '    column = New DataColumn("DCId", GetType(System.Double))
        '    pMetricsTable.Columns.Add(column)

        '    i = 0
        '    For i = 0 To lSinkIDandTypes.Count - 1
        '        j = 0
        '        bDCIpMatch = False
        '        bDCIdMatch = False
        '        For j = 0 To lMetricsObject.Count - 1

        '            If lMetricsObject(j).ID = lSinkIDandTypes(i).SinkID Then
        '                sTempstring = lMetricsObject(j).MetricName
        '                If lMetricsObject(j).MetricName = "DCIp" Then
        '                    dDCIp = lMetricsObject(j).Metric
        '                    bDCIpMatch = True
        '                End If
        '                If lMetricsObject(j).MetricName = "DCId" Then
        '                    dDCId = lMetricsObject(j).Metric
        '                    bDCIdMatch = True
        '                End If

        '                If bDCIpMatch = True And bDCIdMatch = True Then
        '                    pSinkAndDCIS = New SinkandDCIs(lSinkIDandTypes(i).SinkID, lSinkIDandTypes(i).Type, dDCIp, dDCId)
        '                    lSinkAndDCIS.Add(pSinkAndDCIS)
        '                    row = pMetricsTable.NewRow()
        '                    row.ItemArray = New Object() {lSinkIDandTypes(i).SinkID, dDCIp, dDCId}
        '                    pMetricsTable.Rows.Add(row)
        '                    Exit For
        '                End If ' bDCIpMatch and bDCIdMatch are true

        '            End If
        '        Next ' row in the metrics object
        '    Next ' sink in list of unique sink ID strings

        '    ' insert the sink row into the table
        '    'i = 0

        '    'For i = 0 To lSinkAndDCIS.Count - 1

        '    '    row = table.NewRow()
        '    '    row.ItemArray = New Object() {lSinkAndDCIS(i).SinkID, "", lSinkAndDCIS(i).Type, lSinkAndDCIS(i).DCIp, lSinkAndDCIS(i).DCId}
        '    '    table.Rows.Add(row)


        '    'Next

        'Else ' just insert the sink ID and type

        'End If ' bDCI = True

        'Dim pHabTable As DataTable = New DataTable("HabitatTable")

        'column = New DataColumn("Sink", GetType(System.String))
        'pHabTable.Columns.Add(column)
        'column = New DataColumn("Layer", GetType(System.String))
        'pHabTable.Columns.Add(column)
        'column = New DataColumn("Direction", GetType(System.String))
        'pHabTable.Columns.Add(column)
        'column = New DataColumn("TraceType", GetType(System.String))
        'pHabTable.Columns.Add(column)
        'column = New DataColumn("Class", GetType(System.String))
        'pHabTable.Columns.Add(column)
        'column = New DataColumn("Quantity", GetType(System.Double))
        'pHabTable.Columns.Add(column)
        'column = New DataColumn("Unit", GetType(System.String))
        'pHabTable.Columns.Add(column)

        '' create data table for habitat statistics
        'i = 0
        'For i = 0 To lSinkAndDCIS.Count - 1

        '    j = 0
        '    For j = 0 To lHabStatsList.Count - 1

        '        If lSinkAndDCIS(i).SinkID = lHabStatsList(j).Sink And lSinkAndDCIS(i).SinkID = lHabStatsList(j).bID Then

        '            ' = lHabStatsList(j).Sink
        '            ' = lHabStatsList(j).bID
        '            ' = lHabStatsList(j).bType
        '            ' = lHabStatsList(j).Layer
        '            ' = lHabStatsList(j).Direction
        '            ' = lHabStatsList(j).TotalImmedPath
        '            ' = lHabStatsList(j).UniqueClass
        '            ' = lHabStatsList(j).ClassName
        '            ' = lHabStatsList(j).Quantity
        '            ' = lHabStatsList(j).Unit

        '            row = pHabTable.NewRow()
        '            row.ItemArray = New Object() {lHabStatsList(j).Sink, lHabStatsList(j).Layer, lHabStatsList(j).Direction, lHabStatsList(j).TotalImmedPath, lHabStatsList(j).UniqueClass, lHabStatsList(j).Quantity, lHabStatsList(j).Unit}
        '            pHabTable.Rows.Add(row)


        '        End If

        '    Next

        'Next

        '' gonna do a join based on some shit
        '' create a dataset
        'Dim dataset As New DataSet("output_tables")
        'dataset.Tables.Add(pHabTable)
        'dataset.Tables.Add(pMetricsTable)
        'dataset.Tables.Add(pSinkTable)

        'Dim obj_ParentClmn, obj_ChildClmn As DataColumn

        ''Get the reference of columns to create a relation between.
        'obj_ParentClmn = dataset.Tables("Sink Table").Columns("Sink")
        'obj_ChildClmn = dataset.Tables("HabitatTable").Columns("Sink")

        ''Creates a relation object, Parameters required are
        ''New Relation Name, Object of Parent & Child column respectively.
        'Dim obj_DataRelation = New DataRelation("relation_Sink_Habitat", _
        '            obj_ParentClmn, obj_ChildClmn)

        ''Adding Relation to the dataset that holds the tables.
        'dataset.Relations.Add(obj_DataRelation)

        '============================

        '  The challenge is to put two tables side-by-side
        '  Master sinks table next to the child hab list table. 
        '  challenge is spacing and column variability.  



        'pSinkTable.PrimaryKey = 

        ' example:
        ' int n = dataGridView1.Rows.Add();
        'dataGridView1.Rows[n].Cells[0].Value = title;
        'dataGridView1.Rows[n].Cells[1].Value = dateTimeNow;

        '  column one   - sink ID
        '  column two   - sink stat label
        '  column three - sink stat
        '  column four  - barrier ID
        '  column five  - trace direction (i.e. upstream:)  (Loop)
        '  column six   - trace type (i.e. total)
        '  column six   - habitat layer (i.e. Lines) (Loop) (OMIT)
        '  column seven - habitat class (i.e. river or stream)(Loop)
        '                 if there are classes insert a 'total' at the bottom 
        '                 of the list of classes (run totalling function?)
        '  column eight - the quantity
        '  column nine  - unit 

        ' For each Sink in the master Sinks List
        '   If it's the first iteration of that sink. 
        '     if DCI stats were calculated then 
        '     insert the DCIp stat label and value in column 2 and three
        ' 

        ' Do NOT bind the data table so I can program flexible
        ' rows and columns to handle the variety of input data necessary

        ' ============ BEGIN WRITE TO DATAGRID OUTPUT SUMMARY TABLE =============

        ' Set up the table - create columns if needed

        pResultsForm3.DataGridView1.Columns.Add("Sink", "Sink")           '0
        pResultsForm3.DataGridView1.Columns.Add("SinkID", "SinkID")       '1
        pResultsForm3.DataGridView1.Columns.Add("Type", "Type")           '2
        pResultsForm3.DataGridView1.Columns.Add("Barrier", "Barrier")     '3
        pResultsForm3.DataGridView1.Columns.Add("BarrierID", "BarrierID") '4
        pResultsForm3.DataGridView1.Columns.Add("Metric", "Metric")       '5
        pResultsForm3.DataGridView1.Columns.Add("Value", "Value")         '6

        ' If there are habitat statistics then add the proper columns
        If lHabStatsList.Count > 0 Then
            pResultsForm3.DataGridView1.Columns.Add("Layer", "Layer")                 '7
            pResultsForm3.DataGridView1.Columns.Add("Direction", "Direction")         '8
            pResultsForm3.DataGridView1.Columns.Add("Type", "Type")                   '9
            pResultsForm3.DataGridView1.Columns.Add("HabitatClass", "Habitat_Class")  '10
            pResultsForm3.DataGridView1.Columns.Add("Quantity", "Quantity")           '11
            pResultsForm3.DataGridView1.Columns.Add("Unit", "Unit")                   '12


            '' Conditionally add columns and track number
            'Dim iUpHabColumn, iTotalUpHabColumn, iDownHabColumn, iPathDownHabColumn, iTotalPathDownHabColumn As Integer

            'iUpHabColumn = 0
            'iTotalUpHabColumn = 0
            'iDownHabColumn = 0
            'iPathDownHabColumn = 0
            'iTotalPathDownHabColumn = 0

            'bUpHab, bTotalUpHab, bDownHab, bTotalDownHab, bPathDownHab, bTotalPathDownHab

        End If

        i = 0
        For i = 0 To pResultsForm3.DataGridView1.Columns.Count - 1
            pResultsForm3.DataGridView1.Columns.Item(i).SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Next i


        Dim iMaxRowIndex, iSinkRowIndex, iSinkRowCount, iHabRowIndex, iHabRowcount, iBarrRowIndex, iBarrRowCount As Integer ' loop counters and grid indices
        Dim iMetricRowIndex, iMetricRowCount, iThisHabRowIndex, iThisHabRowCount As Integer
        Dim iSinkEID, iBarrEID As Integer
        Dim dTotalHab As Double 'running total of habitat for table
        Dim sLayer, sDirection2, sTraceType As String
        Dim bTrigger As Boolean = False
        Dim bTrigger2 As Boolean = False
        Dim bColorSwitcher = False
        Dim bSinkVisit As Boolean = True
        Dim t As Integer = 0
        i = 0
        iMaxRowIndex = 0
        j = 0

        Dim sinkBarrierLayerComparer As FindLayerAndBarrEIDAndSinkEIDPredicate ' for refining large stats object, reduce looping

        Dim sinkcomparer As FindBarriersBySinkEIDPredicate
        Dim barriercomparer As FindBarriersBySinkEIDPredicate ' used for refining habitat stats list 
        Dim barriermetriccomparer As FindBarrierMetricsBySinkEIDPredicate  ' used for refining barrier metrics stats list

        Dim refinedHabitatList As List(Of StatisticsObject_2)           ' for refining habitat stats list
        Dim refinedBarrierEIDList As List(Of BarrAndBarrEIDAndSinkEIDs) ' for refining barrier list
        Dim refinedBarrierMetricsList As List(Of MetricsObject)
        Dim refinedGLPKOptionsList As List(Of GLPKOptionsObject)

        Dim HabStatsComparer As RefineHabStatsListPredicate


        Dim pDataGridViewCellStyle As System.Windows.Forms.DataGridViewCellStyle
        ' There are two tables being joined manually 
        ' - the metrics table / list
        ' and 
        ' - the habitat statistics table / list
        '  the table added second should tend to be the larger, 
        '  and the table going second needs to know the  
        '  number of rows already inserted in the table so it 
        '  knows whether to insert another. 
        '  iterate through both tables for each unique sink


        ' For each sink
        ' 1. for each sink in the master sinks object list
        ' 2. for each barrier associated with the sink in the master barriers list.  
        ' 2a add the metrics.

        ' notes: -the maxrow index keeps track of which row we're at,
        '        it's needed if there are multiple sinks
        '        -the isinkrow count keeps track of which row for this
        '        sink we're at so that the first row can be found
        '        -results form is populated with sinkID, not EID

        'iProgressIncrementFactor = (40 / lBarrierAndSinkEIDs.Count)

        For i = 0 To lSinkIDandTypes.Count - 1

            iSinkRowCount = 0
            iBarrRowCount = 0
            j = 0
            k = 0
            iSinkRowIndex = pResultsForm3.DataGridView1.Rows.Add()
            iMaxRowIndex = iSinkRowIndex ' the new maximum row count
            iSinkEID = lSinkIDandTypes(i).SinkEID

            ' Add the sink ID to the table
            '    record the row number
            pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(0).Style
            pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(1).Style
            'pDataGridViewCellStyle.Font = New Font(pResultsForm3.DataGridView1.Font.FontFamily, pResultsForm3.DataGridView1.Font.Size, FontStyle.Bold)
            pDataGridViewCellStyle.Font = New Font(pResultsForm3.DataGridView1.Font.FontFamily, 14, FontStyle.Bold)
            pDataGridViewCellStyle.ForeColor = Color.DarkGreen
            pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(0).Style = pDataGridViewCellStyle

            pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(0).Value = lSinkIDandTypes(i).SinkID
            pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(1).Value = lSinkIDandTypes(i).SinkEID
            pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(2).Value = lSinkIDandTypes(i).Type

            ' post up the sink-specific metrics and stats. 
            '    For each of the records in the metrics list
            '     add the values associated with this sink
            '     keep track of the number of rows added
            '     and the max row count of the table.  

            For k = 0 To lMetricsObject.Count - 1
                ' matching the 'barrier' EID - which is redundant
                ' and includes 'sink' metrics, too.  
                If lMetricsObject(k).BarrEID = iSinkEID Then
                    If iSinkRowCount = 0 Then
                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(5).Value = lMetricsObject(k).MetricName
                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(6).Value = Math.Round(lMetricsObject(k).Metric, 2)
                    ElseIf iSinkRowCount > 0 Then
                        pResultsForm3.DataGridView1.Rows.Add()
                        ' keep track of the maximum number of rows in the table
                        iMaxRowIndex = iMaxRowIndex + 1 ' Row tracker
                        'pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(2).Value = lMetricsObject(j).ID
                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(5).Value = lMetricsObject(k).MetricName
                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(6).Value = Math.Round(lMetricsObject(k).Metric, 2)

                    End If
                    iSinkRowCount += 1
                End If
            Next 'Metric Object

            t = 0
            iHabRowIndex = iSinkRowIndex
            iBarrRowIndex = iSinkRowIndex
            iHabRowcount = 0
            bSinkVisit = True ' to pass to Sub to tell it whether to increment the barrier loop counter
            For t = 0 To lAllFCIDs.Count - 1
                If m_bCancel = True Then
                    backgroundworker1.CancelAsync()
                    backgroundworker1.Dispose()
                    Exit Sub
                End If
                If iProgress < 90 Then
                    backgroundworker1.ReportProgress(iProgress + 1, "Writing to Output Form")
                End If
                'MsgBox("Debug:65")
                Dim iTemp As Integer
                'bUpHab, bTotalUpHab, bDownHab, bTotalDownHab, bPathDownHab, bTotalPathDownHab
                iTemp = lAllFCIDs(t).FCID

                If bUpHab = True Then
                    HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, iSinkEID, lAllFCIDs(t).FCID, "upstream", "Immediate")
                    refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                    UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                End If
                If bTotalUpHab = True Then
                    HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, iSinkEID, lAllFCIDs(t).FCID, "upstream", "Total")
                    refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                    UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                End If
                If bDownHab = True Then
                    HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, iSinkEID, lAllFCIDs(t).FCID, "downstream", "Immediate")
                    refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                    UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                End If
                If bTotalDownHab = True Then
                    HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, iSinkEID, lAllFCIDs(t).FCID, "downstream", "Total")
                    refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                    UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                End If
                If bPathDownHab = True Then
                    HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, iSinkEID, lAllFCIDs(t).FCID, "downstream", "Path")
                    refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                    UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                End If
                If bTotalPathDownHab = True Then
                    HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, iSinkEID, lAllFCIDs(t).FCID, "downstream", "Total Path")
                    refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                    UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                End If
            Next ' layer included (t)

            If bColorSwitcher = True Then
                bColorSwitcher = False
            Else
                bColorSwitcher = True
            End If

            iHabRowcount = 0
            iBarrRowIndex = 0
            iBarrRowCount = 0
            bTrigger = False 'indicates if the there's been another row added beyond the sink (any barriers)
            dTotalHab = 0
            bColorSwitcher = True

            ' 1. a refined list of all barriers for the sink
            ' use a comparer to get all the records from the barriers and sinks list that match the sink
            barriercomparer = New FindBarriersBySinkEIDPredicate(iSinkEID)
            refinedBarrierEIDList = lBarrierAndSinkEIDs.FindAll(AddressOf barriercomparer.CompareEID)

            'MsgBox("Debug:66")

            ' For each barrier
            '  1. a refined list of all habitat stats for this barrier 
            '     and sink and layer
            '  2. for each layer get a refined list of habitat metrics 
            '     associated with each layer, sink, barrier combo
            k = 0
            For k = 0 To refinedBarrierEIDList.Count - 1

                iBarrRowIndex = pResultsForm3.DataGridView1.Rows.Add()
                iMaxRowIndex = iBarrRowIndex
                iBarrRowCount = 0
                iSinkRowCount += 1
                iBarrRowCount += 1
                bTrigger = False
                If m_bCancel = True Then
                    backgroundworker1.CancelAsync()
                    backgroundworker1.Dispose()
                    Exit Sub
                End If
                If iProgress < 90 Then
                    backgroundworker1.ReportProgress(iProgress + 1, "Writing to Output Form" & ControlChars.NewLine & _
                                                     " Barrier #: " & k.ToString)
                End If
                ' attempt at a border
                ' border control not available as of 2005 and .net 2.0
                'Dim pPainter As Windows.Forms.DataGridViewRowPrePaintEventArgs
                'pPainter = pResultsForm3.DataGridView1..Rows(iMaxRowIndex).
                '' add barrier ID to the datagrid
                '    record the row number
                pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(4).Style
                If bColorSwitcher = False Then
                    pDataGridViewCellStyle.BackColor = Color.PowderBlue
                Else
                    pDataGridViewCellStyle.BackColor = Color.Lavender
                End If
                pDataGridViewCellStyle.Font = New Font(pResultsForm3.DataGridView1.Font.FontFamily, pResultsForm3.DataGridView1.Font.Size, FontStyle.Bold)
                pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(3).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(4).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(3).Value = refinedBarrierEIDList(k).BarrLabel
                pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(4).Value = refinedBarrierEIDList(k).BarrEID

                ' get refined list of barrier/sink metrics
                barriermetriccomparer = New FindBarrierMetricsBySinkEIDPredicate(iSinkEID, refinedBarrierEIDList(k).BarrEID)
                refinedBarrierMetricsList = lMetricsObject.FindAll(AddressOf barriermetriccomparer.CompareEID)

                ' For each metric in the refined list
                ' insert a new row if necessary
                ' add the metric to the table
                t = 0
                iMetricRowCount = 0
                iMetricRowIndex = iMaxRowIndex
                For t = 0 To refinedBarrierMetricsList.Count - 1


                    If iMetricRowCount = 0 Then
                        'pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(2).Value = lMetricsObject(j).ID
                        If bColorSwitcher = True Then
                            pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(5).Style
                            pDataGridViewCellStyle.BackColor = Color.Lavender
                        Else
                            pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(5).Style
                            pDataGridViewCellStyle.BackColor = Color.PowderBlue
                        End If
                        pResultsForm3.DataGridView1.Rows(iMetricRowIndex).Cells(5).Style = pDataGridViewCellStyle
                        pResultsForm3.DataGridView1.Rows(iMetricRowIndex).Cells(6).Style = pDataGridViewCellStyle

                        pResultsForm3.DataGridView1.Rows(iMetricRowIndex).Cells(5).Value = refinedBarrierMetricsList(t).MetricName
                        pResultsForm3.DataGridView1.Rows(iMetricRowIndex).Cells(6).Value = Math.Round(refinedBarrierMetricsList(t).Metric, 2)
                        iMetricRowCount += 1
                    ElseIf iMetricRowCount > 0 Then
                        If iMaxRowIndex <= (iBarrRowIndex + iMetricRowCount) Then
                            iMetricRowIndex = pResultsForm3.DataGridView1.Rows.Add()
                            'iBarrRowIndex = iMetricRowIndex
                            iBarrRowCount += 1
                            iMetricRowCount += 1
                            iMaxRowIndex += 1 ' Row tracker
                            iSinkRowCount += 1
                        End If
                        If bColorSwitcher = True Then
                            pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(5).Style
                            pDataGridViewCellStyle.BackColor = Color.Lavender
                        Else
                            pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(5).Style
                            pDataGridViewCellStyle.BackColor = Color.PowderBlue
                        End If
                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(3).Style = pDataGridViewCellStyle
                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(4).Style = pDataGridViewCellStyle
                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(5).Style = pDataGridViewCellStyle
                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(6).Style = pDataGridViewCellStyle


                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(5).Value = refinedBarrierMetricsList(t).MetricName
                        pResultsForm3.DataGridView1.Rows(iMaxRowIndex).Cells(6).Value = Math.Round(refinedBarrierMetricsList(t).Metric, 2)
                    End If
                Next ' refined metric (t)

                'MsgBox("Debug:67")
                t = 0
                iHabRowIndex = iBarrRowIndex
                iHabRowcount = 0
                bSinkVisit = False
                For t = 0 To lAllFCIDs.Count - 1

                    Dim iTemp As Integer
                    'bUpHab, bTotalUpHab, bDownHab, bTotalDownHab, bPathDownHab, bTotalPathDownHab
                    iTemp = lAllFCIDs(t).FCID

                    If bUpHab = True Then
                        HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, refinedBarrierEIDList(k).BarrEID, lAllFCIDs(t).FCID, "upstream", "Immediate")
                        refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                        UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                    End If
                    If bTotalUpHab = True Then
                        HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, refinedBarrierEIDList(k).BarrEID, lAllFCIDs(t).FCID, "upstream", "Total")
                        refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                        UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                    End If
                    If bDownHab = True Then
                        HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, refinedBarrierEIDList(k).BarrEID, lAllFCIDs(t).FCID, "downstream", "Immediate")
                        refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                        UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                    End If
                    If bTotalDownHab = True Then
                        HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, refinedBarrierEIDList(k).BarrEID, lAllFCIDs(t).FCID, "downstream", "Total")
                        refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                        UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                    End If
                    If bPathDownHab = True Then
                        HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, refinedBarrierEIDList(k).BarrEID, lAllFCIDs(t).FCID, "downstream", "Path")
                        refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                        UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                    End If
                    If bTotalPathDownHab = True Then
                        HabStatsComparer = New RefineHabStatsListPredicate(iSinkEID, refinedBarrierEIDList(k).BarrEID, lAllFCIDs(t).FCID, "downstream", "Total Path")
                        refinedHabitatList = lHabStatsList.FindAll(AddressOf HabStatsComparer.CompareHabStuff)
                        UpdateSummaryTable(refinedHabitatList, iHabRowcount, pResultsForm3, iMaxRowIndex, iBarrRowIndex, bColorSwitcher, iSinkRowCount, iBarrRowCount, bSinkVisit)
                    End If
                Next ' layer included (t)

                If bColorSwitcher = True Then
                    bColorSwitcher = False
                Else
                    bColorSwitcher = True
                End If
            Next ' barrier for this sink (k)
        Next ' sink 

        'MsgBox("Debug:68")
        pResultsForm3.DataGridView1.AutoResizeColumns()
        EndTime = DateTime.Now
        pResultsForm3.lblBeginTime.Text = "Begin Time: " & BeginTime
        pResultsForm3.lblEndtime.Text = "End Time: " & EndTime

        TotalTime = EndTime - BeginTime
        pResultsForm3.lblTotalTime.Text = "Total Time: " & TotalTime.Hours & "hrs " & TotalTime.Minutes & "minutes " & TotalTime.Seconds & "seconds"
        pResultsForm3.lblDirection.Text = "Analysis Direction: " + sDirection
        If iOrderNum <> 999 Then
            'MsgBox("Debug:69")
            pResultsForm3.lblOrder.Text = "Order of Analysis: " & CStr(iOrderNum)
            'MsgBox("Debug:70")
        Else
            pResultsForm3.lblOrder.Text = "Order of Analysis: Max"
        End If

        If Not pAllFlowEndBarriers Is Nothing Then
            If pAllFlowEndBarriers.Count <> 0 Then
                'MsgBox("Debug:71")
                pResultsForm3.lblNumBarriers.Text = "Number of Barriers Analysed: " & CStr(pAllFlowEndBarriers.Count + pOriginaljuncFlagsList.Count)
                'MsgBox("Debug:72")
            Else
                pResultsForm3.lblNumBarriers.Text = "Number of Barriers Analysed: 1"
            End If
        End If

        ' ============== END WRITE TO OUTPUT SUMMARY TABLE =================



        'lHabStatsList

        ' = lHabStatsList(j).Sink
        ' = lHabStatsList(j).bID
        ' = lHabStatsList(j).bType
        ' = lHabStatsList(j).Layer
        ' = lHabStatsList(j).Direction
        ' = lHabStatsList(j).TotalImmedPath
        ' = lHabStatsList(j).UniqueClass
        ' = lHabStatsList(j).ClassName
        ' = lHabStatsList(j).Quantity
        ' = lHabStatsList(j).Unit

        ' = lDCIStatsList(j).Barrier
        ' = lDCIStatsList(j).Quantity
        ' = lDCIStatsList(j).BarrierPerm
        ' = lDCIStatsList(j).BarrierYN

        ' = lMetricsObject(j).Sink
        ' = lMetricsObject(j).ID
        ' = lMetricsObject(j).Type
        ' = lMetricsObject(j).MetricName
        ' = lMetricsObject(j).Metric



        ' The output form contains a variable width table
        ' with a minimum set of data.  It will be up to the user to select
        ' whether they want this form or not.  This form could contain all
        ' the data presented in the two tables, Habitat and Metrics, and it 
        ' could contain very little of it.Can think about this table as a 1:M
        ' join - lots of wasted space and redundancy.  

        'MsgBox("Debug:73")
        ' ================== END WRITE TO OUTPUT FORM ===================
        ' check if user has hit 'close/cancel'
        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        backgroundworker1.ReportProgress(100, "Completed!")

        backgroundworker1.Dispose()
        backgroundworker1.CancelAsync()

        ' refresh the view
        pActiveView.Refresh()
        pResultsForm3.BringToFront()

    End Sub
    Private Class FindLayerAndBarrEIDAndSinkEIDPredicate
        ' this class should help return a double-check 
        ' list object of Statistics where the 
        ' and the sink EID, barrier ID, and layer matches.  
        ' tutorial here: http://social.msdn.microsoft.com/Forums/en-US/vbgeneral/thread/bad5193a-3bf1-4675-8a05-625f46f9c158/
        Private _SinkEID As Integer
        Private _BarrEID As Integer
        Private _LayerID As Integer

        Public Sub New(ByVal sinkEID As Integer, ByVal barrEID As Integer, ByVal layerID As String)
            Me._SinkEID = sinkEID
            Me._BarrEID = barrEID
            Me._LayerID = layerID
        End Sub

        ' this is a double-check and should 
        ' return true if there's a match between
        ' BOTH the layer and EID of the sink/barrier
        Public Function CompareEIDandLayer(ByVal obj As StatisticsObject_2) As Boolean
            Return (_SinkEID = obj.SinkEID And _BarrEID = obj.bEID And _LayerID = obj.LayerID)
        End Function
    End Class
    Private Class FindBarrierEIDPredicate
        ' this class should help return a double-check 
        ' list object of Statistics where the 
        ' and the sink EID, barrier ID, and layer matches.  
        ' tutorial here: http://social.msdn.microsoft.com/Forums/en-US/vbgeneral/thread/bad5193a-3bf1-4675-8a05-625f46f9c158/
        Private _bEID As Integer
        Private _passability As Double

        Public Sub New(ByVal bEID As Integer, ByVal passability As Double)
            Me._bEID = bEID
            Me._passability = passability
        End Sub

        ' this is a double-check and should 
        ' return true if there's a match between
        ' BOTH the layer and EID of the sink/barrier
        Public Function CompareEIDandLayer(ByVal obj As StatisticsObject_2) As Boolean
            Return (_bEID = obj.bEID)
        End Function
    End Class

    Private Class RefineHabStatsListPredicate
        ' this class should help return a double-check 
        ' list object of Statistics where the 
        ' and the sink EID, barrier ID, and layer matches.  
        ' tutorial here: http://social.msdn.microsoft.com/Forums/en-US/vbgeneral/thread/bad5193a-3bf1-4675-8a05-625f46f9c158/
        Private _SinkEID As Integer
        Private _BarrEID As Integer
        Private _LayerID As Integer
        Private _Direction As String
        Private _Type As String

        Public Sub New(ByVal sinkEID As Integer, ByVal barrEID As Integer, ByVal layerID As String, ByVal direction As String, ByVal type As String)
            Me._SinkEID = sinkEID
            Me._BarrEID = barrEID
            Me._LayerID = layerID
            Me._Direction = direction
            Me._Type = type
        End Sub

        ' this is a double-check and should 
        ' return true if there's a match between
        ' BOTH the layer and EID of the sink/barrier
        Public Function CompareHabStuff(ByVal obj As StatisticsObject_2) As Boolean
            Return (_SinkEID = obj.SinkEID And _BarrEID = obj.bEID And _LayerID = obj.LayerID _
            And _Direction = obj.Direction And _Type = obj.TotalImmedPath)
        End Function
    End Class


    Private Class FindLayerAndBarrEIDPredicate
        ' this class should help return a double-check 
        ' list object of Statistics where the layer matches 
        ' and the sink/barr EID matches as well.  
        ' tutorial here: http://social.msdn.microsoft.com/Forums/en-US/vbgeneral/thread/bad5193a-3bf1-4675-8a05-625f46f9c158/
        Private _BarrEID As Integer
        Private _LayerID As Integer

        Public Sub New(ByVal barrEID As Integer, ByVal layerID As String)
            Me._BarrEID = barrEID
            Me._LayerID = layerID
        End Sub

        ' this is a double-check and should 
        ' return true if there's a match between
        ' BOTH the layer and EID of the sink/barrier
        Public Function CompareEIDandLayer(ByVal obj As StatisticsObject_2) As Boolean
            Return (_BarrEID = obj.bEID And _LayerID = obj.LayerID)
        End Function
    End Class

    Private Class FindStatsClassPredicate
        ' this class should help return a double-check 
        ' list object of Statistics where the layer matches 
        ' and the sink/barr EID matches as well.  
        ' tutorial here: http://social.msdn.microsoft.com/Forums/en-US/vbgeneral/thread/bad5193a-3bf1-4675-8a05-625f46f9c158/
        Private _Class As String

        Public Sub New(ByVal class2 As String)
            Me._Class = class2
        End Sub

        ' this is a double-check and should 
        ' return true if there's a match between
        ' BOTH the layer and EID of the sink/barrier
        Public Function CompareStatsClass(ByVal obj As StatisticsObject) As Boolean
            Return (_Class = obj.UniqueClass)
        End Function
    End Class

    Private Class FindBarriersBySinkEIDPredicate
        ' this class should help return a double-check 
        ' list object of Statistics where the layer matches 
        ' and the sink/barr EID matches as well.  
        ' tutorial here: http://social.msdn.microsoft.com/Forums/en-US/vbgeneral/thread/bad5193a-3bf1-4675-8a05-625f46f9c158/
        Private _SinkEID As Integer

        Public Sub New(ByVal sinkEID As Integer)
            Me._SinkEID = sinkEID
        End Sub

        ' this is a double-check and should 
        ' return true if there's a match between
        ' BOTH the layer and EID of the sink/barrier
        Public Function CompareEID(ByVal obj As BarrAndBarrEIDAndSinkEIDs) As Boolean
            Return (_SinkEID = obj.SinkEID)
        End Function
    End Class
    Private Class FindBarrierMetricsBySinkEIDPredicate
        ' this class should help return a double-check 
        ' list object of Statistics where the layer matches 
        ' and the sink/barr EID matches as well.  
        ' tutorial here: http://social.msdn.microsoft.com/Forums/en-US/vbgeneral/thread/bad5193a-3bf1-4675-8a05-625f46f9c158/
        Private _SinkEID As Integer
        Private _BarrierEID As Integer

        Public Sub New(ByVal sinkEID As Integer, ByVal barrierEID As Integer)
            Me._SinkEID = sinkEID
            Me._BarrierEID = barrierEID
        End Sub

        ' this is a double-check and should 
        ' return true if there's a match between
        ' BOTH the layer and EID of the sink/barrier
        Public Function CompareEID(ByVal obj As MetricsObject) As Boolean
            Return (_SinkEID = obj.SinkEID And _BarrierEID = obj.BarrEID)
        End Function
    End Class
    Public Sub IntersectFeatures()

        'Read Extension Settings
        ' ================== READ EXTENSION SETTINGS =================

        Dim bDBF As Boolean = False         ' Include DBF output default 'no'
        Dim pLLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim pPLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim iPolysCount As Integer = 0      ' number of polygon layers currently using
        Dim iLinesCount As Integer = 0      ' number of lines layers currently using
        Dim HabLayerObj As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property
        ' object to hold stats to add to list. 
        Dim pHabStatsObject_2 As New StatisticsObject_2(Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
        Dim m As Integer = 0
        Dim k As Integer = 0
        Dim j As Integer = 0
        Dim i As Integer = 0

        If m_FiPEx__1.m_bLoaded = True Then

            ' Populate a list of the layers using and habitat summary fields.
            ' match any of the polygon layers saved in stream to those in listboxes 
            iPolysCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numPolys"))
            If iPolysCount > 0 Then
                For k = 0 To iPolysCount - 1
                    'sPolyLayer = m_FiPEX__1.pPropset.GetProperty("IncPoly" + k.ToString) ' get poly layer
                    HabLayerObj = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncPoly" + k.ToString)) ' get poly layer
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyClassField" + k.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyQuanField" + k.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyUnitField" + k.ToString))
                    End With

                    ' Load that object into the list
                    pPLayersFields.Add(HabLayerObj)  'what are the brackets about - this could be aproblem!!
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            Dim iCount1 As Integer = pPLayersFields.Count

            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    If pPLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for polygon layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If

            iLinesCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numLines"))
            Dim HabLayerObj2 As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property

            ' match any of the line layers saved in stream to those in listboxes
            If iLinesCount > 0 Then
                For j = 0 To iLinesCount - 1
                    'sLineLayer = m_FiPEX__1.pPropset.GetProperty("IncLine" + j.ToString) ' get line layer
                    HabLayerObj2 = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj2
                        '.Layer = sLineLayer
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncLine" + j.ToString))
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineClassField" + j.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineQuanField" + j.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineUnitField" + j.ToString))
                    End With
                    ' add to the module level list
                    pLLayersFields.Add(HabLayerObj2)
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            iCount1 = pLLayersFields.Count
            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    If pLLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for river layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If
        Else
            System.Windows.Forms.MessageBox.Show("Cannot read extension settings.", "Calculate Stats Error")
            Exit Sub
        End If

        ' ======================= 1.0 INTERSECT ===========================
        ' This next section checks each of the polygon layers in the focusmap
        ' and intersects them with any layers in the focusmap that have a selection.

        ' PROCESS LOGIC:
        ' If there are polygon layers to use in this process then continue
        '   For each of the layers in the focusMap
        '     If it's a feature layer then
        '       If it's a polygon
        '         If it's on the 'include' list
        '           For each of the FocusMap layers 
        '             If it's a line layer (because we don't want to repeatedly 
        '             intersect a polygon layer with itself, do we? DO WEEE???)
        '               If there are any selected features 
        '                 If the parameter array is already populated then empty it
        '                 Populate parameter array for intersect process
        '                 Perform intersect - return results as selection


        Dim pUID As New UID
        ' Get the pUID of the SelectByLayer command
        'pUID.Value = "{82B9951B-DD63-11D1-AA7F-00C04FA37860}"

        Dim pGp As IGeoProcessor
        pGp = New ESRI.ArcGIS.Geoprocessing.GeoProcessor
        Dim pParameterArray As IVariantArray
        Dim pMxDocument As IMxDocument
        Dim pMap As IMap

        Dim sFeatureFullPath As String
        Dim lMaxLayerIndex As Integer
        Dim pLayer2Intersect As IFeatureLayer
        Dim iFieldVal As Integer  ' The field index
        Dim sTestPolygon As String
        Dim bIncludePoly As Boolean 'For polygon inclusion
        Dim pFeatureLayer As IFeatureLayer
        Dim pEnumLayer As IEnumLayer
        Dim pFeatureSelection As IFeatureSelection
        Dim pGPResults As IGeoProcessorResult
        Dim pDoc As IDocument = My.ArcMap.Application.Document
        pMxDocument = CType(pDoc, IMxDocument)
        pMap = pMxDocument.FocusMap
        lMaxLayerIndex = pMap.LayerCount - 1
        i = 0
        m = 0

        pUID = New UID
        pUID.Value = "{E156D7E5-22AF-11D3-9F99-00C04F6BC78E}"

        pEnumLayer = pMap.Layers(pUID, True)
        pEnumLayer.Reset()

        If Not pPLayersFields Is Nothing Then
            If pPLayersFields.Count > 0 Then
                For i = 0 To lMaxLayerIndex
                    If pMap.Layer(i).Valid = True Then
                        If TypeOf pMap.Layer(i) Is IFeatureLayer Then
                            pFeatureLayer = CType(pMap.Layer(i), IFeatureLayer)
                            sTestPolygon = Convert.ToString(pFeatureLayer.FeatureClass.ShapeType)

                            If pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolygon Then
                                bIncludePoly = False ' Reset Variable
                                For j = 0 To pPLayersFields.Count - 1
                                    If pFeatureLayer.Name = pPLayersFields(j).Layer Then
                                        bIncludePoly = True
                                    End If
                                Next

                                'sDataSourceType = pFeatureLayer.DataSourceType

                                If bIncludePoly = True Then
                                    m = 0
                                    For m = 0 To lMaxLayerIndex
                                        If pMap.Layer(m).Valid = True Then
                                            If TypeOf pMap.Layer(m) Is IFeatureLayer Then
                                                pLayer2Intersect = CType(pMap.Layer(m), IFeatureLayer)

                                                If pLayer2Intersect.FeatureClass.ShapeType = esriGeometryType.esriGeometryLine _
                                                Or pLayer2Intersect.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolyline Then
                                                    pFeatureSelection = CType(pLayer2Intersect, IFeatureSelection)

                                                    If (pFeatureSelection.SelectionSet.Count <> 0) Then

                                                        If pParameterArray IsNot Nothing Then
                                                            pParameterArray.RemoveAll()
                                                        Else
                                                            'pParameterArray = New ESRI.ArcGIS.esriSystem.VarArray 'VB.NET
                                                            pParameterArray = New ESRI.ArcGIS.esriSystem.VarArray
                                                        End If

                                                        ' The GP doesn't need full path names to feature classes
                                                        ' it only needs feature layer names as they appear in the TOC
                                                        sFeatureFullPath = pFeatureLayer.Name
                                                        pParameterArray.Add(sFeatureFullPath)
                                                        pParameterArray.Add("INTERSECT")
                                                        pParameterArray.Add(pLayer2Intersect.Name)
                                                        pParameterArray.Add("#")
                                                        pParameterArray.Add("ADD_TO_SELECTION")

                                                        pGPResults = pGp.Execute("SelectLayerByLocation_management", pParameterArray, Nothing)
                                                    End If ' it has a feature selection
                                                End If ' It's a line
                                            End If ' It's a feature layer
                                        End If
                                    Next
                                End If
                            End If
                        End If
                    End If ' Layer is valid
                Next
            End If ' polygon list count is not zero
        End If ' polygon list is not nothing

    End Sub
    Public Sub calculateGLPKStatistics(ByRef lGLPKStatisticsList As List(Of GLPKStatisticsObject), ByVal lAllLayersFieldsGLPK As List(Of LayerToAdd), ByRef ID As Integer, _
        ByVal iOrderLoop As Integer)

        ' **************************************************************************************
        ' Subroutine:  Calculate DCI Statistics 
        ' Created By:  Greig Oldford
        ' Update Date: October 5, 2010
        ' Purpose:     
        '              1) calculate habitat area and length ignoring habitat classes 
        '              2) combine multiple network-participating line layers into one
        '                 habitat measure (intent to introduce weighting options and 
        '                 inclusion of non-network lines which requires additions to intersect sub)
        '              4) update statistics object and send back to onclick

        Dim pMxDoc As IMxDocument
        Dim pEnumLayer As IEnumLayer
        Dim pFeatureLayer As IFeatureLayer
        Dim pFeatureSelection As IFeatureSelection
        Dim pFeatureCursor As IFeatureCursor
        Dim pFeature As IFeature
        Dim dTotalArea As Double ' alternative to 2D Matrix when no classes are given
        Dim pUID As New UID
        ' Get the pUID of the SelectByLayer command
        'pUID.Value = "{82B9951B-DD63-11D1-AA7F-00C04FA37860}"

        Dim pMxDocument As IMxDocument
        Dim pMap As IMap

        Dim j, k, m As Integer
        Dim iFieldVal As Integer  ' The field index

        Dim pFields As IFields
        Dim pSelectionSet As ISelectionSet

        ' K REPRESENTS NUMBER OF POSSIBLE HABITAT CLASSES
        '  rows, columns.  ROWS SHOULD BE SET BY NUMBER OF SUMMARY FIELDS
        ' cannot be redimension preserved later

        Dim lStatsMatrix As New List(Of StatisticsObject)
        Dim pStatisticsObject As New StatisticsObject(Nothing, Nothing)

        Dim pCursor As ICursor
        Dim vTemp As Object

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        pMxDoc = CType(pDoc, IMxDocument)
        pMxDocument = CType(pDoc, IMxDocument)
        pMap = pMxDocument.FocusMap

        ' ================== READ EXTENSION SETTINGS =================
        Dim sDirection, sDirection2 As String

        Dim bDBF As Boolean = False         ' Include DBF output default 'no'
        Dim pLLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim pPLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim iPolysCount As Integer = 0      ' number of polygon layers currently using
        Dim iLinesCount As Integer = 0      ' number of lines layers currently using
        Dim HabLayerObj As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property
        ' object to hold stats to add to list. 
        Dim pGLPKStatisticsObject As New GLPKStatisticsObject(Nothing, Nothing)

        If m_FiPEx__1.m_bLoaded = True Then

            sDirection = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("direction"))

            'Make the direction more readable for dockable window output
            If sDirection = "up" Then
                sDirection2 = "upstream"
            Else
                sDirection2 = "downstream"
            End If

            ' Populate a list of the layers using and habitat summary fields.
            ' match any of the polygon layers saved in stream to those in listboxes 
            iPolysCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numPolys"))
            If iPolysCount > 0 Then
                For k = 0 To iPolysCount - 1
                    'sPolyLayer = m_FiPEX__1.pPropset.GetProperty("IncPoly" + k.ToString) ' get poly layer
                    HabLayerObj = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncPoly" + k.ToString)) ' get poly layer
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyClassField" + k.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyQuanField" + k.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyUnitField" + k.ToString))
                    End With

                    ' Load that object into the list
                    pPLayersFields.Add(HabLayerObj)  'what are the brackets about - this could be aproblem!!
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            Dim iCount1 As Integer = pPLayersFields.Count

            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    If pPLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for lacustrine layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If

            iLinesCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numLines"))
            Dim HabLayerObj2 As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property

            ' match any of the line layers saved in stream to those in listboxes
            If iLinesCount > 0 Then
                For j = 0 To iLinesCount - 1
                    'sLineLayer = m_FiPEX__1.pPropset.GetProperty("IncLine" + j.ToString) ' get line layer
                    HabLayerObj2 = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj2
                        '.Layer = sLineLayer
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncLine" + j.ToString))
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineClassField" + j.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineQuanField" + j.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineUnitField" + j.ToString))
                    End With
                    ' add to the module level list
                    pLLayersFields.Add(HabLayerObj2)
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            iCount1 = pLLayersFields.Count
            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    If pLLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for river layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If
        Else
            System.Windows.Forms.MessageBox.Show("Cannot read extension settings.", "Calculate Stats Error")
            Exit Sub
        End If

        ' ========== End Read Extension settings ===============

        pUID.Value = "{E156D7E5-22AF-11D3-9F99-00C04F6BC78E}"
        pEnumLayer = pMap.Layers(pUID, True)
        pEnumLayer.Reset()

        ' Look at the next layer in the list
        pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)

        Dim iLoopCount As Integer = 0
        Dim dTempQuan As Double
        dTotalArea = 0

        Do While Not pFeatureLayer Is Nothing ' these two lines must be separate
            If pFeatureLayer.Valid = True Then ' or there will be an empty object ref
                If pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryLine Or _
                pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolyline Or _
                pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolygon Then ' or there will be an empty object ref

                    pFeatureSelection = CType(pFeatureLayer, IFeatureSelection)
                    pSelectionSet = pFeatureSelection.SelectionSet

                    ' get the fields from the featureclass
                    pFields = pFeatureLayer.FeatureClass.Fields
                    j = 0

                    For j = 0 To lAllLayersFieldsGLPK.Count - 1
                        If lAllLayersFieldsGLPK(j).Layer = pFeatureLayer.Name Then

                            If pFeatureSelection.SelectionSet.Count <> 0 Then

                                pFeatureSelection.SelectionSet.Search(Nothing, False, pCursor)
                                pFeatureCursor = CType(pCursor, IFeatureCursor)
                                pFeature = pFeatureCursor.NextFeature

                                ' Get the summary field and add the value to the
                                ' total for habitat area.
                                ' ** ==> Multiple fields could be added here in a 'for' loop.

                                iFieldVal = pFeatureCursor.FindField(lAllLayersFieldsGLPK(j).QuanField)

                                ' For each selected feature
                                m = 1
                                Do While Not pFeature Is Nothing
                                    Try
                                        vTemp = pFeature.Value(iFieldVal)
                                    Catch ex As Exception
                                        vTemp = 0
                                    End Try

                                    Try
                                        dTempQuan = Convert.ToDouble(pFeature.Value(iFieldVal))
                                    Catch ex As Exception
                                        dTempQuan = 0
                                        MsgBox("The Habitat Quantity found in the " & pFeatureLayer.Name & " was not convertible" _
                                            & " to type 'double'.  Null values in field may be responsible. " & ex.Message)
                                    End Try
                                    ' Insert into the corresponding column of the second
                                    ' row the updated habitat area measurement.
                                    dTotalArea = dTotalArea + dTempQuan
                                    pFeature = pFeatureCursor.NextFeature
                                Loop     ' selected feature
                            End If ' there are selected features

                            ' increment the loop counter for
                            iLoopCount = iLoopCount + 1

                        End If     ' feature layer matches hab class layer
                    Next           ' habitat layer
                End If ' featurelayer is valid
            End If
            pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
        Loop ' next map layer

        With pGLPKStatisticsObject
            ' If iOrderLoop = 0 Then
            ' .Barrier = "Sink"
            ' Else
            .Barrier = ID
            'End If
            '.BarrierPerm = dBarrierPerm
            '.BarrierYN = sNaturalYN
            .Quantity = dTotalArea
        End With

        lGLPKStatisticsList.Add(pGLPKStatisticsObject)
    End Sub

    Public Sub calculateDCIStatistics(ByRef lDCIStatsList As List(Of DCIStatisticsObject), ByVal lLLayersFieldsDCI As List(Of LayerToAdd), ByRef ID As String, _
        ByVal dBarrierPerm As Double, ByVal sNaturalYN As String, ByVal iOrderLoop As Integer)

        ' **************************************************************************************
        ' Subroutine:  Calculate DCI Statistics 
        ' Created By:  Greig Oldford
        ' Update Date: October 5, 2010
        ' Purpose:     
        '              1) calculate habitat area and length ignoring habitat classes 
        '              2) combine multiple network-participating line layers into one
        '                 habitat measure (intent to introduce weighting options and 
        '                 inclusion of non-network lines which requires additions to intersect sub)
        '              4) update statistics object and send back to onclick

        Dim pMxDoc As IMxDocument
        Dim pEnumLayer As IEnumLayer
        Dim pFeatureLayer As IFeatureLayer
        Dim pFeatureSelection As IFeatureSelection
        Dim pFeatureCursor As IFeatureCursor
        Dim pFeature As IFeature
        Dim dTotalArea As Double ' alternative to 2D Matrix when no classes are given
        Dim pUID As New UID
        ' Get the pUID of the SelectByLayer command
        'pUID.Value = "{82B9951B-DD63-11D1-AA7F-00C04FA37860}"

        Dim pMxDocument As IMxDocument
        Dim pMap As IMap

        Dim j, k, m As Integer
        Dim iFieldVal As Integer  ' The field index

        Dim pFields As IFields
        Dim pSelectionSet As ISelectionSet

        ' K REPRESENTS NUMBER OF POSSIBLE HABITAT CLASSES
        '  rows, columns.  ROWS SHOULD BE SET BY NUMBER OF SUMMARY FIELDS
        ' cannot be redimension preserved later

        Dim lStatsMatrix As New List(Of StatisticsObject)
        Dim pStatisticsObject As New StatisticsObject(Nothing, Nothing)

        Dim pCursor As ICursor
        Dim vTemp As Object

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        pMxDoc = CType(pDoc, IMxDocument)
        pMxDocument = CType(pDoc, IMxDocument)
        pMap = pMxDocument.FocusMap

        ' ================== READ EXTENSION SETTINGS =================
        Dim sDirection, sDirection2 As String

        Dim bDBF As Boolean = False         ' Include DBF output default 'no'
        Dim pLLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim pPLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim iPolysCount As Integer = 0      ' number of polygon layers currently using
        Dim iLinesCount As Integer = 0      ' number of lines layers currently using
        Dim HabLayerObj As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property
        ' object to hold stats to add to list. 
        Dim pDCIStatsObject As New DCIStatisticsObject(Nothing, Nothing, Nothing, Nothing)
        Dim dTempQuan As Double

        If m_FiPEx__1.m_bLoaded = True Then

            sDirection = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("direction"))
            bDBF = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("bDBF"))

            'Make the direction more readable for dockable window output
            If sDirection = "up" Then
                sDirection2 = "upstream"
            Else
                sDirection2 = "downstream"
            End If

            ' Populate a list of the layers using and habitat summary fields.
            ' match any of the polygon layers saved in stream to those in listboxes 
            iPolysCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numPolys"))
            If iPolysCount > 0 Then
                For k = 0 To iPolysCount - 1
                    'sPolyLayer = m_FiPEX__1.pPropset.GetProperty("IncPoly" + k.ToString) ' get poly layer
                    HabLayerObj = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncPoly" + k.ToString)) ' get poly layer
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyClassField" + k.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyQuanField" + k.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyUnitField" + k.ToString))
                    End With

                    ' Load that object into the list
                    pPLayersFields.Add(HabLayerObj)  'what are the brackets about - this could be aproblem!!
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            Dim iCount1 As Integer = pPLayersFields.Count

            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    If pPLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for lacustrine layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If

            iLinesCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numLines"))
            Dim HabLayerObj2 As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property

            ' match any of the line layers saved in stream to those in listboxes
            If iLinesCount > 0 Then
                For j = 0 To iLinesCount - 1
                    'sLineLayer = m_FiPEX__1.pPropset.GetProperty("IncLine" + j.ToString) ' get line layer
                    HabLayerObj2 = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj2
                        '.Layer = sLineLayer
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncLine" + j.ToString))
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineClassField" + j.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineQuanField" + j.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineUnitField" + j.ToString))
                    End With
                    ' add to the module level list
                    pLLayersFields.Add(HabLayerObj2)
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            iCount1 = pLLayersFields.Count
            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    If pLLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for river layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If
        Else
            System.Windows.Forms.MessageBox.Show("Cannot read extension settings.", "Calculate Stats Error")
            Exit Sub
        End If

        ' ========== End Read Extension settings ===============

        pUID.Value = "{E156D7E5-22AF-11D3-9F99-00C04F6BC78E}"
        pEnumLayer = pMap.Layers(pUID, True)
        pEnumLayer.Reset()

        ' Look at the next layer in the list
        pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)

        Dim iLoopCount As Integer = 0
        dTotalArea = 0

        Do While Not pFeatureLayer Is Nothing ' these two lines must be separate
            If pFeatureLayer.Valid = True Then ' or there will be an empty object ref
                If pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryLine Or _
                pFeatureLayer.FeatureClass.ShapeType = esriGeometryType.esriGeometryPolyline Then ' or there will be an empty object ref

                    pFeatureSelection = CType(pFeatureLayer, IFeatureSelection)
                    pSelectionSet = pFeatureSelection.SelectionSet

                    ' get the fields from the featureclass
                    pFields = pFeatureLayer.FeatureClass.Fields
                    j = 0

                    For j = 0 To lLLayersFieldsDCI.Count - 1
                        If lLLayersFieldsDCI(j).Layer = pFeatureLayer.Name Then

                            If pFeatureSelection.SelectionSet.Count <> 0 Then

                                pFeatureSelection.SelectionSet.Search(Nothing, False, pCursor)
                                pFeatureCursor = CType(pCursor, IFeatureCursor)
                                pFeature = pFeatureCursor.NextFeature

                                ' Get the summary field and add the value to the
                                ' total for habitat area.
                                ' ** ==> Multiple fields could be added here in a 'for' loop.

                                iFieldVal = pFeatureCursor.FindField(lLLayersFieldsDCI(j).QuanField)

                                ' For each selected feature
                                m = 1
                                Do While Not pFeature Is Nothing
                                    Try
                                        vTemp = pFeature.Value(iFieldVal)
                                    Catch ex As Exception
                                        vTemp = 0
                                    End Try

                                    Try
                                        dTempQuan = Convert.ToDouble(pFeature.Value(iFieldVal))
                                    Catch ex As Exception
                                        dTempQuan = 0
                                        MsgBox("The Habitat Quantity found in the " & pFeatureLayer.Name & " was not convertible" _
                                            & " to type 'double'.  Null values in field may be responsible. " & ex.Message)
                                    End Try
                                    ' Insert into the corresponding column of the second
                                    ' row the updated habitat area measurement.
                                    dTotalArea = dTotalArea + dTempQuan
                                    pFeature = pFeatureCursor.NextFeature
                                Loop     ' selected feature
                            End If ' there are selected features

                            ' increment the loop counter for
                            iLoopCount = iLoopCount + 1

                        End If     ' feature layer matches hab class layer
                    Next           ' habitat layer
                End If ' featurelayer is valid
            End If
            pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
        Loop ' next map layer

        With pDCIStatsObject
            If iOrderLoop = 0 Then
                .Barrier = "Sink"
            Else
                .Barrier = ID
            End If
            .BarrierPerm = dBarrierPerm
            .BarrierYN = sNaturalYN
            .Quantity = dTotalArea
        End With

        lDCIStatsList.Add(pDCIStatsObject)
    End Sub
    Public Sub calculateStatistics_2(ByRef lHabStatsList As List(Of StatisticsObject_2), ByRef ID As String, _
        ByRef iEID As Integer, ByRef sType As String, ByRef f_sOutID As String, ByRef f_siOutEID As Integer, _
        ByVal sKeyword As String, ByVal sHabTypeKeyword As String, _
        ByVal sDirection2 As String)

        ' **************************************************************************************
        ' Subroutine:  Calculate Statistics (2) 
        ' Created By:  Greig Oldford
        ' Update Date: October 5, 2010
        ' Purpose:     1) To intersect other included layers with returned selection
        '                 from the trace.
        '              2) calculate habitat area and length using habitat classes 
        '                 and excluding unwanted features
        '              3) get array (matrix?) of statistics for each habitat class and
        '                 each layer included for habitat classification stats
        '              4) update statistics object and send back to onclick
        ' Keywords:    sHabTypeKeyword - "Total", "Immediate", or "Path"
        '              sKeyword - "barrier" or "nonbarr"
        '
        '
        ' Notes:
        '       Oct 5, 2010  --> Changing this subroutine to a function so it can update the statistics 
        '                  object for habitat statistics (with classes) ONLY. i.e., there will be no 
        '                  other metrics included in this habitat statistics object.
        '                  Added another keyword to say whether this is TOTAL habitat or otherwise (sHabTypeKeyword). 
        '    
        '       Mar 3, 2008  --> Currently, only polygon feature layers are intersected.  The function
        '                  checks the config file for included polygons and will intersect any
        '                  network features returned by the trace with the polygons on the list.
        '                  There is probably no reason to have this explicitly for polygons, and
        '                  dividing the 'includes' list into line and polygon categories means that
        '                  the habitat classification also must be divided as such.  This would double
        '                  the number of variables for this process (polygon habitat class layer
        '                  variable, line hab class lyr var, polygon hab class case field var, etc.)
        '                  So, since network feature layers are already being returned by the trace,
        '                  they don't need to be intersected.  If we have one 'includes' list that
        '                  contains both polygon and line layers then we need to find out which layers
        '                  in this list are not part of the geometric network, and only intersect these
        '                  features.
        '                  For each includes feature, For each current geometric feature, find match?  Next
        '                  If no match then continue intersection.


        Dim pMxDoc As IMxDocument
        Dim pEnumLayer As IEnumLayer
        Dim pFeatureLayer As IFeatureLayer
        Dim pFeatureSelection As IFeatureSelection
        Dim pFeatureCursor As IFeatureCursor
        Dim pFeature As IFeature
        ' Feb 29 --> There will be a variable number of "included" layers
        '            to use for the habitat classification summary tables.
        '            Each table corresponds to "pages" in the matrix.
        '            Matrix(pages, columns, rows)
        '            Only the farthest right element in a matrix can be
        '            redim "preserved" in VB6 meaning there must be a static
        '            number of columns and pages.  Pages isn't a problem.
        '            They will be the number of layers in the "includes" list
        '            Columns, however, will vary.  This is a problem.  They
        '            will vary between pages of the matrix too which means there
        '            will be empty columns on at least one page if the column count
        '            is different between pages.
        '            Answer to this problem is to avoid the matrix altogether and
        '            update the necessary tables within this function


        Dim dTotalArea As Double ' alternative to 2D Matrix when no classes are given
        Dim pUID As New UID
        ' Get the pUID of the SelectByLayer command
        'pUID.Value = "{82B9951B-DD63-11D1-AA7F-00C04FA37860}"

        Dim pGp As IGeoProcessor
        pGp = New ESRI.ArcGIS.Geoprocessing.GeoProcessor
        Dim pMxDocument As IMxDocument
        Dim pMap As IMap


        Dim i, j, k, m As Integer
        Dim iFieldVal As Integer  ' The field index

        Dim pFields As IFields
        Dim vVar As Object
        Dim pSelectionSet As ISelectionSet
        Dim sTemp As String
        Dim sUnit As String

        ' K REPRESENTS NUMBER OF POSSIBLE HABITAT CLASSES
        '  rows, columns.  ROWS SHOULD BE SET BY NUMBER OF SUMMARY FIELDS
        ' cannot be redimension preserved later

        'Dim mHabClassVals() As Object       'Matrix holds the unique classes and values
        'ReDim mHabClassVals(0 To 4, 0 To 400)         'temporary dimension statement
        Dim lStatsMatrix As New List(Of StatisticsObject)
        Dim pStatisticsObject As New StatisticsObject(Nothing, Nothing)

        'Dim pFeatureWkSp As IFeatureWorkspace
        Dim pDataStats As IDataStatistics
        Dim pCursor As ICursor
        Dim vFeatHbClsVl As Object ' Feature Habitat Class Value (an object because classes can be numbers or string)
        Dim vTemp As Object
        Dim sFeatClassVal As String
        Dim sMatrixVal As String
        Dim dHabArea As Double

        Dim bClassFound As Boolean
        'For k = 1 To UBound(mHabClassVals, 2) vb6
        Dim classComparer As FindStatsClassPredicate
        Dim iStatsMatrixIndex As Integer ' for refining statistics list 
        Dim sClass As String
        Dim vHabTemp As Object

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        pMxDoc = CType(pDoc, IMxDocument)
        pMxDocument = CType(pDoc, IMxDocument)
        pMap = pMxDocument.FocusMap

        ' ================== READ EXTENSION SETTINGS =================
        'Dim sDirection, sDirection2 As String

        Dim bDBF As Boolean = False         ' Include DBF output default 'no'
        Dim pLLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim pPLayersFields As List(Of LayerToAdd) = New List(Of LayerToAdd)
        Dim iPolysCount As Integer = 0      ' number of polygon layers currently using
        Dim iLinesCount As Integer = 0      ' number of lines layers currently using
        Dim HabLayerObj As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property
        ' object to hold stats to add to list. 
        Dim pHabStatsObject_2 As New StatisticsObject_2(Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
        Dim sDirection As String

        If m_FiPEx__1.m_bLoaded = True Then

            sDirection = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("direction"))
            bDBF = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("bDBF"))

            ''Make the direction more readable for dockable window output
            'If sDirection = "up" Then
            '    sDirection2 = "upstream"
            'Else
            '    sDirection2 = "downstream"
            'End If

            ' Populate a list of the layers using and habitat summary fields.
            ' match any of the polygon layers saved in stream to those in listboxes 
            iPolysCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numPolys"))
            If iPolysCount > 0 Then
                For k = 0 To iPolysCount - 1
                    'sPolyLayer = m_FiPEX__1.pPropset.GetProperty("IncPoly" + k.ToString) ' get poly layer
                    HabLayerObj = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncPoly" + k.ToString)) ' get poly layer
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyClassField" + k.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyQuanField" + k.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("PolyUnitField" + k.ToString))
                    End With

                    ' Load that object into the list
                    pPLayersFields.Add(HabLayerObj)  'what are the brackets about - this could be aproblem!!
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            Dim iCount1 As Integer = pPLayersFields.Count

            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    If pPLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for lacustrine layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If

            iLinesCount = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numLines"))
            Dim HabLayerObj2 As New LayerToAdd(Nothing, Nothing, Nothing, Nothing) ' layer to hold parameters to send to property

            ' match any of the line layers saved in stream to those in listboxes
            If iLinesCount > 0 Then
                For j = 0 To iLinesCount - 1
                    'sLineLayer = m_FiPEX__1.pPropset.GetProperty("IncLine" + j.ToString) ' get line layer
                    HabLayerObj2 = New LayerToAdd(Nothing, Nothing, Nothing, Nothing)
                    With HabLayerObj2
                        '.Layer = sLineLayer
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("IncLine" + j.ToString))
                        .ClsField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineClassField" + j.ToString))
                        .QuanField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineQuanField" + j.ToString))
                        .UnitField = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("LineUnitField" + j.ToString))
                    End With
                    ' add to the module level list
                    pLLayersFields.Add(HabLayerObj2)
                Next
            End If

            ' Need to be sure that quantity field has been assigned for each
            ' layer using. 
            iCount1 = pLLayersFields.Count
            If iCount1 > 0 Then
                For m = 0 To iCount1 - 1
                    If pLLayersFields.Item(m).QuanField = "Not set" Then
                        System.Windows.Forms.MessageBox.Show("No habitat quantity parameter set for river layer. Please choose a field in the options menu.", "Parameter Missing")
                        Exit Sub
                    End If
                Next
            End If
        Else
            System.Windows.Forms.MessageBox.Show("Cannot read extension settings.", "Calculate Stats Error")
            Exit Sub
        End If

        ' ======================== PREPARE DOCKABLE WINDOW FOR OUTPUT =================
        'Dim pDockWin As IDockableWindow
        'Dim pDSTDockWin As IDockableWindowDef
        'Dim pDockWinMgr As IDockableWindowManager
        'Dim containedBox As System.Windows.Forms.ListBox
        'pDockWinMgr = CType(My.ArcMap.Application, IDockableWindowManager) 'QI

        'Dim u As New UID


        'If bDockWin = True Then
        '    u.Value = "{5904bd54-d8ec-4dd8-b1e1-9adcb6558d26}"

        '    pDockWin = pDockWinMgr.GetDockableWindow(u)
        '    pDockWin.Show(True)
        '    pDockWin.Dock(esriDockFlags.esriDockShow)

        '    ' If pDockwin works, try to link in and clear the listbox
        '    ' sample code from http://edndoc.esri.com/arcobjects/9.2/NET/ViewCodePages/e439cf8c-778b-4fdb-b4c4-fab51a546ac6ClearLoggingCommand.vb.htm
        '    If pDockWin IsNot Nothing Then
        '        containedBox = TryCast(pDockWin.UserData, System.Windows.Forms.ListBox)
        '    End If

        'End If
        ' ======================== END OLD DOCKWIN CODE =================================

        ' ================ 2.0 Calculate Area and Length ======================
        ' This next section calculates the area or length of selected features
        ' in the TOC.
        '
        ' PROCESS LOGIC:
        '  1.0 For each Feature Layer in the map
        '  1.1 Filter out any excluded features
        '  1.2 Get a list of all fields in the layer
        '  1.3 Combine the polygon and line layers into one list
        '  1.4 Prepare the dockable window 
        '    2.0 For each habitat layer in the new list (polygons and lines)
        '      3.0 If there's a match b/w the current layer and habitat layer in list
        '        4.0 then prepare Dockable Window and DBF tables if need be
        '        4.1 Search for the habitat class field in layer
        '        4.2a If the field is found
        '          5.0a If there is a selection set 
        '            6.0a Get the unique values in that field from the selection set
        '            6.1a Loop through unique values and add each to the left column
        '                of a two-column array/matrix to hold statistics
        '            6.2a For each selected feature in the layer
        '              7.0a Get the value in the habitat class field
        '              7.1a For each unique habitat class value in the statistics matrix
        '                8.0a If it matches the value of the class field found in the current feature
        '                  9.0a then add the value of the quantity field in that feature to the
        '                      quantity field for that row in the matrix
        '        4.2b Else if the habitat class field is not found
        '          5.0b If there is a selection set
        '            6.0b For each feature total up stats
        '          5.1b Send output to dockable window

        pUID = New UID
        pUID.Value = "{E156D7E5-22AF-11D3-9F99-00C04F6BC78E}"

        pEnumLayer = pMap.Layers(pUID, True)
        pEnumLayer.Reset()
        pEnumLayer.Reset()

        ' Look at the next layer in the list
        pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
        Dim iClassCheckTemp As Integer
        Dim iLoopCount As Integer = 0
        Dim dTempQuan As Double

        Do While Not pFeatureLayer Is Nothing ' these two lines must be separate
            If pFeatureLayer.Valid = True Then ' or there will be an empty object ref

                pFeatureSelection = CType(pFeatureLayer, IFeatureSelection)
                pSelectionSet = pFeatureSelection.SelectionSet

                ' get the fields from the featureclass
                pFields = pFeatureLayer.FeatureClass.Fields
                j = 0

                ' Need to combine both polygon and line lists into one
                ' This avoids the need for two loops
                Dim lLayersFields As New List(Of LayerToAdd)
                For j = 0 To pLLayersFields.Count - 1
                    lLayersFields.Add(pLLayersFields(j))
                Next
                j = 0
                For j = 0 To pPLayersFields.Count - 1
                    lLayersFields.Add(pPLayersFields(j))
                Next

                j = 0
                For j = 0 To lLayersFields.Count - 1
                    If lLayersFields(j).Layer = pFeatureLayer.Name Then

                        ' Get the Units of measure, if any
                        sUnit = lLayersFields(j).UnitField
                        If sUnit = "Metres" Then
                            sUnit = "m"
                        ElseIf sUnit = "Kilometres" Then
                            sUnit = "km"
                        ElseIf sUnit = "Square Metres" Then
                            sUnit = "m^2"
                        ElseIf sUnit = "Feet" Then
                            sUnit = "ft"
                        ElseIf sUnit = "Miles" Then
                            sUnit = "mi"
                        ElseIf sUnit = "Square Miles" Then
                            sUnit = "mi^2"
                        ElseIf sUnit = "Hectares" Then
                            sUnit = "ha"
                        ElseIf sUnit = "Acres" Then
                            sUnit = "ac"
                        Else
                            sUnit = "n/a"
                        End If

                        iClassCheckTemp = pFields.FindField(lLayersFields(j).ClsField)
                        'If pFields.FindField(lLayersFields(j).ClsField) <> -1 Then
                        If iClassCheckTemp <> -1 Then

                            ' Reset the stats objects
                            pDataStats = New DataStatistics
                            pStatisticsObject = New StatisticsObject(Nothing, Nothing)
                            ' Clear the statsMatrix
                            lStatsMatrix = New List(Of StatisticsObject)

                            If pFeatureSelection.SelectionSet.Count <> 0 Then
                                pSelectionSet.Search(Nothing, False, pCursor)

                                '' Setup the datastatistics and get the unique values of the "Id" field
                                'Dim pEnum As IEnumerator
                                ''System.Windows.Forms.MessageBox.Show(pSelectionSet.Count.ToString)
                                'With pDataStats
                                '    .Cursor = pCursor
                                '    .Field = lLayersFields(j).ClsField
                                '    '.Field = "Strahler"
                                'End With

                                'pEnum = pDataStats.UniqueValues
                                ''Dim sTemp As String = pDataStats.Field
                                ''Try
                                ''    pEnumVar = CType(pEnum, IEnumVariantSimple)
                                ''Catch ex As Exception
                                ''    System.Windows.Forms.MessageBox.Show(ex.Message.ToString, "Initialize")
                                ''End Try
                                '' Add the top left corner label to matrix
                                ''mHabClassVals(0, 0) = "Classes"
                                pStatisticsObject = New StatisticsObject(Nothing, Nothing)
                                With pStatisticsObject
                                    .UniqueClass = "Classes"
                                    .Quantity = Nothing '***
                                End With
                                lStatsMatrix.Add(pStatisticsObject)

                                pSelectionSet.Search(Nothing, False, pCursor) ' THIS LINE MAY BE REDUNDANT (SEE ABOVE)
                                pFeatureCursor = CType(pCursor, IFeatureCursor)

                                pFeature = pFeatureCursor.NextFeature                            ' For each selected feature
                                Do While Not pFeature Is Nothing
                                    'pFields = pFeature.Fields  '** removed because should be redundant

                                    ' The habitat class field could be a number or a string
                                    ' so the variable used to hold it is an ambiguous object (variant)
                                    vFeatHbClsVl = pFeature.Value(pFields.FindField(lLayersFields(j).ClsField))
                                    'vFeatHbClsVl = pFeature.Value(pFields.FindField("Strahler"))

                                    'dHabArea = Convert.ToDouble(pFeature.Value(pFields.FindField(lLayersFields(j).QuanField)))

                                    ' Loop through each unique habitat class again
                                    ' and check if it matches the class value of the feature
                                    k = 1
                                    bClassFound = False
                                    iStatsMatrixIndex = 0

                                    Try
                                        sClass = Convert.ToString(vFeatHbClsVl)
                                    Catch ex As Exception
                                        MsgBox("The Habitat Class found in the " & lLayersFields(j).Layer & " was not convertible" _
                                        & " to type 'string'.  " & ex.Message)
                                        sClass = "not set"
                                    End Try
                                    If sClass = "" Then
                                        sClass = "not set"
                                    End If

                                    vHabTemp = pFeature.Value(pFields.FindField(lLayersFields(j).QuanField))

                                    Try
                                        dHabArea = Convert.ToDouble(vHabTemp)
                                    Catch ex As Exception
                                        MsgBox("The Habitat Quantity found in the " & lLayersFields(j).Layer & " was not convertible" _
                                        & " to type 'double'.  Null values in field may be responsible. " & ex.Message)
                                        dHabArea = 0
                                    End Try

                                    classComparer = New FindStatsClassPredicate(sClass)
                                    ' use the layer and sink ID to get a refined list of habitat stats for 
                                    ' this sink, layer combo
                                    iStatsMatrixIndex = lStatsMatrix.FindIndex(AddressOf classComparer.CompareStatsClass)
                                    If iStatsMatrixIndex = -1 Then
                                        bClassFound = False
                                        pStatisticsObject = New StatisticsObject(sClass, dHabArea)
                                        lStatsMatrix.Add(pStatisticsObject)
                                    Else
                                        bClassFound = True
                                        lStatsMatrix(iStatsMatrixIndex).Quantity = lStatsMatrix(iStatsMatrixIndex).Quantity + dHabArea
                                    End If

                                    ' Check if the unique class exists in the object list yet
                                    ' if it doesn't trigger flag or add it... 

                                    '' k starts at 1 because the first item in the list will just be column
                                    '' headings
                                    'For k = 1 To lStatsMatrix.Count - 1
                                    '    'vMatClmnVl = mHabClassVals(0, k) vb6
                                    '    sMatrixVal = lStatsMatrix(k).UniqueClass
                                    '    If Len(sFeatClassVal) <> 0 And Len(sMatrixVal) <> 0 Then
                                    '        If sMatrixVal = sFeatClassVal Then

                                    '            ' Get the summary field and add the value to the
                                    '            ' total for habitat area.
                                    '            ' ** ==> Multiple fields could be added here in a 'for' loop.
                                    '            'lFieldVal = pFields.FindField(m_aHabSumFld(j))
                                    '            ' Insert into the corresponding column of the second
                                    '            ' row the updated habitat area measurement.
                                    '            'mHabClassVals(1, k) = mHabClassVals(1, k) + lHabArea vb6
                                    '            lStatsMatrix(k).Quantity = lStatsMatrix(k).Quantity + dHabArea
                                    '            sTemp = lStatsMatrix(k).UniqueClass.ToString
                                    '        End If
                                    '        'ElseIf Len(sFeatClassVal) <>  Then
                                    '    End If
                                    'Next ' unique habitat class

                                    pFeature = pFeatureCursor.NextFeature

                                Loop     ' selected feature

                                'k = 0
                                'Dim dTemp As Double
                                'For k = 0 To lStatsMatrix.Count - 1
                                '    Dim sTemp2 As String = lStatsMatrix(k).UniqueClass
                                '    dTemp = lStatsMatrix(k).Quantity
                                'Next

                            End If ' There is a selection set

                            '' Print Quantity Field
                            'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                            'pResultsForm.txtRichResults.AppendText("        Quantity Field (" + sUnit + "): ")
                            'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Italic)
                            'pResultsForm.txtRichResults.AppendText(lLayersFields(j).QuanField + Environment.NewLine)

                            '' Print Class Field
                            'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                            'pResultsForm.txtRichResults.AppendText("        Class Field: ")
                            'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Italic)
                            'pResultsForm.txtRichResults.AppendText(lLayersFields(j).ClsField + Environment.NewLine)

                            '' add 'columns' for each
                            'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                            'pResultsForm.txtRichResults.AppendText("        <class> / <habitat>" + Environment.NewLine)

                            'If bDockWin = True Then
                            '    If containedBox IsNot Nothing Then
                            '        containedBox.Items.Add("   Quantity Field: " + lLayersFields(j).QuanField)
                            '        containedBox.Items.Add("      Class Field: " + lLayersFields(j).ClsField)
                            '    End If
                            'End If ' bDockWin True

                            ' If there are items in the stats matrix
                            If lStatsMatrix.Count <> 0 Then
                                k = 1
                                ' For each unique value in the matrix
                                ' (always skip first row of matrix as it is the 'column headings')
                                For k = 1 To lStatsMatrix.Count - 1
                                    'If bDBF = True Then

                                    pHabStatsObject_2 = New StatisticsObject_2(Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
                                    With pHabStatsObject_2
                                        .Layer = pFeatureLayer.Name
                                        .LayerID = pFeatureLayer.FeatureClass.FeatureClassID
                                        .bID = ID
                                        .bEID = iEID
                                        .bType = sType
                                        .Sink = f_sOutID
                                        .SinkEID = f_siOutEID
                                        .Direction = sDirection2
                                        .TotalImmedPath = sHabTypeKeyword
                                        .UniqueClass = CStr(lStatsMatrix(k).UniqueClass)
                                        .ClassName = CStr(lLayersFields(j).ClsField)
                                        .Quantity = lStatsMatrix(k).Quantity
                                        .Unit = sUnit
                                    End With
                                    lHabStatsList.Add(pHabStatsObject_2)

                                    'End If

                                    If sUnit = "n/a" Then
                                        'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                                        'pResultsForm.txtRichResults.AppendText("         " & lStatsMatrix(k).UniqueClass & "    " & Format(lStatsMatrix(k).Quantity, "0.00") & Environment.NewLine)
                                    Else
                                        'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                                        'pResultsForm.txtRichResults.AppendText("         " & lStatsMatrix(k).UniqueClass & "    " & Format(lStatsMatrix(k).Quantity, "0.00") & sUnit & Environment.NewLine)
                                    End If
                                Next

                                ' Insert a line break
                                'pResultsForm.txtRichResults.AppendText(Environment.NewLine)

                            Else ' If there are no statistics
                                'If bDBF = True Then

                                pHabStatsObject_2 = New StatisticsObject_2(Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
                                With pHabStatsObject_2
                                    .Layer = pFeatureLayer.Name
                                    .LayerID = pFeatureLayer.FeatureClass.FeatureClassID
                                    .bID = ID
                                    .bEID = iEID
                                    .bType = sType
                                    .Sink = f_sOutID
                                    .SinkEID = f_siOutEID
                                    .Direction = sDirection
                                    .TotalImmedPath = sHabTypeKeyword
                                    .UniqueClass = "none"
                                    .ClassName = CStr(lLayersFields(j).ClsField)
                                    .Quantity = 0.0
                                    .Unit = sUnit
                                End With
                                lHabStatsList.Add(pHabStatsObject_2)

                                '                            End If

                                ' If no stats found then add zeros
                                If sUnit = "n/a" Then
                                    'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                                    'pResultsForm.txtRichResults.AppendText("         none    0.00" & Environment.NewLine)
                                Else
                                    'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                                    'pResultsForm.txtRichResults.AppendText("         none    0.00" & sUnit & Environment.NewLine)
                                End If


                                'If bDockWin = True Then
                                '    If containedBox IsNot Nothing Then
                                '        If sUnit = "n/a" Then
                                '            containedBox.Items.Add("            " & "0.00")
                                '        Else
                                '            containedBox.Items.Add("            " & "0.00" & sUnit)
                                '        End If
                                '    End If
                                'End If
                            End If ' There are items in the statsmatrix

                            '' Insert a line break
                            'pResultsForm.txtRichResults.AppendText(Environment.NewLine)

                        Else   ' if the habitat class case field is not found


                            '' Reset the stats objects
                            ''---------TEMP----------
                            'pDataStats = New DataStatistics
                            'pStatisticsObject = New StatisticsObject(Nothing, Nothing)
                            '' Clear the statsMatrix
                            'lStatsMatrix = New List(Of StatisticsObject)
                            '' -------- END TEMP -----------

                            dTotalArea = 0

                            If pFeatureSelection.SelectionSet.Count <> 0 Then

                                pFeatureSelection.SelectionSet.Search(Nothing, False, pCursor)

                                pFeatureCursor = CType(pCursor, IFeatureCursor)
                                pFeature = pFeatureCursor.NextFeature

                                ' Get the summary field and add the value to the
                                ' total for habitat area.
                                ' ** ==> Multiple fields could be added here in a 'for' loop.

                                iFieldVal = pFeatureCursor.FindField(lLayersFields(j).QuanField)
                                
                                ' For each selected feature
                                m = 1
                                Do While Not pFeature Is Nothing
                                    Try
                                        vTemp = pFeature.Value(iFieldVal)
                                    Catch ex As Exception
                                        MsgBox("Could not convert quantity field found in " + lLayersFields(j).Layer.ToString + _
                                               " was not convertible to type 'double'.  Null values in field may be responsible. " & ex.Message)
                                        vTemp = 0
                                    End Try
                                    Try
                                        dTempQuan = Convert.ToDouble(vTemp)
                                    Catch ex As Exception
                                        MsgBox("Could not convert the habitat quantity value found in the" + _
                                        lLayersFields(j).Layer.ToString + ". Was not convertable to type 'double'." + _
                                        ex.Message)
                                        dTempQuan = 0
                                    End Try
                                    ' Insert into the corresponding column of the second
                                    ' row the updated habitat area measurement.
                                    dTotalArea = dTotalArea + dTempQuan
                                    pFeature = pFeatureCursor.NextFeature
                                Loop     ' selected feature
                            End If ' there are selected features

                            ' If DBF tables are to be output
                            'If bDBF = True Then

                            pHabStatsObject_2 = New StatisticsObject_2(Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
                            With pHabStatsObject_2
                                .Layer = pFeatureLayer.Name
                                .LayerID = pFeatureLayer.FeatureClass.FeatureClassID
                                .bID = ID
                                .bEID = iEID
                                .bType = sType
                                .Sink = f_sOutID
                                .SinkEID = f_siOutEID
                                .Direction = sDirection2
                                .TotalImmedPath = sHabTypeKeyword
                                .UniqueClass = "none"
                                .ClassName = CStr(lLayersFields(j).ClsField)
                                .Quantity = dTotalArea
                                .Unit = sUnit
                            End With
                            lHabStatsList.Add(pHabStatsObject_2)

                            'End If ' DBF tables output

                            '' Print Quantity Field
                            'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                            'pResultsForm.txtRichResults.AppendText("        Quantity Field (" + sUnit + "): ")
                            'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Italic)
                            'pResultsForm.txtRichResults.AppendText(lLayersFields(j).QuanField + Environment.NewLine)

                            '' add 'columns' for each
                            'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                            'pResultsForm.txtRichResults.AppendText("        <habitat>" + Environment.NewLine)

                            If sUnit = "n/a" Then
                                'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                                'pResultsForm.txtRichResults.AppendText("        " & Format(dTotalArea, "0.00") & Environment.NewLine)
                            Else
                                'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Regular)
                                'pResultsForm.txtRichResults.AppendText("        " & Format(dTotalArea, "0.00") & sUnit & Environment.NewLine)
                            End If

                            'If bDockWin = True Then
                            '    If containedBox IsNot Nothing Then
                            '        containedBox.Items.Add("   Quantity Field: " + lLayersFields(j).QuanField)
                            '        If sUnit = "n/a" Then
                            '            containedBox.Items.Add("            " & Format(dTotalArea, "0.00"))
                            '        Else
                            '            containedBox.Items.Add("            " & Format(dTotalArea, "0.00") & sUnit)
                            '        End If
                            '    End If

                            'End If

                            '' Insert a line break
                            'pResultsForm.txtRichResults.AppendText(Environment.NewLine)

                        End If ' found habitat class field in layer

                        ' increment the loop counter for
                        iLoopCount = iLoopCount + 1

                    End If     ' feature layer matches hab class layer
                Next           ' habitat layer
            End If ' featurelayer is valid
            pFeatureLayer = CType(pEnumLayer.Next, IFeatureLayer)
        Loop

    End Sub
    Private Sub UpdateSummaryTable(ByRef lRefinedHabStatsList As List(Of StatisticsObject_2), ByRef iHabRowCount As Integer, _
    ByRef pResultsForm3 As FiPEX_AddIn_dotNet35_2.frmResults_3, ByRef iMaxRowIndex As Integer, ByRef iBarrIndex As Integer, _
    ByRef bColorSwitcher As Boolean, ByRef iSinkRowCount As Integer, ByRef iBarrRowCount As Integer, ByVal bSinkVisit As Boolean)

        Dim m As Integer = 0
        Dim iThisRowIndex As Integer
        Dim pDataGridViewCellStyle As System.Windows.Forms.DataGridViewCellStyle
        Dim bTrigger As Boolean = False
        Dim sLayer, sDirection, sTraceType, sClass, sUnit As String
        Dim dTotalHab, dQuantity As Double

        ' For each habitat stat in the refined list
        For m = 0 To lRefinedHabStatsList.Count - 1

            ' if it's the first habitat item in the list
            ' then it's going on the barrierindex line
            ' otherwise it's habrowindex + habrowcount
            ' if that number exceeds the Max row index
            ' then a new row will need to be inserted
            If (iBarrIndex + iHabRowCount) > iMaxRowIndex Then
                iMaxRowIndex = pResultsForm3.DataGridView1.Rows.Add()
                iThisRowIndex = iMaxRowIndex
                iSinkRowCount += 1
                If bSinkVisit = False Then
                    iBarrRowCount += 1
                End If
                bTrigger = True
            Else
                iThisRowIndex = iBarrIndex + iHabRowCount
            End If

            If bColorSwitcher = True Then
                pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(7).Style
                pDataGridViewCellStyle.BackColor = Color.Lavender
            Else
                pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(7).Style
                pDataGridViewCellStyle.BackColor = Color.Powderblue
            End If
            pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(7).Style = pDataGridViewCellStyle
            pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(8).Style = pDataGridViewCellStyle
            pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(9).Style = pDataGridViewCellStyle
            pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(10).Style = pDataGridViewCellStyle
            pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(11).Style = pDataGridViewCellStyle
            pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(12).Style = pDataGridViewCellStyle

            ' if the row count of the habitat metrics exceeds the 
            ' statistics metrics then the colors of cells below the metrics
            ' will also have to be changed
            If bTrigger = True Then
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(3).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(4).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(5).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(6).Style = pDataGridViewCellStyle
            End If
            'End If

            If m = 0 Then
                sLayer = lRefinedHabStatsList(m).Layer
                sDirection = lRefinedHabStatsList(m).Direction
                sTraceType = lRefinedHabStatsList(m).TotalImmedPath
                sUnit = lRefinedHabStatsList(m).Unit

                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(7).Value = sLayer
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(8).Value = sDirection
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(9).Value = sTraceType
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(12).Value = sUnit
            End If

            sClass = lRefinedHabStatsList(m).UniqueClass
            dQuantity = Math.Round(lRefinedHabStatsList(m).Quantity, 2)
            pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(10).Value = sClass
            pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(11).Value = dQuantity

            dTotalHab = dTotalHab + lRefinedHabStatsList(m).Quantity
            iHabRowCount += 1

            ' Add the total field if necessary
            If m = lRefinedHabStatsList.Count - 1 Then

                If (iBarrIndex + iHabRowCount) > iMaxRowIndex Then
                    iMaxRowIndex = pResultsForm3.DataGridView1.Rows.Add()
                    iThisRowIndex = iMaxRowIndex
                    iSinkRowCount += 1
                    If bSinkVisit = False Then
                        iBarrRowCount += 1
                    End If
                    bTrigger = True
                Else
                    iThisRowIndex = iBarrIndex + iHabRowCount
                End If

                pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(11).Style
                pDataGridViewCellStyle.Font = New Font(pResultsForm3.DataGridView1.Font.FontFamily, pResultsForm3.DataGridView1.Font.Size, FontStyle.Bold)
                pDataGridViewCellStyle.BackColor = Color.SlateGray
                'pDataGridViewCellStyle.ForeColor = Color.White
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(12).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(11).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(10).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(9).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(8).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(7).Style = pDataGridViewCellStyle

                ' If the habitat row exceeds maximum metric row then 
                ' color the cells below the metric row appropriately
                If bTrigger = True And bColorSwitcher = True Then
                    pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(5).Style
                    pDataGridViewCellStyle.BackColor = Color.Lavender
                ElseIf bTrigger = True And bColorSwitcher = False Then
                    pDataGridViewCellStyle = pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(5).Style
                    pDataGridViewCellStyle.BackColor = Color.Powderblue
                End If
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(3).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(4).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(5).Style = pDataGridViewCellStyle
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(6).Style = pDataGridViewCellStyle
                ' for border adjustment
                'dataGridViewAdvancedBorderStyleInput = pResultsForm3.DataGridView1.Rows(iHabRowIndex).DefaultCellStyle(8).
                'dataGridViewAdvancedBorderStylePlaceHolder = dataGridViewAdvancedBorderStyleInput
                'dataGridViewAdvancedBorderStylePlaceHolder.Top = System.Windows.Forms.DataGridViewAdvancedCellBorderStyle.InsetDouble

                'pResultsForm3.DataGridView1.Rows(iHabRowIndex).Cells(8).AdjustCellBorderStyle(dataGridViewAdvancedBorderStyleInput, dataGridViewAdvancedBorderStylePlaceHolder, False, False, False, False)
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(10).Value = "Total"
                pResultsForm3.DataGridView1.Rows(iThisRowIndex).Cells(11).Value = Math.Round(dTotalHab, 2)

                iHabRowCount += 1

            End If
        Next

        '' Switch the color switcher
        'If bColorSwitcher = True Then
        '    bColorSwitcher = False
        'Else
        '    bColorSwitcher = True
        'End If


    End Sub
    Private Sub GLPKShellCall(ByVal sGLPKHabitatTableName As String, _
                              ByVal sGLPKOptionsTableName As String, _
                              ByVal sGLPKConnectTabName As String, _
                              ByVal iMaxOptions As Integer, _
                              ByVal iSinkEID As Integer, _
                              ByRef pFWorkspace As IFeatureWorkspace, _
                              ByRef iProgress1 As Integer)
        ' ====================================================================
        ' SubRoutine:    GLPK GNUwin Shell Call
        ' Author:        Greig Oldford
        ' Created For:   DFO Maritimes
        '
        ' Description:
        '             Runs the GLPK Optimization Model on the network and other CSV files 
        '             First overwrites a data file containing parameters 
        '             BUDGET     - budget for this analysis 
        '             TIME LIMIT - second time limit to GLPK run
        '             MAX OPTIONS - max number of options at any node 
        '             FIRST NODE - network sink
        '
        ' Logic:
        '       exports already created FC GDB Tables to CSV's in the GLPK Model folder
        '       iteratively runs the GLPK model for incremental budget amounts.  


        Dim bGLPKTables As Boolean = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("bGLPKTables"))
        Dim sGLPKModelDir As String = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sGLPKModelDir"))
        Dim sGnuWinDir As String = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sGnuWinDir"))
        Dim sGLPKTreatment As String '= Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sGLPKTreatment")) 'to name the treatment (optional)
        Dim dBudgetIncrement As Double '= Convert.ToDouble(m_FiPEx__1.pPropset.GetProperty("dGLPKBudgetIncrement"))
        Dim dMinBudget As Double '= Convert.ToDouble(m_FiPEx__1.pPropset.GetProperty("dGLPKMinBudget"))
        Dim dMaxBudget As Double '= Convert.ToDouble(m_FiPEx__1.pPropset.GetProperty("dGLPKMaxBudget"))
        Dim iTimeLimit As Integer '= Convert.ToInt16(m_FiPEx__1.pPropset.GetProperty("iGLPKTimeLimit"))
        Dim sPrefix As String = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("TabPrefix"))

        'TEMP HARDCODE!
        bGLPKTables = True
        sGLPKModelDir = "c:\GunnsModel"
        sGnuWinDir = "C:\gnuwin32"
        sGLPKTreatment = "July21_SHH_Areas"
        dBudgetIncrement = 60
        dMinBudget = 15
        dMaxBudget = 2000
        iTimeLimit = 50
        Dim dBudget As Double
        Dim bGLPKSolved As Boolean = False
        Dim dPercGap As Double
        Dim dTimeUsed As Double
        Dim iSolutionFoundRow As Integer = 0
        Dim dMaxHabitat As Double = 0

        Dim sSplitTimeUsed As String
        Dim sSplitTimeUsedFirstHalf As String
        Dim sSplitTimeUsedFirstHalf2 As String
        Dim pTable As ITable
        'Dim pCursor As ICursor
        Dim i As Integer
        Dim pTxtFactory As IWorkspaceFactory = New TextFileWorkspaceFactory

        Dim pFWorkspaceOut As IFeatureWorkspace
        Dim pWorkspaceOut As IWorkspace
        Dim sw As StreamWriter
        ' Get output workspace
        pWorkspaceOut = pTxtFactory.OpenFromFile(sGLPKModelDir, My.ArcMap.Application.hWnd)
        pFWorkspaceOut = CType(pWorkspaceOut, IFeatureWorkspace)

        Dim sOutputFile(0) As String
        Dim sModelFile(0) As String
        Dim sPreviousOutputLine As String
        Dim sPreviousOutputLineSplit(1) As String
        Dim pGLPKResultsObject As New GLPKResultsObject(Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
        Dim n As Integer
        Dim pGLPKDecisionsObject As New GLPKDecisionsObject(Nothing, Nothing, Nothing, Nothing)
        Dim lGLPKDecisionsObject As New List(Of GLPKDecisionsObject)
        Dim sDecisionOutputSplit(2) As String
        Dim iDecisionEID, iDecisionNum As Integer
        ' Check that user has write permissions in output workspace
        'Dim pc As New CheckPerm
        'pc.Permission = "Modify"
        'If Not pc.CheckPerm(sDCIModelDir) Then
        '    MsgBox("You do not have the necessary permission to create, delete, or modify files in the DCI Model installation directory." + _
        '    " Please change directory, attain necessary permissions, or uncheck DCI Output checkbox in 'Advanced Tab' of Options Menu.")
        '    Exit Sub
        'End If

        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        If iProgress1 < 70 Then
            iProgress1 = iProgress1 + 1
        End If
        backgroundworker1.ReportProgress(iProgress1, "Performing Optimization Analysis" & ControlChars.NewLine & _
                                                     "Checking User permissions in output directory.")


        ' Check that the user currently has file permissions to write to 
        ' this directory
        Dim bPermissionCheck
        bPermissionCheck = FileWriteDeleteCheck(sGLPKModelDir)
        If bPermissionCheck = False Then
            MsgBox("File / folder permission check: " & Str(bPermissionCheck))
            MsgBox("It appears you do not have write permission to the DCI Model Directory.  Write permission to this directory is needed in order to run DCI Analysis.")
            Exit Sub
        End If

        Dim pExportOp As IExportOperation = New ExportOperation
        Dim pDataSetIn As IDataset
        Dim pDataSetOut As IDataset
        Dim pDSNameIn As IDatasetName
        Dim pDSNameOut As IDatasetName
        Dim FileToDelete As String

        ' Get the output dataset name ready.
        pDataSetOut = CType(pWorkspaceOut, IDataset)

        ' Take DBF habitat tables in geodatabase workspace
        ' and print it to the new text/csv file

        ' export three tables to output directory:
        ' 1 options
        ' 2 connectivity
        ' 3 habitat
        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        If iProgress1 < 70 Then
            iProgress1 = iProgress1 + 1
        End If
        backgroundworker1.ReportProgress(iProgress1, "Performing Optimization Analysis" & ControlChars.NewLine & _
                                                     "Exporting connectivity table to GLPK Model Directory.")

        ' ============ EXPORT CONNECTIVITY TABLE TO CSV ==============
        ' Delete the table if it already exists
        FileToDelete = sGLPKModelDir + "/FIPEX_GLPKConnectivity.csv"
        If System.IO.File.Exists(FileToDelete) = True Then
            System.IO.File.Delete(FileToDelete)

            ' need to reset the workspace so the file list will refresh and
            ' arcgis will know the file doesn't exist now.
            pWorkspaceOut = pTxtFactory.OpenFromFile(sGLPKModelDir, 0)
            pFWorkspaceOut = CType(pWorkspaceOut, IFeatureWorkspace)
            pDataSetOut = CType(pWorkspaceOut, IDataset)
        End If

        pExportOp = New ExportOperation

        ' Get input table
        pTable = pFWorkspace.OpenTable(sGLPKConnectTabName)

        ' Get the dataset name for the input table
        pDataSetIn = CType(pTable, IDataset)
        pDSNameIn = CType(pDataSetIn.FullName, IDatasetName)

        ' Get dataset for output table
        pDSNameOut = New TableName
        pDSNameOut.Name = "FIPEX_GLPKConnectivity.csv"
        pDSNameOut.WorkspaceName = CType(pDataSetOut.FullName, IWorkspaceName)

        Try
            pExportOp.ExportTable(pDSNameIn, Nothing, Nothing, pDSNameOut, My.ArcMap.Application.hWnd)
        Catch ex As Exception
            MsgBox("Error trying to export DBF table to DCI Directory. " & ex.Message)
        End Try


        ' ======== EXPORT HABITAT TABLE TO CSV ==========
        ' Convert the habitat table

        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        If iProgress1 < 70 Then
            iProgress1 = iProgress1 + 1
        End If
        backgroundworker1.ReportProgress(iProgress1, "Performing Optimization Analysis" & ControlChars.NewLine & _
                                         "Exporting habitat table to GLPK Model Directory.")


        pExportOp = New ExportOperation

        ' Input table
        pTable = pFWorkspace.OpenTable(sGLPKHabitatTableName)

        ' Get the dataset name for the input table
        pDataSetIn = CType(pTable, IDataset)
        pDSNameIn = CType(pDataSetIn.FullName, IDatasetName)

        ' Delete the table if it already exists
        FileToDelete = sGLPKModelDir + "/FIPEX_GLPKHabitat.csv"
        If System.IO.File.Exists(FileToDelete) = True Then
            System.IO.File.Delete(FileToDelete)
        End If

        ' Get dataset for output table and export
        pDSNameOut = New TableName
        pDSNameOut.Name = "FIPEX_GLPKHabitat.csv"
        pDSNameOut.WorkspaceName = CType(pDataSetOut.FullName, IWorkspaceName)

        Try
            pExportOp.ExportTable(pDSNameIn, Nothing, Nothing, pDSNameOut, My.ArcMap.Application.hWnd)
        Catch ex As Exception
            MsgBox("Error exporting connectivity table to GLPK Directory. " & ex.Message)
        End Try

        ' ======== EXPORT OPTIONS TABLE TO CSV ==========
        ' Convert the options table

        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        If iProgress1 < 70 Then
            iProgress1 = iProgress1 + 1
        End If
        backgroundworker1.ReportProgress(iProgress1, "Performing Optimization Analysis" & ControlChars.NewLine & _
                                         "Exporting options table to GLPK Model Directory.")


        pExportOp = New ExportOperation

        ' Input table
        pTable = pFWorkspace.OpenTable(sGLPKOptionsTableName)

        ' Get the dataset name for the input table
        pDataSetIn = CType(pTable, IDataset)
        pDSNameIn = CType(pDataSetIn.FullName, IDatasetName)

        ' Delete the table if it already exists
        FileToDelete = sGLPKModelDir + "/FIPEX_GLPKOptions.csv"
        If System.IO.File.Exists(FileToDelete) = True Then
            System.IO.File.Delete(FileToDelete)
        End If

        ' Get dataset for output table and export
        pDSNameOut = New TableName
        pDSNameOut.Name = "FIPEX_GLPKOptions.csv"
        pDSNameOut.WorkspaceName = CType(pDataSetOut.FullName, IWorkspaceName)

        Try
            pExportOp.ExportTable(pDSNameIn, Nothing, Nothing, pDSNameOut, My.ArcMap.Application.hWnd)
        Catch ex As Exception
            MsgBox("Error exporting connectivity table to GLPK Directory. " & ex.Message)
        End Try

        ' ==== PRIOR TO ANALYSIS SEARCH AND REPLACE PATH TXT IN MODEL FILE ===
        '  search and replace 
        ' replace c:\GunnsModel\ 
        ' with path to Model DIR (sGLPKModelDir)

        If m_bCancel = True Then
            backgroundworker1.CancelAsync()
            backgroundworker1.Dispose()
            Exit Sub
        End If
        If iProgress1 < 70 Then
            iProgress1 = iProgress1 + 1
        End If
        backgroundworker1.ReportProgress(iProgress1, "Performing Optimization Analysis" & ControlChars.NewLine & _
                                         "Rewriting Gunns Model file with user output directory.")


        If System.IO.File.Exists(sGLPKModelDir + "/May25_EldonsModel_FiPEx.mod") = True Then
            sModelFile = System.IO.File.ReadAllLines(sGLPKModelDir + "/May25_EldonsModel_FiPEx.mod")
        End If

        n = 0
        For n = 0 To sModelFile.GetUpperBound(0)
            If sModelFile(n).Contains("C:\GunnsModel_REPLACE") = True Then
                sModelFile(n) = sModelFile(n).Replace("C:\GunnsModel_REPLACE", sGLPKModelDir)
            End If
        Next

        ' overwrite file
        System.IO.File.WriteAllLines(sGLPKModelDir + "/May25_EldonsModel_FiPEx.mod", sModelFile)

        Dim lGLPKResultsObject As New List(Of GLPKResultsObject)

        Dim iTotalBudgetIncrements As Integer
        iTotalBudgetIncrements = Convert.ToInt16((dMaxBudget - dMinBudget) / dBudgetIncrement)
        Dim iAnalysisCounter As Integer = 0
        Dim iEstimatedMaxTimeRemaining As Integer


        ' ========== FOR EACH BUDGET AMOUNT ===============
        ' Do until Max budget is exceeded

        dBudget = dMinBudget
        Do Until dBudget > dMaxBudget


            ' ========== WRITE / OVERWRITE .DAT MODEL PARAMETERS FILE ===========
            ' Delete the table if it already exists
            FileToDelete = sGLPKModelDir + "/modelparameters.dat"
            If System.IO.File.Exists(FileToDelete) = True Then
                System.IO.File.Delete(FileToDelete)
            End If

            Try
                sw = File.CreateText(sGLPKModelDir + "/modelparameters.dat")
                sw.WriteLine("data;")
                sw.WriteLine("param FirstNod:=" + Convert.ToString(iSinkEID) + ";")
                sw.WriteLine("param mOptions:=" + Convert.ToString(iMaxOptions) + ";")
                sw.WriteLine("param Budget:=" + Convert.ToString(dBudget) + ";")
                sw.Close()

            Catch e As Exception
                MsgBox("The modelparameters.dat file in the GLPK Model directory could not be written to.  The following exception was found: " & e.Message)

            End Try

            ' ===== CALL THE MODEL AND WAIT TILL COMPLETED ========\
            ' will need to call the model as a batch executable. 
            ' the model executable will need to be rewritten each time
            ' to adapt for path name variations

            FileToDelete = sGLPKModelDir + "/FiPEX_GLPSOLCommand.bat"
            If System.IO.File.Exists(FileToDelete) = True Then
                System.IO.File.Delete(FileToDelete)
            End If

            Try
                sw = File.CreateText(sGLPKModelDir + "/FiPEX_GLPSOLCommand.bat")
                sw.WriteLine("@ECHO ON")
                sw.WriteLine(":BEGIN")
                If iTimeLimit = 0 Then
                    sw.WriteLine(sGnuWinDir + "\bin\glpsol -m " + sGLPKModelDir + "\May25_EldonsModel_FiPEx.mod -d " + sGLPKModelDir + "\modelparameters.dat >" + sGLPKModelDir + "\outputMay251.txt")
                Else
                    sw.WriteLine(sGnuWinDir + "\bin\glpsol -m " + sGLPKModelDir + "\May25_EldonsModel_FiPEx.mod -d " + sGLPKModelDir + "\modelparameters.dat --tmlim " + Convert.ToString(iTimeLimit) + " >" + sGLPKModelDir + "\outputMay251.txt")
                End If
                sw.WriteLine(":END")
                sw.Close()

            Catch e As Exception
                MsgBox("The FiPEX_GLPSOLCommand.bat file could not be written to.  The following exception was found: " & e.Message)
                Exit Sub

            End Try

            ' notify user of time remaining
            iAnalysisCounter += 1
            iEstimatedMaxTimeRemaining = iTimeLimit * (iTotalBudgetIncrements - iAnalysisCounter)
            If m_bCancel = True Then
                backgroundworker1.CancelAsync()
                backgroundworker1.Dispose()
                Exit Sub
            End If
            If iProgress1 < 70 Then
                iProgress1 = iProgress1 + 1
            End If
            If iAnalysisCounter > iTotalBudgetIncrements Then
                iTotalBudgetIncrements = iAnalysisCounter
            End If
            backgroundworker1.ReportProgress(iProgress1, "Performing Optimization Analysis" & ControlChars.NewLine & _
                                             iAnalysisCounter.ToString & " of ~" & iTotalBudgetIncrements.ToString & " rounds" & ControlChars.NewLine & _
                                             "Estimated time remaining for optimization (max): " & iEstimatedMaxTimeRemaining.ToString & "sec.")
            Shell(sGLPKModelDir + "/FiPEX_GLPSOLCommand.bat", AppWinStyle.MinimizedNoFocus, True)

            ' ==== READ OUTPUT DECISION CSV AND UPDATE DECISION OBJECT ========
            pGLPKResultsObject = New GLPKResultsObject(Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)

            ' ------------------------------
            ' GET SINKEID iSinkEID
            pGLPKResultsObject.SinkEID = iSinkEID
            ' ------------------------------
            ' GET BUDGET dBudget
            pGLPKResultsObject.Budget = dBudget
            ' ------------------------------
            ' GET TREATMENT sGLPKTreatment
            pGLPKResultsObject.Treatment_Name = sGLPKTreatment
            ' ------------------------------
            ' GET GLPK_SOLVED bGLPKSolved
            If System.IO.File.Exists(sGLPKModelDir + "/outputMay251.txt") = True Then
                sOutputFile = System.IO.File.ReadAllLines(sGLPKModelDir + "/outputMay251.txt")
            End If

            n = 0
            bGLPKSolved = False
            For n = 0 To sOutputFile.GetUpperBound(0)
                If sOutputFile(n).Contains("INTEGER OPTIMAL SOLUTION FOUND") = True Then
                    bGLPKSolved = True
                    iSolutionFoundRow = n
                    Exit For
                End If
            Next

            pGLPKResultsObject.GLPK_Solved = bGLPKSolved
            Try
                ' ------------------------------
                ' GET PERCENT GAP dPercGap
                If bGLPKSolved = True Then
                    dPercGap = 0.0
                Else
                    n = 0
                    For n = 0 To sOutputFile.GetUpperBound(0)
                        If sOutputFile(n).Contains("TIME LIMIT EXCEEDED; SEARCH TERMINATED") = False Then
                            sPreviousOutputLine = sOutputFile(n)
                        Else
                            ' found the last line before the 'time limit exceeded' warning
                            ' search for the '%' and keep the three digits prior as the Perc gap
                            sPreviousOutputLineSplit = sPreviousOutputLine.Split("%")
                            sPreviousOutputLine = sPreviousOutputLineSplit(0)
                            ' now trim all but the last four characters
                            dPercGap = Convert.ToDouble(sPreviousOutputLine.Remove(0, sPreviousOutputLine.Length - 4))
                            Exit For
                        End If
                    Next

                End If

                pGLPKResultsObject.Perc_Gap = dPercGap

                ' ---------------------------
                ' GET TIME USED iTimeLimit
                pGLPKResultsObject.MaxSolTime = iTimeLimit

                ' ---------------------------
                ' GET TIME USED dTimeUsed
                If bGLPKSolved = True Then
                    ' split output file 'time used:   0.1 secs"
                    sSplitTimeUsed = sOutputFile(iSolutionFoundRow + 1)
                    sSplitTimeUsedFirstHalf = sSplitTimeUsed.Remove(0, 10)
                    sSplitTimeUsedFirstHalf2 = sSplitTimeUsedFirstHalf.TrimEnd("s", "e", "c")
                    dTimeUsed = Convert.ToDouble(sSplitTimeUsedFirstHalf2)
                Else
                    dTimeUsed = iTimeLimit
                End If

                pGLPKResultsObject.TimeUsed = dTimeUsed

                ' --------------------------
                ' GET HABITAT ZMAX
                If System.IO.File.Exists(sGLPKModelDir + "/ZMaxOutput.txt") = True Then
                    sOutputFile = System.IO.File.ReadAllLines(sGLPKModelDir + "/ZMaxOutput.txt")
                    dMaxHabitat = Convert.ToDouble(sOutputFile(1))
                Else
                    dMaxHabitat = 0
                End If

                pGLPKResultsObject.Habitat_ZMax = dMaxHabitat
                lGLPKResultsObject.Add(pGLPKResultsObject)

                ' ===== READ THE DECISIONS INTO AN OBJECT ===========


                ' open output res2.csv (could be res1) and read each line
                If System.IO.File.Exists(sGLPKModelDir + "/Res1.csv") = True Then

                    sOutputFile = System.IO.File.ReadAllLines(sGLPKModelDir + "/Res1.csv")
                    n = 1
                    ' split each line up, write to master list for this treatment
                    For n = 1 To sOutputFile.GetUpperBound(0)
                        sDecisionOutputSplit = sOutputFile(n).Split(",")
                        iDecisionEID = Convert.ToInt32(sDecisionOutputSplit(0))
                        iDecisionNum = Convert.ToInt16(sDecisionOutputSplit(1))
                        pGLPKDecisionsObject = New GLPKDecisionsObject(dBudget, sGLPKTreatment, iDecisionEID, iDecisionNum)
                        lGLPKDecisionsObject.Add(pGLPKDecisionsObject)
                    Next
                Else
                    ' contingency code on fail.  should be a goto error 
                End If

            Catch ex As Exception
                MsgBox("Crash." + ex.Message)
            End Try
            dBudget = dBudget + dBudgetIncrement
        Loop

        ' ===== PREP OUTPUT RESULTS TABLES =======
        ' ----------------
        ' Table 1
        ' Get Table1 Name
        Dim sGLPKResultsTableName As String
        sGLPKResultsTableName = TableName("GLPKResults", pFWorkspace, sPrefix)
        PrepGLPKResultsOutTable(sGLPKResultsTableName, pFWorkspace)
        ' Populate Table

        Dim pRowBuffer As IRowBuffer
        Dim pCursor As ICursor

        pTable = pFWorkspace.OpenTable(sGLPKResultsTableName)
        n = 0
        For n = 0 To lGLPKResultsObject.Count - 1
            '  SinkEID (integer)
            '  Treatment (string)
            '  Budget (double)
            '  GLPKSolved (boolean/binary)
            '  Perc_Gap (double)
            '  MAxSolTime(integer)
            '  TimeUsed(double)
            '  HabitatZmax(double)
            pRowBuffer = pTable.CreateRowBuffer
            pRowBuffer.Value(1) = lGLPKResultsObject(n).SinkEID
            pRowBuffer.Value(2) = lGLPKResultsObject(n).Treatment_Name
            pRowBuffer.Value(3) = lGLPKResultsObject(n).Budget
            pRowBuffer.Value(4) = Convert.ToInt16(lGLPKResultsObject(n).GLPK_Solved)
            pRowBuffer.Value(5) = lGLPKResultsObject(n).Perc_Gap
            pRowBuffer.Value(6) = lGLPKResultsObject(n).MaxSolTime
            pRowBuffer.Value(7) = lGLPKResultsObject(n).TimeUsed
            pRowBuffer.Value(8) = lGLPKResultsObject(n).Habitat_ZMax

            pCursor = pTable.Insert(True)
            pCursor.InsertRow(pRowBuffer)
        Next


        ' ---------------
        ' Table 2
        ' get table name
        Dim sGLPKResultsDecisionsTableName As String
        sGLPKResultsDecisionsTableName = TableName("GLPKResultsDecisions", pFWorkspace, sPrefix)
        ' create table
        PrepGLPKResultsDecisionsOutTable(sGLPKResultsDecisionsTableName, pFWorkspace)
        ' populate table
        '  SinkEID(Of Integer)()
        '  Treatment (string)
        '  Budget (double)
        '  BarrierEID (Integer)
        '  OptionNum (Integer)

        n = 0
        pTable = pFWorkspace.OpenTable(sGLPKResultsDecisionsTableName)
        For n = 0 To lGLPKDecisionsObject.Count - 1
            '  SinkEID(Of Integer)
            '  Treatment (string)
            '  Budget (double)
            '  BarrierEID (Integer)
            '  OptionNum (Integer)
            pRowBuffer = pTable.CreateRowBuffer
            pRowBuffer.Value(1) = iSinkEID
            pRowBuffer.Value(2) = lGLPKDecisionsObject(n).Treatment
            pRowBuffer.Value(3) = lGLPKDecisionsObject(n).Budget
            pRowBuffer.Value(4) = lGLPKDecisionsObject(n).BarrierEID
            pRowBuffer.Value(5) = lGLPKDecisionsObject(n).DecisionOption

            pCursor = pTable.Insert(True)
            pCursor.InsertRow(pRowBuffer)
        Next


        ' ===== PRINT RESULTS OBJECTS TO GDB TABLES =====

        ' ==== AFTER ANALYSIS SEARCH AND REPLACE PATH TXT IN MODEL FILE ===
        '  search and replace 
        ' replac epath to Model DIR (sGLPKModelDir)  
        ' with c:\GunnsModel\
        If System.IO.File.Exists(sGLPKModelDir + "/May25_EldonsModel_FiPEx.mod") = True Then
            sModelFile = System.IO.File.ReadAllLines(sGLPKModelDir + "/May25_EldonsModel_FiPEx.mod")
        End If

        n = 0
        For n = 0 To sModelFile.GetUpperBound(0)
            If sModelFile(n).Contains(sGLPKModelDir) = True Then
                sModelFile(n) = sModelFile(n).Replace(sGLPKModelDir, "C:\GunnsModel_REPLACE")
            End If
        Next

        ' overwrite file
        System.IO.File.WriteAllLines(sGLPKModelDir + "/May25_EldonsModel_FiPEx.mod", sModelFile)

    End Sub

    Private Sub DCIShellCall(ByVal sDCITableName As String, ByVal sConnectTabName As String, ByRef pFWorkspace As IFeatureWorkspace)
        ' ====================================================================
        ' SubRoutine:    DCI R Shell Call
        ' Author:        Greig Oldford
        ' Created For:   DFO Maritimes
        '
        ' Description:   This command will open the tables created in the earlier
        '                Analysis command process and resaves them as .CSV's (comma 
        '                separated value files).
        '                It only converts tables that contain habitat quantities derived
        '                from lines layers that participate in the geometric network. 
        '                If there is more than one lines layer and consequently more than 
        '                one table it WILL MERGE THESE TABLES INTO ONE.  This means the quantity 
        '                units are assumed the same. 
        '                It then calls on R from the DOS command line and calls the
        '                conversion file created to convert column headings and table 
        '                format to match the requirements of the DCI model.  Then it will run
        '                a batch command that calculates DCI and prints to a TXT file.  


        Dim sDCIModelDir As String = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sDCIModelDir"))    ' DCI model install directory
        Dim sRInstallDir As String = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sRInstallDir"))     ' R Program install directory
        Dim bDCISectional As Boolean = Convert.ToBoolean(m_FiPEx__1.pPropset.GetProperty("dcisectionalyn")) ' DCI sectional on/off?

        Dim pTable As ITable
        'Dim pCursor As ICursor
        Dim i As Integer
        Dim pTxtFactory As IWorkspaceFactory = New TextFileWorkspaceFactory

        Dim pFWorkspaceOut As IFeatureWorkspace
        Dim pWorkspaceOut As IWorkspace

        ' Get output workspace
        pWorkspaceOut = pTxtFactory.OpenFromFile(sDCIModelDir, My.ArcMap.Application.hWnd)
        pFWorkspaceOut = CType(pWorkspaceOut, IFeatureWorkspace)

        ' Check that user has write permissions in output workspace
        'Dim pc As New CheckPerm
        'pc.Permission = "Modify"
        'If Not pc.CheckPerm(sDCIModelDir) Then
        '    MsgBox("You do not have the necessary permission to create, delete, or modify files in the DCI Model installation directory." + _
        '    " Please change directory, attain necessary permissions, or uncheck DCI Output checkbox in 'Advanced Tab' of Options Menu.")
        '    Exit Sub
        'End If

        ' Check that the user currently has file permissions to write to 
        ' this directory
        Dim bPermissionCheck
        bPermissionCheck = FileWriteDeleteCheck(sDCIModelDir)
        If bPermissionCheck = False Then
            MsgBox("File / folder permission check: " & Str(bPermissionCheck))
            MsgBox("It appears you do not have write permission to the DCI Model Directory.  Write permission to this directory is needed in order to run DCI Analysis.")
            Exit Sub
        End If

        Dim pExportOp As IExportOperation = New ExportOperation
        Dim pDataSetIn As IDataset
        Dim pDataSetOut As IDataset
        Dim pDSNameIn As IDatasetName
        Dim pDSNameOut As IDatasetName
        Dim FileToDelete As String

        ' Get the output dataset name ready.
        pDataSetOut = CType(pWorkspaceOut, IDataset)

        ' Take DBF habitat tables in geodatabase workspace
        ' and print it to the new text/csv file
        ' If there is more than one then merge it 
        ' into one table.  


        ' If it is the first table then delete other tables 
        ' and create the output table. 
        If i = 0 Then

            ' Delete the table if it already exists
            FileToDelete = sDCIModelDir + "/FIPEX_BarrierHabitatLine.csv"
            If System.IO.File.Exists(FileToDelete) = True Then
                System.IO.File.Delete(FileToDelete)

                ' need to reset the workspace so the file list will refresh and
                ' arcgis will know the file doesn't exist now.
                pWorkspaceOut = pTxtFactory.OpenFromFile(sDCIModelDir, 0)
                pFWorkspaceOut = CType(pWorkspaceOut, IFeatureWorkspace)
                pDataSetOut = CType(pWorkspaceOut, IDataset)
            End If

            pExportOp = New ExportOperation

            ' Get input table
            pTable = pFWorkspace.OpenTable(sDCITableName)

            ' Get the dataset name for the input table
            pDataSetIn = CType(pTable, IDataset)
            pDSNameIn = CType(pDataSetIn.FullName, IDatasetName)

            ' Get dataset for output table
            pDSNameOut = New TableName
            pDSNameOut.Name = "FIPEX_BarrierHabitatLine.csv"
            pDSNameOut.WorkspaceName = CType(pDataSetOut.FullName, IWorkspaceName)

            Try
                pExportOp.ExportTable(pDSNameIn, Nothing, Nothing, pDSNameOut, My.ArcMap.Application.hWnd)
            Catch ex As Exception
                MsgBox("Error trying to export DBF table to DCI Directory. " & ex.Message)
            End Try

            'Else ' if this is the second loop just ADD data from the input table to output table

        End If

        ' Convert the connectivity table
        pExportOp = New ExportOperation

        ' Input table
        pTable = pFWorkspace.OpenTable(sConnectTabName)

        ' Get the dataset name for the input table
        pDataSetIn = CType(pTable, IDataset)
        pDSNameIn = CType(pDataSetIn.FullName, IDatasetName)

        ' Delete the table if it already exists
        FileToDelete = sDCIModelDir + "/FIPEX_connectivity.csv"
        If System.IO.File.Exists(FileToDelete) = True Then
            System.IO.File.Delete(FileToDelete)
        End If

        ' Get dataset for output table and export
        pDSNameOut = New TableName
        pDSNameOut.Name = "FIPEX_connectivity.csv"
        pDSNameOut.WorkspaceName = CType(pDataSetOut.FullName, IWorkspaceName)

        Try
            pExportOp.ExportTable(pDSNameIn, Nothing, Nothing, pDSNameOut, My.ArcMap.Application.hWnd)
        Catch ex As Exception
            MsgBox("Error exporting connectivity table to DCI Directory. " & ex.Message)
        End Try

        ' navigate to the model directory and run the R program.  Pause until completed.
        ChDir(sDCIModelDir)
        If bDCISectional = True Then
            Shell(sRInstallDir + "/bin/r" + " CMD BATCH FIPEX.run.DCI.Sectional.r", AppWinStyle.NormalFocus, True)
        Else
            Shell(sRInstallDir + "/bin/r" + " CMD BATCH FIPEX.run.DCI.r", AppWinStyle.NormalFocus, True)
        End If



    End Sub
    Private Sub UpdateResultsDCI(ByRef iBarrierCount As Integer, ByRef dDCIp As Double, ByRef dDCId As Double, ByRef bNaturalY As Boolean)

        ' ====================================================================
        ' SubRoutine:    Update Results Form With DCI
        ' Author:        Greig Oldford
        ' Created For:   DFO Maritimes
        '
        ' Description:   This command will read the output file in the DCI Model
        '                directory, created during the DCIShellCall sub, and 
        '                update the ResultsForm with it
        ' ====================================================================

        ' Read the DCI Model Directory from the document properties
        Dim sDCIModelDir As String = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("sDCIModelDir"))
        'Dim bDCISectional As Boolean = Convert.ToBoolean(m_FiPEX__1.pPropset.GetProperty("dcisectionalyn"))

        ' Read the file and return two values - line one and line two from output
        Dim ErrInfo As String

        Dim objReader As StreamReader
        Dim sLine As String
        Dim iPosit As Integer

        ''Select the DCI Output title and set it to bold.  
        'iPosit = pResultsForm.txtRichResults.Find("DCI OUTPUT")
        'pResultsForm.txtRichResults.Select(iPosit, 10)
        'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Bold)

        Dim iLoopCount As Integer = 0

        Try
            If iBarrierCount > 1 Then ' TEMP 'if' here in case no barriers - otherwise model fails (always one barrier - the flag)
                objReader = New StreamReader(sDCIModelDir + "/out.txt")
                Do Until objReader.EndOfStream = True
                    iLoopCount = iLoopCount + 1
                    sLine = objReader.ReadLine()
                    ' If the first line says ERROR then write this, otherwise write nothing
                    ' because the first line of a successful DCI will say "Value" - skip.  
                    ' Using FINDME to get to the position at top of results box.  
                    If iLoopCount = 1 Then

                        If sLine = "ERROR" Then
                            'pResultsForm.txtRichResults.SelectedText = "    DCI Stats" + Environment.NewLine + "    FINDME"
                            'iPosit = pResultsForm.txtRichResults.Find("FINDME")
                            'pResultsForm.txtRichResults.Select(iPosit, 6)
                            'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Italic)
                            'pResultsForm.txtRichResults.SelectedText = sLine + Environment.NewLine + "    R DCI model encountered a problem with FIPEX tables" + _
                            'Environment.NewLine + "    FINDME"

                            dDCIp = 9999
                            dDCId = 9999

                            Exit Do
                        End If
                    ElseIf iLoopCount = 2 Then

                        '' Take selected bold DCI OUTPUT, change it to two lines including a findme string
                        'pResultsForm.txtRichResults.SelectedText = "    DCI Stats" + Environment.NewLine + "    FINDME"
                        'iPosit = pResultsForm.txtRichResults.Find("FINDME")
                        'pResultsForm.txtRichResults.Select(iPosit, 6)
                        'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Italic)
                        'pResultsForm.txtRichResults.SelectedText = sLine + Environment.NewLine + "    FINDME"

                        If bNaturalY = True Then
                            sLine = sLine.Remove(0, 15)
                        Else
                            sLine = sLine.Remove(0, 6)
                        End If
                        dDCIp = Convert.ToDouble(sLine)

                    ElseIf iLoopCount = 3 Then
                        'iPosit = pResultsForm.txtRichResults.Find("FINDME")
                        'pResultsForm.txtRichResults.Select(iPosit, 6)
                        'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Italic)
                        'pResultsForm.txtRichResults.SelectedText = sLine + Environment.NewLine + "    FINDME"
                        If bNaturalY = True Then
                            sLine = sLine.Remove(0, 15)
                        Else
                            sLine = sLine.Remove(0, 6)
                        End If
                        dDCId = Convert.ToDouble(sLine)

                    End If
                Loop

                objReader.Close()

                '' Clean up - get rid of final FINDME
                'iPosit = pResultsForm.txtRichResults.Find("FINDME")
                'pResultsForm.txtRichResults.Select(iPosit, 6)
                'pResultsForm.txtRichResults.SelectedText = "    "

            Else ' if there are no barriers encountered

                'pResultsForm.txtRichResults.SelectedText = "    DCI Stats" + Environment.NewLine + "    FINDME"
                'iPosit = pResultsForm.txtRichResults.Find("FINDME")
                'pResultsForm.txtRichResults.Select(iPosit, 6)
                'pResultsForm.txtRichResults.SelectionFont = New Font("Tahoma", 10, FontStyle.Italic)
                'pResultsForm.txtRichResults.SelectedText = "    DCIp = 100" + Environment.NewLine + "       DCId = 100"

                dDCId = 100
                dDCIp = 100

            End If

        Catch Ex As Exception
            ErrInfo = Ex.Message
            MsgBox("Error reading DCI output file. " + ErrInfo)

        End Try

    End Sub
    Private Function PrepConnectivityTables(ByVal pFWorkspace As IFeatureWorkspace, ByVal sConnectTabName As String) As String
        ' ==============================================
        ' Function: Prepare Connectivity Table(s)
        ' Author:   Greig(Oldford)
        ' Purpose: To prepare connectivity tables in 
        '          output workspace
        ' PROCESS LOGIC:
        ' 1.0 Set the table collection to the map document
        ' 1.1 If Connectivity tables are desired
        '   2.0 Check for table name conflicts and get name
        '   2.1 Create three fields
        '   2.2 Set first as objectID
        '   2.3 Set second as barrierID (string)
        '   2.4 Set third as downstream_barrierID (should be string)
        '
        '  Note on field types:  Since there can be multiple barriers layers
        '  there could be a variety of ID types that will get added to the one connectivity
        '  table.  Since anything can be inserted to a text field then both fields should
        '  be string. 

        Dim pStTab As IStandaloneTable
        Dim pStTabColl As IStandaloneTableCollection
        'Dim sConnectTabName As String

        Dim pFields As IFields
        Dim pFieldsEdit As IFieldsEdit
        Dim pField As IField
        Dim pFieldEdit As IFieldEdit

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap
        pStTabColl = CType(pMap, IStandaloneTableCollection)
        Dim pTable As ITable


        ' Create new Fields object
        pFields = New Fields
        pFieldsEdit = CType(pFields, IFieldsEdit)
        pFieldsEdit.FieldCount_2 = 3

        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "ObjectID"
        pFieldEdit.Name_2 = "ObID"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID

        ' Set first field
        pFieldsEdit.Field_2(0) = pField

        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "BarrierFlagID assigned"
        pFieldEdit.Name_2 = "BarrierOrFlagID"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 55

        pFieldsEdit.Field_2(1) = pField

        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        ' THIS COLUMN IS SET AS AN INTEGER
        ' MAY CAUSE PROBLEMS IN THE FUTURE IF BARRIER
        ' IDs ARE STRINGS!!
        pFieldEdit.AliasName_2 = "Downstream Barrier/Sink"
        pFieldEdit.Name_2 = "Downstream_Barrier"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 55

        pFieldsEdit.Field_2(2) = pField

        ' May be possible to add optional params for RDBMS behaviour
        If pFWorkspace IsNot Nothing Then
            Try
                pFWorkspace.CreateTable(sConnectTabName, pFields, Nothing, Nothing, "")
            Catch ex As Exception
                MsgBox("Problem creating connectivity table. " & ex.Message)
            End Try

            ' Add Table to Map Doc
            pTable = pFWorkspace.OpenTable(sConnectTabName)
            pStTab = New StandaloneTable
            pStTab.Table = pTable
            pStTabColl.AddStandaloneTable(pStTab)
            pMxDoc.UpdateContents()
        Else
            System.Windows.Forms.MessageBox.Show("Output workspace for DBF table must be within a Personal or File GeoDatabase", "Output workspace conflict")
        End If

        PrepConnectivityTables = sConnectTabName
    End Function
    Private Function PrepGLPKConnectivityTable(ByVal pFWorkspace As IFeatureWorkspace, ByVal sConnectTabName As String) As String
        ' ==============================================
        ' Function: Prepare GLPK Connectivity Table(s)
        ' Author:   Greig(Oldford)
        ' Purpose: To prepare GLPK connectivity tables in 
        '          output workspace
        ' PROCESS LOGIC:
        ' 1.0 Set the table collection to the map document
        ' 1.1 If Connectivity tables are desired
        '   2.0 Check for table name conflicts and get name
        '   2.1 Create three fields
        '   2.2 Set one as downstream_barrierID (should be string)
        '   2.3 Set second as barrierID (string)
        '   2.4 Set third as DUMMY
        '

        Dim pStTab As IStandaloneTable
        Dim pStTabColl As IStandaloneTableCollection
        'Dim sConnectTabName As String

        Dim pFields As IFields
        Dim pFieldsEdit As IFieldsEdit
        Dim pField As IField
        Dim pFieldEdit As IFieldEdit

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap
        pStTabColl = CType(pMap, IStandaloneTableCollection)
        Dim pTable As ITable


        ' Create new Fields object
        pFields = New Fields
        pFieldsEdit = CType(pFields, IFieldsEdit)
        pFieldsEdit.FieldCount_2 = 3

        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "BEID"
        pFieldEdit.Name_2 = "BEID"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger

        ' Set first field
        pFieldsEdit.Field_2(0) = pField

        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "UpEID"
        pFieldEdit.Name_2 = "UpEID"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger

        pFieldsEdit.Field_2(1) = pField

        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        ' THIS COLUMN IS SET AS AN INTEGER
        ' MAY CAUSE PROBLEMS IN THE FUTURE IF BARRIER
        ' IDs ARE STRINGS!!
        pFieldEdit.AliasName_2 = "DUMMY"
        pFieldEdit.Name_2 = "DUMMY"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger

        pFieldsEdit.Field_2(2) = pField

        ' May be possible to add optional params for RDBMS behaviour
        If pFWorkspace IsNot Nothing Then
            Try
                pFWorkspace.CreateTable(sConnectTabName, pFields, Nothing, Nothing, "")
            Catch ex As Exception
                MsgBox("Problem creating connectivity table. " & ex.Message)
            End Try

            ' Add Table to Map Doc
            pTable = pFWorkspace.OpenTable(sConnectTabName)
            pStTab = New StandaloneTable
            pStTab.Table = pTable
            pStTabColl.AddStandaloneTable(pStTab)
            pMxDoc.UpdateContents()
        Else
            System.Windows.Forms.MessageBox.Show("Output workspace for DBF table must be within a Personal or File GeoDatabase", "Output workspace conflict")
        End If

        PrepGLPKConnectivityTable = sConnectTabName
    End Function


    Private Sub PrepGLPKHabTable(ByVal sTable As String, ByVal pFWSpace As IFeatureWorkspace)

        ' ==============================================
        ' Purpose: To prepare dbf tables in output workspace for use with DCI Model
        '
        ' PROCESS LOGIC:
        ' 1.0 Set the table collection to the map document
        ' 2.0 Create a fields collection with name and type of each field
        ' 3.0 Create the tables in the output workspace. 
        '
        ' Table fields:
        '   BarrierID (integer)
        '   Quantity (double)

        Dim pStTab As IStandaloneTable
        Dim pStTabColl As IStandaloneTableCollection
        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap

        Dim pFields As IFields
        Dim pFieldsEdit As IFieldsEdit
        Dim pField As IField
        Dim pFieldEdit As IFieldEdit

        ' Create new Fields object
        pFields = New Fields
        pFieldsEdit = CType(pFields, IFieldsEdit)

        Dim iFields As Integer ' to keep track of number of fields

        pFieldsEdit.FieldCount_2 = 2
        iFields = 2

        '' ============ First Field ============
        '' Create ObjectID Field
        'pField = New Field
        'pFieldEdit = CType(pField, IFieldEdit)

        'pFieldEdit.AliasName_2 = "ObjectID" 'VB.NET
        'pFieldEdit.Name_2 = "ObID"
        'pFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID
        ''pFieldEdit.AliasName = "ObjectID"
        ''pFieldEdit.Name = "ObID"
        ''pFieldEdit.Type = esriFieldType.esriFieldTypeOID

        'pFieldsEdit.Field_2(0) = pField 'VB.NET
        ''pFieldsEdit.Field(0) = pField

        ' ============= First Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "BARRIER"
        pFieldEdit.Name_2 = "BARRIER"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldsEdit.Field_2(0) = pField

        ' ============ Third Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Habitat Quantity Field"
        pFieldEdit.Name_2 = "HABITAT"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        'pFieldEdit.Scale_2 = 1
        pFieldsEdit.Field_2(1) = pField

        '' =========== Fourth Field ===========
        'pField = New Field
        'pFieldEdit = CType(pField, IFieldEdit)

        'pFieldEdit.AliasName_2 = "Barrier Permeability Field"
        'pFieldEdit.Name_2 = "BarrierPerm"

        'pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        'pFieldsEdit.Field_2(3) = pField

        '' =========== Fifth Field ===========
        'pField = New Field
        'pFieldEdit = CType(pField, IFieldEdit)

        'pFieldEdit.AliasName_2 = "Barrier Natural TF Field"
        'pFieldEdit.Name_2 = "NaturalYN"

        'pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        'pFieldEdit.Length_2 = 55

        'pFieldsEdit.Field_2(4) = pField

        ' MsgBox "Going to create table in workspace named - & sTableName
        ' May be possible to add optional params for RDBMS behaviour
        pFWSpace.CreateTable(sTable, pFields, Nothing, Nothing, "")
        ' MsgBox "created table successfully"

        ' Add Table to Map Doc
        Dim pTable As ITable = pFWSpace.OpenTable(sTable)
        pStTabColl = CType(pMap, IStandaloneTableCollection)
        pStTab = New StandaloneTable
        pStTab.Table = pTable
        pStTabColl.AddStandaloneTable(pStTab)
        pMxDoc.UpdateContents()

    End Sub
    Private Sub PrepGLPKOptionsTable(ByVal sTable As String, ByVal pFWSpace As IFeatureWorkspace)

        ' ==============================================
        ' Purpose: To prepare dbf tables in output workspace for use with DCI Model
        '
        ' PROCESS LOGIC:
        ' 1.0 Set the table collection to the map document
        ' 2.0 Create a fields collection with name and type of each field
        ' 3.0 Create the tables in the output workspace. 
        '
        ' Table fields:
        '   BARRIER (Integer)
        '   OPTION (double)
        '   PERM (double)
        '   COST (double)

        Dim pStTab As IStandaloneTable
        Dim pStTabColl As IStandaloneTableCollection
        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap

        Dim pFields As IFields
        Dim pFieldsEdit As IFieldsEdit
        Dim pField As IField
        Dim pFieldEdit As IFieldEdit

        ' Create new Fields object
        pFields = New Fields
        pFieldsEdit = CType(pFields, IFieldsEdit)

        Dim iFields As Integer ' to keep track of number of fields

        pFieldsEdit.FieldCount_2 = 4
        iFields = 4

        '' ============ First Field ============
        '' Create ObjectID Field
        'pField = New Field
        'pFieldEdit = CType(pField, IFieldEdit)

        'pFieldEdit.AliasName_2 = "ObjectID" 'VB.NET
        'pFieldEdit.Name_2 = "ObID"
        'pFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID
        ''pFieldEdit.AliasName = "ObjectID"
        ''pFieldEdit.Name = "ObID"
        ''pFieldEdit.Type = esriFieldType.esriFieldTypeOID

        'pFieldsEdit.Field_2(0) = pField 'VB.NET
        ''pFieldsEdit.Field(0) = pField

        ' ============= First Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "BARRIER"
        pFieldEdit.Name_2 = "BARRIER"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldsEdit.Field_2(0) = pField

        ' ============ Second Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "OPTION1"
        pFieldEdit.Name_2 = "OPTION1"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldsEdit.Field_2(1) = pField

        ' ============ Third Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "PERM"
        pFieldEdit.Name_2 = "PERM"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldEdit.Scale_2 = 2
        pFieldsEdit.Field_2(2) = pField

        ' ============ Fourth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "COST"
        pFieldEdit.Name_2 = "COST"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldsEdit.Field_2(3) = pField

        ' MsgBox "Going to create table in workspace named - & sTableName
        ' May be possible to add optional params for RDBMS behaviour
        pFWSpace.CreateTable(sTable, pFields, Nothing, Nothing, "")
        ' MsgBox "created table successfully"

        ' Add Table to Map Doc
        Dim pTable As ITable = pFWSpace.OpenTable(sTable)
        pStTabColl = CType(pMap, IStandaloneTableCollection)
        pStTab = New StandaloneTable
        pStTab.Table = pTable
        pStTabColl.AddStandaloneTable(pStTab)
        pMxDoc.UpdateContents()

    End Sub
    Private Sub PrepGLPKResultsOutTable(ByVal sTable As String, ByVal pFWSpace As IFeatureWorkspace)

        ' ==============================================
        ' Purpose: To prepare dbf tables in output workspace for use with DCI Model
        '
        ' PROCESS LOGIC:
        ' 1.0 Set the table collection to the map document
        ' 2.0 Create a fields collection with name and type of each field
        ' 3.0 Create the tables in the output workspace. 
        '
        ' Table fields:
        '  SinkEID (integer)
        '  Treatment (string)
        '  Budget (double)
        '  GLPKSolved (boolean/binary)
        '  Perc_Gap (double)
        '  MAxSolTime(integer)
        '  TimeUsed(double)
        '  HabitatZmax(double)


        Dim pStTab As IStandaloneTable
        Dim pStTabColl As IStandaloneTableCollection
        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap

        Dim pFields As IFields
        Dim pFieldsEdit As IFieldsEdit
        Dim pField As IField
        Dim pFieldEdit As IFieldEdit

        ' Create new Fields object
        pFields = New Fields
        pFieldsEdit = CType(pFields, IFieldsEdit)

        Dim iFields As Integer ' to keep track of number of fields

        pFieldsEdit.FieldCount_2 = 9
        iFields = 9

        ' ============ First Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "ObjectID" 'VB.NET
        pFieldEdit.Name_2 = "ObID"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID
        'pFieldEdit.AliasName = "ObjectID"
        'pFieldEdit.Name = "ObID"
        'pFieldEdit.Type = esriFieldType.esriFieldTypeOID

        pFieldsEdit.Field_2(0) = pField 'VB.NET
        'pFieldsEdit.Field(0) = pField

        ' ============= First Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "SinkEID"
        pFieldEdit.Name_2 = "SinkEID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldsEdit.Field_2(1) = pField

        ' ============ Second Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Treatment"
        pFieldEdit.Name_2 = "Treatment"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldsEdit.Field_2(2) = pField

        ' ============ Third Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Budget"
        pFieldEdit.Name_2 = "Budget"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldEdit.Scale_2 = 2
        pFieldsEdit.Field_2(3) = pField

        ' ============ Fourth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "GLPKSolved"
        pFieldEdit.Name_2 = "GLPKSolved"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeSmallInteger
        pFieldsEdit.Field_2(4) = pField

        ' ============ Fifth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "PercGap"
        pFieldEdit.Name_2 = "PercGap"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldsEdit.Field_2(5) = pField

        ' ============ Sixth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "MaxSolTime"
        pFieldEdit.Name_2 = "MaxSolTime"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldsEdit.Field_2(6) = pField

        ' ============ Seventh Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "TimeUsed"
        pFieldEdit.Name_2 = "TimeUsed"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldsEdit.Field_2(7) = pField

        ' ============ Eighth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "HabitatZMax"
        pFieldEdit.Name_2 = "HabitatZMax"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldsEdit.Field_2(8) = pField

        ' MsgBox "Going to create table in workspace named - & sTableName
        ' May be possible to add optional params for RDBMS behaviour
        pFWSpace.CreateTable(sTable, pFields, Nothing, Nothing, "")
        ' MsgBox "created table successfully"

        ' Add Table to Map Doc
        Dim pTable As ITable = pFWSpace.OpenTable(sTable)
        pStTabColl = CType(pMap, IStandaloneTableCollection)
        pStTab = New StandaloneTable
        pStTab.Table = pTable
        pStTabColl.AddStandaloneTable(pStTab)
        pMxDoc.UpdateContents()

    End Sub
    Private Sub PrepGLPKResultsDecisionsOutTable(ByVal sTable As String, ByVal pFWSpace As IFeatureWorkspace)

        ' ==============================================
        ' Purpose: To prepare dbf tables in output workspace for use with DCI Model
        '
        ' PROCESS LOGIC:
        ' 1.0 Set the table collection to the map document
        ' 2.0 Create a fields collection with name and type of each field
        ' 3.0 Create the tables in the output workspace. 
        '
        ' Table fields:
        '  SinkEID (integer)
        '  Treatment (string)
        '  Budget (double)
        '  BarrierEID (Integer)
        '  OptionNum (Integer)


        Dim pStTab As IStandaloneTable
        Dim pStTabColl As IStandaloneTableCollection
        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap

        Dim pFields As IFields
        Dim pFieldsEdit As IFieldsEdit
        Dim pField As IField
        Dim pFieldEdit As IFieldEdit

        ' Create new Fields object
        pFields = New Fields
        pFieldsEdit = CType(pFields, IFieldsEdit)

        Dim iFields As Integer ' to keep track of number of fields

        pFieldsEdit.FieldCount_2 = 6
        iFields = 6

        ' ============ First Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "ObjectID" 'VB.NET
        pFieldEdit.Name_2 = "ObID"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID
        'pFieldEdit.AliasName = "ObjectID"
        'pFieldEdit.Name = "ObID"
        'pFieldEdit.Type = esriFieldType.esriFieldTypeOID

        pFieldsEdit.Field_2(0) = pField 'VB.NET
        'pFieldsEdit.Field(0) = pField

        ' ============= First Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "SinkEID"
        pFieldEdit.Name_2 = "SinkEID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldsEdit.Field_2(1) = pField

        ' ============ Second Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Treatment"
        pFieldEdit.Name_2 = "Treatment"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldsEdit.Field_2(2) = pField

        ' ============ Third Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Budget"
        pFieldEdit.Name_2 = "Budget"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldEdit.Scale_2 = 2
        pFieldsEdit.Field_2(3) = pField

        ' ============ Fourth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "BarrierEID"
        pFieldEdit.Name_2 = "BarrierEID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldsEdit.Field_2(4) = pField

        ' ============ Fifth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "OptionNum"
        pFieldEdit.Name_2 = "OptionNum"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldsEdit.Field_2(5) = pField

        ' MsgBox "Going to create table in workspace named - & sTableName
        ' May be possible to add optional params for RDBMS behaviour
        pFWSpace.CreateTable(sTable, pFields, Nothing, Nothing, "")
        ' MsgBox "created table successfully"

        ' Add Table to Map Doc
        Dim pTable As ITable = pFWSpace.OpenTable(sTable)
        pStTabColl = CType(pMap, IStandaloneTableCollection)
        pStTab = New StandaloneTable
        pStTab.Table = pTable
        pStTabColl.AddStandaloneTable(pStTab)
        pMxDoc.UpdateContents()

    End Sub

    Private Sub PrepDCIOutTable(ByVal sTable As String, ByVal pFWSpace As IFeatureWorkspace)

        ' ==============================================
        ' Purpose: To prepare dbf tables in output workspace for use with DCI Model
        '
        ' PROCESS LOGIC:
        ' 1.0 Set the table collection to the map document
        ' 2.0 Create a fields collection with name and type of each field
        ' 3.0 Create the tables in the output workspace. 
        '
        ' Table fields:
        '   ObjectID (autoinc)
        '   BarrierID (string 55)
        '   Quantity (double)
        '   BarrierPerm (double)
        '   BarrierYN (string 55)

        Dim pStTab As IStandaloneTable
        Dim pStTabColl As IStandaloneTableCollection
        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap

        Dim pFields As IFields
        Dim pFieldsEdit As IFieldsEdit
        Dim pField As IField
        Dim pFieldEdit As IFieldEdit

        ' Create new Fields object
        pFields = New Fields
        pFieldsEdit = CType(pFields, IFieldsEdit)

        Dim iFields As Integer ' to keep track of number of fields

        pFieldsEdit.FieldCount_2 = 5
        iFields = 5

        ' ============ First Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "ObjectID" 'VB.NET
        pFieldEdit.Name_2 = "ObID"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID
        'pFieldEdit.AliasName = "ObjectID"
        'pFieldEdit.Name = "ObID"
        'pFieldEdit.Type = esriFieldType.esriFieldTypeOID

        pFieldsEdit.Field_2(0) = pField 'VB.NET
        'pFieldsEdit.Field(0) = pField

        ' ============= Second Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "BarrierID"
        pFieldEdit.Name_2 = "BarrierID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 55
        pFieldsEdit.Field_2(1) = pField

        ' ============ Third Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Habitat Quantity Field"
        pFieldEdit.Name_2 = "Quantity"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldsEdit.Field_2(2) = pField

        ' =========== Fourth Field ===========
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Barrier Permeability Field"
        pFieldEdit.Name_2 = "BarrierPerm"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldsEdit.Field_2(3) = pField

        ' =========== Fifth Field ===========
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Barrier Natural TF Field"
        pFieldEdit.Name_2 = "NaturalYN"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 55

        pFieldsEdit.Field_2(4) = pField

        ' MsgBox "Going to create table in workspace named - & sTableName
        ' May be possible to add optional params for RDBMS behaviour
        pFWSpace.CreateTable(sTable, pFields, Nothing, Nothing, "")
        ' MsgBox "created table successfully"

        ' Add Table to Map Doc
        Dim pTable As ITable = pFWSpace.OpenTable(sTable)
        pStTabColl = CType(pMap, IStandaloneTableCollection)
        pStTab = New StandaloneTable
        pStTab.Table = pTable
        pStTabColl.AddStandaloneTable(pStTab)
        pMxDoc.UpdateContents()

    End Sub
    Private Sub PrepHabitatTable(ByVal sTable As String, ByVal pFWSpace As IFeatureWorkspace)

        ' ==============================================
        ' Purpose: To prepare dbf tables in output workspace
        '
        ' PROCESS LOGIC:
        ' 1.0 Set the table collection to the map document
        ' 2.0 Create a fields collection with name and type of each field
        ' 3.0 Create the tables in the output workspace. 
        '
        '
        ' Creates the following fields:
        '       ObjectID
        '       Sink      (string - 55)
        '       SinkEID   (integer - long)
        '       Barrier   (string - 55)
        '       BarrierEID(integer - long)
        '       Layer     (string - 255)
        '       Direction (string - 12)
        '       Trace Type(string - 20)
        '       Class     (string - 85)
        '       Quantity  (double)
        '       Measure   (string - 30)

        Dim pStTab As IStandaloneTable
        Dim pStTabColl As IStandaloneTableCollection
        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap

        Dim pFields As IFields
        Dim pFieldsEdit As IFieldsEdit
        Dim pField As IField
        Dim pFieldEdit As IFieldEdit

        ' Create new Fields object
        pFields = New Fields
        pFieldsEdit = CType(pFields, IFieldsEdit)

        Dim iFields As Integer ' to keep track of number of fields

        pFieldsEdit.FieldCount_2 = 13
        iFields = 13

        ' ============ First Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "ObjectID" 'VB.NET
        pFieldEdit.Name_2 = "ObID"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID
        'pFieldEdit.AliasName = "ObjectID"
        'pFieldEdit.Name = "ObID"
        'pFieldEdit.Type = esriFieldType.esriFieldTypeOID

        pFieldsEdit.Field_2(0) = pField 'VB.NET
        'pFieldsEdit.Field(0) = pField

        ' ============= Second Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Sink ID"
        pFieldEdit.Name_2 = "SinkID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 55
        pFieldsEdit.Field_2(1) = pField

        ' ============= Third Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Sink EID"
        pFieldEdit.Name_2 = "SinkEID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldEdit.Length_2 = 5
        pFieldsEdit.Field_2(2) = pField

        ' ============= Fourth Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "bID"
        pFieldEdit.Name_2 = "bID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 55
        pFieldsEdit.Field_2(3) = pField

        ' ============= Fifth Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "barr EID"
        pFieldEdit.Name_2 = "barrEID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldEdit.Length_2 = 5
        pFieldsEdit.Field_2(4) = pField

        ' ============ Sixth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Node Type"
        pFieldEdit.Name_2 = "nType"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 30
        pFieldsEdit.Field_2(5) = pField

        ' ============ Seventh Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Habitat Layer"
        pFieldEdit.Name_2 = "Layer"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 255
        pFieldsEdit.Field_2(6) = pField

        ' ============ Eigth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Direction"
        pFieldEdit.Name_2 = "Direction"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 12
        pFieldsEdit.Field_2(7) = pField

        ' ============ Ninth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Trace Type"
        pFieldEdit.Name_2 = "TraceType"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 20
        pFieldsEdit.Field_2(8) = pField

        ' ============ tenth Field ============
        ' THIS COLUMN IS SET AS A STRING IN CASE HAB CLASSES
        ' ARE DIVIDED INTO PRIM, SECOND, TERT etc.
        ' This may cause problems when populating from
        ' a numeric field.

        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)
        pFieldEdit.AliasName_2 = "Habitat Class"
        pFieldEdit.Name_2 = "HabClass"
        'End If
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 85
        pFieldsEdit.Field_2(9) = pField

        ' ============ Eleventh Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)
        pFieldEdit.AliasName_2 = "Habitat Class Field"
        pFieldEdit.Name_2 = "HabClassField"
        'End If
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 85
        pFieldsEdit.Field_2(10) = pField

        ' =========== Twelfth Field ===========
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Habitat Quantity Field"
        pFieldEdit.Name_2 = "Quantity"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldsEdit.Field_2(11) = pField

        ' =========== Thirteenth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "UnitMeasure"
        pFieldEdit.Name_2 = "Units"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 30
        pFieldsEdit.Field_2(12) = pField


        ' MsgBox "Going to create table in workspace named - & sTableName
        ' May be possible to add optional params for RDBMS behaviour
        pFWSpace.CreateTable(sTable, pFields, Nothing, Nothing, "")
        ' MsgBox "created table successfully"

        ' Add Table to Map Doc
        Dim pTable As ITable = pFWSpace.OpenTable(sTable)
        pStTabColl = CType(pMap, IStandaloneTableCollection)
        pStTab = New StandaloneTable
        pStTab.Table = pTable
        pStTabColl.AddStandaloneTable(pStTab)
        pMxDoc.UpdateContents()

    End Sub

    Private Sub PrepMetricTable(ByVal sTable As String, ByVal pFWSpace As IFeatureWorkspace)

        ' ==============================================
        ' Purpose: To prepare dbf tables in output workspace
        '
        ' PROCESS LOGIC:
        ' 1.0 Set the table collection to the map document
        ' 2.0 Create a fields collection with name and type of each field
        ' 3.0 Create the tables in the output workspace. 
        '
        '
        ' Creates the following fields:
        '       ObjectID
        '       SinkID    (string - 55)
        '       SinkEID   (integer - long)
        '       Barrier   (string - 55)
        '       BarrierEID (integer - long)
        '       MetricName (string - 55)
        '       Metric (double)

        Dim pStTab As IStandaloneTable
        Dim pStTabColl As IStandaloneTableCollection
        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap

        Dim pFields As IFields
        Dim pFieldsEdit As IFieldsEdit
        Dim pField As IField
        Dim pFieldEdit As IFieldEdit

        ' Create new Fields object
        pFields = New Fields
        pFieldsEdit = CType(pFields, IFieldsEdit)

        Dim iFields As Integer ' to keep track of number of fields

        pFieldsEdit.FieldCount_2 = 8
        iFields = 8

        ' ============ First Field ============
        ' Create ObjectID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "ObjectID" 'VB.NET
        pFieldEdit.Name_2 = "ObID"
        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeOID
        'pFieldEdit.AliasName = "ObjectID"
        'pFieldEdit.Name = "ObID"
        'pFieldEdit.Type = esriFieldType.esriFieldTypeOID

        pFieldsEdit.Field_2(0) = pField 'VB.NET
        'pFieldsEdit.Field(0) = pField

        ' ============= Second Field ============
        ' Create Barrier ID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Sink ID"
        pFieldEdit.Name_2 = "SinkID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 55
        pFieldsEdit.Field_2(1) = pField

        ' ============= Third Field ============
        ' Create Barrier ID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Sink EID"
        pFieldEdit.Name_2 = "SinkEID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldEdit.Length_2 = 5
        pFieldsEdit.Field_2(2) = pField

        ' ============= Fourth Field ============
        ' Create Barrier ID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "bID"
        pFieldEdit.Name_2 = "bID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 55
        pFieldsEdit.Field_2(3) = pField

        ' ============= Fifth Field ============
        ' Create Barrier ID Field
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "barr EID"
        pFieldEdit.Name_2 = "barrEID"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeInteger
        pFieldEdit.Length_2 = 5
        pFieldsEdit.Field_2(4) = pField

        ' ============ Sixth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Node Type"
        pFieldEdit.Name_2 = "NodeType"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 30
        pFieldsEdit.Field_2(5) = pField

        ' ============ Seventh Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Metric Name"
        pFieldEdit.Name_2 = "MetricName"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeString
        pFieldEdit.Length_2 = 55
        pFieldsEdit.Field_2(6) = pField

        ' ============ Eigth Field ============
        pField = New Field
        pFieldEdit = CType(pField, IFieldEdit)

        pFieldEdit.AliasName_2 = "Metric"
        pFieldEdit.Name_2 = "Metric"

        pFieldEdit.Type_2 = esriFieldType.esriFieldTypeDouble
        pFieldsEdit.Field_2(7) = pField

        ' MsgBox "Going to create table in workspace named - & sTableName
        ' May be possible to add optional params for RDBMS behaviour
        pFWSpace.CreateTable(sTable, pFields, Nothing, Nothing, "")
        ' MsgBox "created table successfully"

        ' Add Table to Map Doc
        Dim pTable As ITable = pFWSpace.OpenTable(sTable)
        pStTabColl = CType(pMap, IStandaloneTableCollection)
        pStTab = New StandaloneTable
        pStTab.Table = pTable
        pStTabColl.AddStandaloneTable(pStTab)
        pMxDoc.UpdateContents()

    End Sub

    Private Sub ExcludeFeatures(ByVal pFeatureLayer As IFeatureLayer)


        ' Function:    ExcludeFeatures
        ' Created By:  Greig Oldford
        ' Date:        June 11, 2009
        ' Purpose:     To remove from selection any features which are to be
        '              excluded.
        ' Description: This function is called after the intersecting any polygons
        '              included for habitat statistics with returned trace features.
        '              It is meant to remove any selected features that are on the
        '              'excludes' list. It is also meant to remove selected features
        '              of feature classes that are not on the 'includes' list.
        ' Notes:
        '      June 30, 2009  --> This has been modified to read exclusions from extension
        '                         rather than retrieving from global variable. 
        '       Feb 29, 2008  --> The exludes list does not need to be divided into polygons
        '               and lines at all. However, it helps when removing excludes.
        '                  This function should also remove even initially returned
        '               line features since the user may opt only to output habitat
        '               statistics for polygons.


        ' =================== READ EXCLUSIONS FROM EXTENSION =================

        Dim iExclusions, j As Integer
        Dim plExclusions As List(Of LayerToExclude) = New List(Of LayerToExclude)
        If m_FiPEx__1.m_bLoaded = True Then ' If there were any extension settings set

            iExclusions = Convert.ToInt32(m_FiPEx__1.pPropset.GetProperty("numExclusions"))
            Dim ExclusionsObj As New LayerToExclude(Nothing, Nothing, Nothing)

            ' match any of the line layers saved in stream to those in listboxes
            If iExclusions > 0 Then
                For j = 0 To iExclusions - 1
                    'sLineLayer = m_FiPEX__1.pPropset.GetProperty("IncLine" + j.ToString) ' get line layer
                    ExclusionsObj = New LayerToExclude(Nothing, Nothing, Nothing)
                    With ExclusionsObj
                        '.Layer = sLineLayer
                        .Layer = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("ExcldLayer" + j.ToString))
                        .Feature = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("ExcldFeature" + j.ToString))
                        .Value = Convert.ToString(m_FiPEx__1.pPropset.GetProperty("ExcldValue" + j.ToString))
                    End With

                    ' add to the module level list
                    plExclusions.Add(ExclusionsObj)
                Next
            End If
        Else
            Exit Sub
        End If

        ' ==================== EXCLUDE FEATURES =======================
        ' PROCESS LOGIC: 
        ' 1.0 If there are selected features in the layer
        '   2.0 If there are exclusions
        '     3.0 For each exclusion 
        '       4.0 If exclusion layer matches the current layer
        '       4.1 Get a cursor to loop through selection set
        '         5.0 If the layer name matches current exclusion layer name
        '           6.0 If the exclusion field is found in the layer
        '             7.0 For each feature in the layer
        '             7.1 Get the value from the exclusion list
        '               8.0 If the value from feature matches exclusion value
        '               8.1 Add the object id of feature to a list of items to exclude
        '             7.2 If there are feature values that match found then
        '               9.0 For each value
        '               9.1 Remove that feature from the selection

        Dim pFeatureSelection As IFeatureSelection
        Dim pFeatureCursor As IFeatureCursor
        Dim pFeature As IFeature
        Dim iFieldVal As Integer
        Dim x As Integer
        Dim aOID As New List(Of Integer)
        Dim iCount As Integer
        Dim pMxDoc As IMxDocument
        Dim pMap As IMap
        Dim pAV As IActiveView
        Dim vVal As Object
        Dim sTempVal As String

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        pMxDoc = CType(pDoc, IMxDocument)
        pMap = pMxDoc.FocusMap
        pAV = pMxDoc.ActiveView
        pFeatureSelection = CType(pFeatureLayer, IFeatureSelection)

        If (pFeatureSelection.SelectionSet.Count <> 0) Then
            If iExclusions > 0 Then
                x = 0
                For x = 0 To iExclusions - 1
                    Dim pCursor As ICursor
                    pFeatureSelection.SelectionSet.Search(Nothing, True, pCursor)
                    pFeatureCursor = CType(pCursor, IFeatureCursor)

                    ' FOR DEBUG - see how many feautres are selected in the layer
                    Dim iCountTEMP As Integer
                    iCountTEMP = pFeatureSelection.SelectionSet.Count

                    If pFeatureLayer.Name = plExclusions(x).Layer Then
                        ' Find the field
                        iFieldVal = pFeatureCursor.FindField(plExclusions(x).Feature)

                        If iFieldVal <> -1 Then
                            ' reset the excluded features count
                            iCount = 0
                            pFeature = pFeatureCursor.NextFeature
                            Do While Not pFeature Is Nothing
                                Try
                                    vVal = pFeature.Value(iFieldVal)
                                Catch ex As Exception
                                    MsgBox("Could not convert value found in Exclusions Sub to type 'variant/object'. " + _
                                           ". Found in Layer " + pFeatureLayer.Name.ToString + ex.Message)
                                    vVal = "nothing"
                                End Try
                                Try
                                    sTempVal = vVal.ToString
                                Catch ex As Exception
                                    MsgBox("Could not convert value found in Exclusions Sub to type 'string'. " + _
                                           ". Found in Layer " + pFeatureLayer.Name.ToString + ex.Message)
                                    sTempVal = "nothing"
                                End Try

                                'MsgBox(" m_aExcldVls(x): " + CStr(m_aExcldVls(x)))
                                'MsgBox("Is vVal Null? " + CStr(IsNull(vVal)))
                                'MsgBox("What kind of layer is feature from? " + CStr(pFeatureLayer.FeatureClass.ShapeType))
                                '

                                ' If the value matches then add the OID to an array
                                ' to subtract from the selection set.
                                If sTempVal IsNot Nothing Then
                                    If sTempVal = plExclusions(x).Value Then
                                        aOID.Add(pFeature.OID)
                                    End If
                                End If

                                pFeature = pFeatureCursor.NextFeature
                            Loop

                            iCount = aOID.Count
                            Dim iOID As Integer
                            If iCount <> 0 Then
                                For i As Integer = 0 To iCount - 1
                                    ' Remove excluded features from selection set by OID
                                    ' NOTE: remove list does not actually remove a list
                                    ' so we need a loop here; see http://forums.esri.com/Thread.asp?c=159&f=1707&t=224394
                                    iOID = aOID.Item(i)
                                    pFeatureSelection.SelectionSet.RemoveList(1, iOID)
                                    pFeatureSelection.SelectionChanged()
                                Next
                                pAV.PartialRefresh(ESRI.ArcGIS.Carto.esriViewDrawPhase.esriViewGeoSelection, Nothing, Nothing)
                                pAV.Refresh()

                            End If
                            ' If the feature value for the column name matches
                            ' Note that pFeature.Value() outputs type Variant

                            ' Set variable indicating to exclude feature

                            'pFeatureSelection.SelectionSet.RemoveList(
                            'MsgBox ("Set the exclusion var to: " + CStr(bExcludeFeat))
                        End If
                    End If
                Next
            End If
        End If
    End Sub
    'Public Function GetFileContents(ByVal FullPath As String, _
    '   Optional ByRef ErrInfo As String = "") As String

    '    Dim sFirstLine, sSecondLine As String
    '    Dim objReader As StreamReader
    '    Try

    '        objReader = New StreamReader(FullPath)
    '        sFirstLine = objReader.ReadLine()
    '        sSecondLine = objReader.ReadLine

    '        objReader.Close()
    '        'GetFileContents.m_LineOne = sFirstLine
    '        'GetFileContents.m_LineTwo = sSecondLine
    '    Catch Ex As Exception
    '        ErrInfo = Ex.Message
    '        MsgBox("Error reading DCI output file. " + ErrInfo)

    '    End Try
    'End Function

    'Public Structure DCIFileStrings
    '    'Structure suggested here: http://www.codewidgets.com/product.aspx?key=55
    '    Public m_LineOne As String
    '    Public m_LineTwo As String
    'End Structure

    Public Function FileWriteDeleteCheck(ByVal sDCIOutputDir As String) As Boolean

        ' Checks user permissions at runtime to read/write/delete to output directory. 
        ' Need to take the previous out.txt and put a default error string in there in case
        ' the DCI model fails.  

        Dim FILE_NAME As String = "out.txt"
        Try
            If File.Exists(sDCIOutputDir + "\" + FILE_NAME) Then
                'MsgBox("tempmsg: this is the file name tested: " + sDCIOutputDir + FILE_NAME)
                'MsgBox("Output directory already contains the write test file. It will be deleted")
                File.Delete(sDCIOutputDir + "\" + FILE_NAME)
            End If
        Catch e As Exception
            MsgBox("You require read/write/delete permissions on the DCI Model Directory. " & e.Message)
        End Try

        Try
            Dim path As String = sDCIOutputDir + "\" + FILE_NAME
            Dim sw As StreamWriter = File.CreateText(path)
            sw.Write("ERROR")
            sw.Close()

            ' Ensure that the target does not exist.
            'File.Delete(path)

            Return True

        Catch e As Exception
            MsgBox("The out.txt file in the DCI Model directory could not be written to.  The following exception was found: " & e.Message)
            Return False
        End Try

    End Function
    Public Function TraceFlowSolverSetup() As ITraceFlowSolver
        ' Prepares the network for tracing

        Dim pNetworkAnalysisExt As INetworkAnalysisExt
        Dim pGeometricNetwork As IGeometricNetwork
        Dim pUtilityNetwork As IUtilityNetwork
        Dim pNetSolver As INetSolver
        Dim pNetworkAnalysisExtBarriers As INetworkAnalysisExtBarriers
        Dim pNetworkAnalysisExtFlags As INetworkAnalysisExtFlags
        Dim pEdgeElementBarriers As INetElementBarriers     ' Should these next two be INetElementBarriersGEN?
        Dim pJunctionElementBarriers As INetElementBarriers
        Dim pSelectionSetBarriers As ISelectionSetBarriers
        Dim pFeatureLayer As IFeatureLayer
        Dim pFlagDisplay As IFlagDisplay
        Dim pEdgeFlagDisplay As IEdgeFlagDisplay
        Dim pEdgeFlags() As IEdgeFlag
        Dim pJunctionFlags() As IJunctionFlag
        Dim pNetFlag As INetFlag
        Dim pEdgeFlag As IEdgeFlag
        'Dim pTraceFlowSolver As ITraceFlowSolver
        Dim pTraceTasks As ITraceTasks
        Dim pNetworkAnalysisExtWeightFilter As INetworkAnalysisExtWeightFilter
        Dim pNetSchema As INetSchema
        Dim pNetWeight As INetWeight
        Dim eWeightFilterType As esriWeightFilterType
        Dim pNetSolverWeights As INetSolverWeights
        Dim pTraceFlowSolver As ITraceFlowSolver

        ' Must change from Object type in VB.Net to Variant in VB6
        Dim lngFromValues() As Object
        Dim lngToValues() As Object

        Dim lngFeatureLayerCount As Integer
        Dim lngEdgeFlagCount As Integer
        Dim lngJunctionFlagCount As Integer
        Dim binFeatureLayerDisabled As Boolean
        Dim binApplyNotOperator As Boolean
        Dim lngFilterRangeCount As Integer
        Dim i As Integer

        If m_FiPEx__1 Is Nothing Then
            m_FiPEx__1 = FiPEX_AddIn_dotNet35_2.FishPassageExtension.GetExtension()
        End If
        If m_UNAExt Is Nothing Then
            m_UNAExt = FiPEX_AddIn_dotNet35_2.FishPassageExtension.GetUNAExt
        End If
        'Dim FiPEx__1 As FishPassageExtension = FiPEX_AddIn_dotNet35_2.FishPassageExtension.GetExtension
        'Dim pUNAExt As IUtilityNetworkAnalysisExt = FiPEX_AddIn_dotNet35_2.FishPassageExtension.GetUNAExt
        If m_pNetworkAnalysisExt Is Nothing Then
            m_pNetworkAnalysisExt = CType(m_UNAExt, INetworkAnalysisExt)
        End If

        ' Get reference to the current network through Utility Network interface
        pNetworkAnalysisExt = CType(m_UNAExt, INetworkAnalysisExt)

        ' Assign a reference to the current geometric network via a local variable
        pGeometricNetwork = pNetworkAnalysisExt.CurrentNetwork

        ' Assign the network to local IUtilityNetwork variable
        ' however, do it through GeometricNetwork which returns
        ' a QI for utilitynetwork using INetwork.... ?

        ' Not all members of IUtilityNetwork be directly calleable
        ' With VB.NET and it has been recommended to use IUtilityNetworkGEN
        ' instead...

        pUtilityNetwork = CType(pGeometricNetwork.Network, IUtilityNetwork)

        ' initialize the trace flow solver and set the network
        pNetSolver = New TraceFlowSolver
        pNetSolver.SourceNetwork = pUtilityNetwork

        ' Get barriers for the network
        ' QI for the interface using the IUtilityNetworkAnalysisExt
        pNetworkAnalysisExtBarriers = CType(m_UNAExt, INetworkAnalysisExtBarriers)
        ' Get the element barriers
        pNetworkAnalysisExtBarriers.CreateElementBarriers(pJunctionElementBarriers, pEdgeElementBarriers)
        ' Get the selection set barriers
        pNetworkAnalysisExtBarriers.CreateSelectionBarriers(pSelectionSetBarriers)
        ' set the barriers for the network solver
        pNetSolver.ElementBarriers(esriElementType.esriETEdge) = pEdgeElementBarriers
        pNetSolver.ElementBarriers(esriElementType.esriETJunction) = pJunctionElementBarriers
        pNetSolver.SelectionSetBarriers = pSelectionSetBarriers


        ' set the barriers for the network solver
        ' for each feature determine if it is enabled.
        ' if it is disabled notify network solver
        ' determine the number of feature layers belonging to network
        lngFeatureLayerCount = pNetworkAnalysisExt.FeatureLayerCount
        For i = 0 To lngFeatureLayerCount - 1
            ' get the next feature layer and determine if it is disabled
            ' assign the feature layer to a local IFeatureLayer variable
            pFeatureLayer = pNetworkAnalysisExt.FeatureLayer(i)
            ' determine if the feature layer is disabled
            binFeatureLayerDisabled = pNetworkAnalysisExtBarriers.GetDisabledLayer(pFeatureLayer)
            ' if it is disabled then notify the network solver
            If binFeatureLayerDisabled Then
                pNetSolver.DisableElementClass(pFeatureLayer.FeatureClass.FeatureClassID)
            End If
        Next

        ' set up the weight filters for the network
        ' QI for the INetworkAnalysisEctWeightFilter interface using
        ' the UtilityNetworkAnalysisExt
        pNetworkAnalysisExtWeightFilter = CType(m_UNAExt, INetworkAnalysisExtWeightFilter)
        ' QI for the INetSolverWeights interace using the INetSolver
        pNetSolverWeights = CType(pNetSolver, INetSolverWeights)
        ' QI for the INetSchema interface using IUtilityNetwork
        pNetSchema = CType(pUtilityNetwork, INetSchema)

        With pNetworkAnalysisExtWeightFilter

            ' Create the junction weight filter
            lngFilterRangeCount = pNetworkAnalysisExtWeightFilter.FilterRangeCount(esriElementType.esriETJunction)
            ' If there are any weight filters
            If lngFilterRangeCount > 0 Then
                ' get a NetWeight object from the INetSchema interface
                pNetWeight = pNetSchema.WeightByName(.JunctionWeightFilterName)
                ' get the type and Not operator status from the InetworkAnalysisExtWeightFileter interface
                .GetFilterType(esriElementType.esriETJunction, eWeightFilterType, binApplyNotOperator)
                ' redimension the weight filter ranges arrays and get the ranges
                ReDim lngFromValues(0 To lngFilterRangeCount - 1)
                ReDim lngToValues(0 To lngFilterRangeCount - 1)
                For i = 0 To lngFilterRangeCount - 1
                    .GetFilterRange(esriElementType.esriETJunction, i, lngFromValues(i), lngToValues(i))
                Next
                ' add the filter ranges to the network solver
                pNetSolverWeights.SetFilterRanges(esriElementType.esriETJunction, lngFilterRangeCount, lngFromValues(0), lngToValues(0))

            End If


            ' create the edge weight filters
            lngFilterRangeCount = pNetworkAnalysisExtWeightFilter.FilterRangeCount(esriElementType.esriETEdge)
            If lngFilterRangeCount > 0 Then

                ' get the type and Not operator status from the INetworkAnalysisExtWeightFilter interface
                .GetFilterType(esriElementType.esriETEdge, eWeightFilterType, binApplyNotOperator)

                ' get a NetWeight object from the INetSchema interface
                pNetWeight = pNetSchema.WeightByName(.FromToEdgeWeightFilterName)
                ' add the weight filter to the network solver
                pNetSolverWeights.FromToEdgeFilterWeight = pNetWeight

                ' get a NetWeight object from the INetScema interface
                pNetWeight = pNetSchema.WeightByName(.ToFromEdgeWeightFilterName)
                ' add the weight filter to the network solver
                pNetSolverWeights.ToFromEdgeFilterWeight = pNetWeight

                'get the filter ranges and apply them to the network solver
                ReDim lngFromValues(0 To lngFilterRangeCount - 1)
                ReDim lngToValues(0 To lngFilterRangeCount - 1)
                For i = 0 To lngFilterRangeCount - 1
                    .GetFilterRange(esriElementType.esriETEdge, i, lngFromValues(i), lngToValues(i))
                Next

                pNetSolverWeights.SetFilterType(esriElementType.esriETEdge, eWeightFilterType, binApplyNotOperator)
                pNetSolverWeights.SetFilterRanges(esriElementType.esriETEdge, lngFilterRangeCount, lngFromValues(0), lngToValues(0))

            End If

        End With


        ' assign the flags to the Network Solver
        ' get the edge flags
        ' QI for the ITraceFlowSolver interface using INetSolver Interface
        pTraceFlowSolver = CType(pNetSolver, ITraceFlowSolver)
        ' QI for the INetworkAnalysisExtFlags interface using the IUtilitNetworkAnalysisExt
        pNetworkAnalysisExtFlags = CType(m_UNAExt, INetworkAnalysisExtFlags)
        ' determine the number of edge flags on the current network
        lngEdgeFlagCount = pNetworkAnalysisExtFlags.EdgeFlagCount

        ' if there are edge flags then
        If Not lngEdgeFlagCount = 0 Then
            ' Redimension the array to hold the correct number of edge flags
            ReDim pEdgeFlags(0 To lngEdgeFlagCount - 1)
            For i = 0 To lngEdgeFlagCount - 1
                ' assign a local variable for IFlagDisplay and IEdgeFlagDisplay variables
                pFlagDisplay = CType(pNetworkAnalysisExtFlags.EdgeFlag(i), IFlagDisplay)
                pEdgeFlagDisplay = CType(pFlagDisplay, IEdgeFlagDisplay)

                ' co-create(?)a new EdgeFlag Object
                pNetFlag = New EdgeFlag
                pEdgeFlag = CType(pNetFlag, IEdgeFlag)
                ' assign the properties of the EdgeFlagDisplay object to he EdgeFlag Object
                ' I think this is where you could determine the distance along the line
                ' an edge flag is. 
                pEdgeFlag.Position = Convert.ToSingle(pEdgeFlagDisplay.Percentage)
                pNetFlag.UserClassID = pFlagDisplay.FeatureClassID
                pNetFlag.UserID = pFlagDisplay.FID
                pNetFlag.UserSubID = pFlagDisplay.SubID
                ' add the new EdgeFlag object to the array
                pEdgeFlags(i) = CType(pNetFlag, IEdgeFlag)
            Next
            ' add the edge flags to the network solver
            'pTraceFlowSolver.PutEdgeOrigins(lngEdgeFlagCount, pEdgeFlags(0))
        End If


        ' Get the junction flags
        ' determine the number of junction flags on the network
        lngJunctionFlagCount = pNetworkAnalysisExtFlags.JunctionFlagCount
        ' only execute this if there are juntion flags
        If Not lngJunctionFlagCount = 0 Then
            ' redimension the array to hold the correct number of junction flags
            ReDim pJunctionFlags(0 To lngJunctionFlagCount - 1)
            For i = 0 To lngJunctionFlagCount - 1

                ' assign to a local IFlagDisplay variable
                pFlagDisplay = CType(pNetworkAnalysisExtFlags.JunctionFlag(i), IFlagDisplay)
                ' co-create a new JunctionFlag object
                pNetFlag = New JunctionFlag
                ' assign the properties of the JunctionFlagDisplay object to the JunctionFlag object
                pNetFlag.UserClassID = pFlagDisplay.FeatureClassID
                pNetFlag.UserID = pFlagDisplay.FID
                pNetFlag.UserSubID = pFlagDisplay.SubID
                ' add the new junction flag to the array of junction flags
                pJunctionFlags(i) = CType(pNetFlag, IJunctionFlag)
            Next
            'add the junction flags to the network solver
            ' This function is not calleable from VB.NET:
            'pTraceFlowSolver.PutJunctionOrigins(lngJunctionFlagCount, pJunctionFlags(0))
            ' So we use this function
            Dim pTraceFlowSolverGEN As ITraceFlowSolverGEN
            pTraceFlowSolverGEN = CType(pNetSolver, ITraceFlowSolverGEN)
            pTraceFlowSolverGEN.PutJunctionOrigins(pJunctionFlags)

        End If

        ' set the option for tracing on indeterminate flow
        ' QI for the ITraceTasksinterface using IUtilityNetworkAnlysisExt
        pTraceTasks = CType(m_UNAExt, ITraceTasks)
        'pTraceFlowSolver.TraceIndeterminateFlow = pTraceTasks.TraceIndeterminateFlow
        pTraceFlowSolver.TraceIndeterminateFlow = True
        pTraceTasks.TraceIndeterminateFlow = True

        ' pass the traceFlowSolver object back to the network solver
        TraceFlowSolverSetup = pTraceFlowSolver

    End Function
    Private Function GetNaturalYN(ByVal iFCID As Integer, ByVal iFID As Integer, ByVal lBarrierIDs As List(Of BarrierIDObj)) As String
        ' =============== FLAG ON POINT WITH Perm? =========================
        ' This section checks whether there is a BarrierPerm Field
        ' In which case it will use this field to identify the 
        ' barrier in the output.
        ' 1.0 For each layer in the table of contents
        '   2.0 If the layer is a FeatureLayer
        '     3.0 If the layer ClassID matches the layer of the CURRENT FLAG
        '     3.1 Get the field values for the feature
        '       4.0 For each of the Barrier IDs in the list
        '         5.0 If the layer in the BarrierID list matches the layer in the TOC
        '         5.1 Get the name of the field
        '           6.0 If the field has something in it
        '             7.0 Set the ID of the flag (dOutValue) equal to that value
        '
        Dim bCheck As Boolean
        Dim j, k As Integer

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap
        Dim pFLayer As IFeatureLayer
        Dim pFeatureClass As IFeatureClass
        Dim pFeature As IFeature
        Dim pFields As IFields
        Dim sNaturalYNField As String
        Dim iBarrierIds As Integer
        Dim sOutNatural As String

        bCheck = False
        For j = 0 To pMap.LayerCount - 1
            If pMap.Layer(j).Valid = True Then
                If TypeOf pMap.Layer(j) Is IFeatureLayer Then
                    pFLayer = CType(pMap.Layer(j), IFeatureLayer)
                    If pFLayer.FeatureClass.FeatureClassID = iFCID Then

                        pFeatureClass = pFLayer.FeatureClass
                        pFeature = pFeatureClass.GetFeature(iFID)
                        pFields = pFeature.Fields
                        iBarrierIds = lBarrierIDs.Count

                        For k = 0 To iBarrierIds - 1
                            If lBarrierIDs.Item(k).Layer = pFLayer.Name Then
                                sNaturalYNField = lBarrierIDs.Item(k).NaturalYNField
                                If pFields.FindField(sNaturalYNField) <> -1 Then
                                    sOutNatural = Convert.ToString(pFeature.Value(pFields.FindField(sNaturalYNField)))
                                    bCheck = True
                                End If ' names match
                            End If
                        Next ' barrierIDField
                        If bCheck = False Then ' assume it's not natural
                            sOutNatural = "F"
                        End If
                    End If ' feature class in map equals feature class of flag
                End If
            End If
        Next

        GetNaturalYN = sOutNatural

    End Function
    Private Function GetBarrierPerm(ByVal iFCID As Integer, ByVal iFID As Integer, ByVal lBarrierIDs As List(Of BarrierIDObj)) As Double
        ' =============== FLAG ON POINT WITH Perm? =========================
        ' This section checks whether there is a BarrierPerm Field
        ' In which case it will use this field to identify the 
        ' barrier in the output.
        ' 1.0 For each layer in the table of contents
        '   2.0 If the layer is a FeatureLayer
        '     3.0 If the layer ClassID matches the layer of the CURRENT FLAG
        '     3.1 Get the field values for the feature
        '       4.0 For each of the Barrier IDs in the list
        '         5.0 If the layer in the BarrierID list matches the layer in the TOC
        '         5.1 Get the name of the field
        '           6.0 If the field has something in it
        '             7.0 Set the ID of the flag (dOutValue) equal to that value
        '
        Dim bCheck As Boolean
        Dim j, k As Integer

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap
        Dim pFLayer As IFeatureLayer
        Dim pFeatureClass As IFeatureClass
        Dim pFeature As IFeature
        Dim pFields As IFields
        Dim sBarrierPermField As String
        Dim iBarrierIds As Integer
        Dim dOutValue As Double

        bCheck = False
        For j = 0 To pMap.LayerCount - 1
            If pMap.Layer(j).Valid = True Then
                If TypeOf pMap.Layer(j) Is IFeatureLayer Then
                    pFLayer = CType(pMap.Layer(j), IFeatureLayer)
                    If pFLayer.FeatureClass.FeatureClassID = iFCID Then

                        pFeatureClass = pFLayer.FeatureClass
                        pFeature = pFeatureClass.GetFeature(iFID)
                        pFields = pFeature.Fields
                        iBarrierIds = lBarrierIDs.Count

                        For k = 0 To iBarrierIds - 1
                            If lBarrierIDs.Item(k).Layer = pFLayer.Name Then
                                sBarrierPermField = lBarrierIDs.Item(k).PermField
                                If pFields.FindField(sBarrierPermField) <> -1 Then
                                    Try
                                        dOutValue = Convert.ToDouble(pFeature.Value(pFields.FindField(sBarrierPermField)))
                                        bCheck = True
                                    Catch ex As Exception
                                        dOutValue = 1
                                    End Try

                                End If ' names match
                            End If
                        Next ' barrierIDField
                        If bCheck = False Then ' names don't match - assume it's a 
                            dOutValue = 0
                        End If
                    End If ' feature class in map equals feature class of flag
                End If
            End If
        Next

        GetBarrierPerm = dOutValue

    End Function
    Private Function GetGLPKOptions(ByVal iFCID As Integer, ByVal iFID As Integer, ByVal lBarrierIDs As List(Of BarrierIDObj), ByVal iEID As Integer) As List(Of GLPKOptionsObject)
        ' =============== FLAG ON POINT WITH Perm? =========================
        ' This function returns a list of the GLPK Options for this barrier
        ' which will be added to the running list in the main sub.
        ' 1.0 For each layer in the table of contents
        '   2.0 If the layer is a FeatureLayer
        '     3.0 If the layer ClassID matches the layer of the CURRENT FLAG
        '     3.1 Get the field values for the feature
        '       4.0 For each of the Barrier IDs in the list
        '         5.0 If the layer in the BarrierID list matches the layer in the TOC
        '         5.1 Get the name of the field
        '           6.0 If the field has something in it
        '             7.0 Set the ID of the flag (dOutValue) equal to that value
        '
        Dim bCheck As Boolean
        Dim j, k, m As Integer

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap
        Dim pFLayer As IFeatureLayer
        Dim pFeatureClass As IFeatureClass
        Dim pFeature As IFeature
        Dim pFields As IFields
        Dim iBarrierIds As Integer
        Dim dOptionPermValue, dOptionCostValue As Double
        Dim lGLPKOptionsListTEMP As List(Of GLPKOptionsObject) = New List(Of GLPKOptionsObject) ' for TEMP options stats for GLPK
        Dim pGLPKOptionsObject As GLPKOptionsObject = New GLPKOptionsObject(Nothing, Nothing, Nothing, Nothing)
        Dim sBarrierOptionPermField, sBarrierOptionCostField As String

        bCheck = False
        For j = 0 To pMap.LayerCount - 1
            If pMap.Layer(j).Valid = True Then
                If TypeOf pMap.Layer(j) Is IFeatureLayer Then
                    pFLayer = CType(pMap.Layer(j), IFeatureLayer)
                    If pFLayer.FeatureClass.FeatureClassID = iFCID Then

                        pFeatureClass = pFLayer.FeatureClass
                        pFeature = pFeatureClass.GetFeature(iFID)
                        pFields = pFeature.Fields
                        iBarrierIds = lBarrierIDs.Count

                        'For k = 0 To iBarrierIds - 1
                        '    If lBarrierIDs.Item(k).Layer = pFLayer.Name Then
                        '        sBarrierPermField = lBarrierIDs.Item(k).PermField
                        '        If pFields.FindField(sBarrierPermField) <> -1 Then
                        '            dOutValue = Convert.ToDouble(pFeature.Value(pFields.FindField(sBarrierPermField)))
                        '            bCheck = True
                        '        End If ' names match
                        '    End If
                        'Next ' barrierIDField

                        ' TEMP SEARCH FOR SPECIFIC FIELDS REPLACES ABOVE
                        For k = 0 To iBarrierIds - 1
                            If lBarrierIDs.Item(k).Layer = pFLayer.Name Then

                                ' for each of the four maximum options to consider
                                ' get the 
                                m = 1
                                For m = 1 To 4
                                    sBarrierOptionPermField = "option" + Convert.ToString(m) + "permafter"
                                    sBarrierOptionCostField = "option" + Convert.ToString(m) + "cost"
                                    If pFields.FindField(sBarrierOptionPermField) <> -1 Then
                                        Try
                                            dOptionPermValue = Convert.ToDouble(pFeature.Value(pFields.FindField(sBarrierOptionPermField)))

                                        Catch ex As Exception
                                            'System.Windows.Forms.MessageBox.Show("The permeability value in the Barriers Layer is Null. Please provide a value. Default value will be used otherwise (0).  " + ex.Message, "")
                                            dOptionPermValue = 9999
                                        End Try

                                        If pFields.FindField(sBarrierOptionCostField) <> -1 Then
                                            Try
                                                dOptionCostValue = Convert.ToDouble(pFeature.Value(pFields.FindField(sBarrierOptionCostField)))

                                            Catch ex As Exception
                                                ' System.Windows.Forms.MessageBox.Show("The cost value in the Barriers Layer is Null. Please provide a value. " + ex.Message, "")
                                                dOptionCostValue = 9999
                                            End Try
                                            bCheck = True
                                            pGLPKOptionsObject = New GLPKOptionsObject(iEID, m + 1, dOptionPermValue, dOptionCostValue)
                                            lGLPKOptionsListTEMP.Add(pGLPKOptionsObject)
                                        Else
                                            ' MsgBox("The Option Cost Value was not found for the " + Convert.ToString(m) + " Option field, but the Permeability field was found")
                                        End If
                                    End If
                                    'm += 1
                                Next 'm (option)

                            End If
                        Next ' barrierIDField

                        If bCheck = False Then ' names don't match - assume it's a 
                            'MsgBox("No options or permeability fields were found in the barriers layer.  No projects will be considered for this barrier/layer except 'do nothing.'")

                        End If
                    End If ' feature class in map equals feature class of flag
                End If
            End If
        Next

        GetGLPKOptions = lGLPKOptionsListTEMP

    End Function

    Private Function GetBarrierID(ByVal iFCID As Integer, ByVal iFID As Integer, ByVal lBarrierIDs As List(Of BarrierIDObj)) As IDandType
        ' =============== FLAG ON POINT WITH BNUMBER? =========================
        ' This section checks whether there is a BNumber Field
        ' In which case it will use this field to identify the 
        ' barrier in the output.
        ' 1.0 For each layer in the table of contents
        '   2.0 If the layer is a FeatureLayer
        '     3.0 If the layer ClassID matches the layer of the CURRENT FLAG
        '     3.1 Get the field values for the feature
        '       4.0 For each of the Barrier IDs in the list
        '         5.0 If the layer in the BarrierID list matches the layer in the TOC
        '         5.1 Get the name of the field
        '           6.0 If the field has something in it
        '             7.0 Set the ID of the flag (sOID) equal to that value
        '
        Dim bCheck As Boolean
        Dim j, k As Integer

        Dim pDoc As IDocument = My.ArcMap.Application.Document
        Dim pMxDoc As IMxDocument = CType(pDoc, IMxDocument)
        Dim pMap As IMap = pMxDoc.FocusMap
        Dim pFLayer As IFeatureLayer
        Dim pFeatureClass As IFeatureClass
        Dim pFeature As IFeature
        Dim pFields As IFields
        Dim sBarrierIDField As String
        Dim iBarrierIds, iOID As Integer
        Dim sOutID As String
        Dim q As Integer
        Dim sAncillaryRole As String

        bCheck = False
        For j = 0 To pMap.LayerCount - 1
            If pMap.Layer(j).Valid = True Then
                If TypeOf pMap.Layer(j) Is IFeatureLayer Then
                    pFLayer = CType(pMap.Layer(j), IFeatureLayer)
                    If pFLayer.FeatureClass.FeatureClassID = iFCID Then

                        pFeatureClass = pFLayer.FeatureClass
                        pFeature = pFeatureClass.GetFeature(iFID)
                        pFields = pFeature.Fields
                        iBarrierIds = lBarrierIDs.Count

                        For k = 0 To iBarrierIds - 1
                            If lBarrierIDs.Item(k).Layer = pFLayer.Name Then
                                sBarrierIDField = lBarrierIDs.Item(k).Field
                                If pFields.FindField(sBarrierIDField) <> -1 Then
                                    Try
                                        sOutID = Convert.ToString(pFeature.Value(pFields.FindField(sBarrierIDField)))
                                    Catch ex As Exception
                                        MsgBox("Could not convert barrier ID to string.")
                                        sOutID = "Unknown"
                                    End Try
                                    bCheck = True
                                End If ' names match
                            End If
                        Next ' barrierIDField
                        If bCheck = False Then ' names don't match - set to default field
                            'sOutID = Convert.ToString(pFeature.Value(pFields.FindField("OBJECTID")))
                            ' If the layer has an ancillaryRole, check to see if the feature
                            q = pFields.FindField("AncillaryRole")
                            If Not q = -1 Then
                                sAncillaryRole = Convert.ToString(pFeature.Value(q))
                                If sAncillaryRole = "2" Then
                                    sOutID = "Sink"
                                    iOID = pFeature.OID.ToString ' Added Feb 18, 2012
                                End If
                            Else
                                sOutID = pFeature.OID.ToString
                            End If
                        End If
                    End If ' feature class in map equals feature class of flag
                End If
            End If
        Next

        Dim pIDAndType As New IDandType(Nothing, Nothing)

        If sOutID = "Sink" Then
            pIDAndType.BarrID = iOID.ToString
            pIDAndType.BarrIDType = sOutID
        Else
            pIDAndType.BarrID = sOutID
            pIDAndType.BarrIDType = "Barrier"
        End If

        GetBarrierID = pIDAndType

    End Function

    Private Function GetWorkspace(ByVal sGDB As String) As IFeatureWorkspace
        ' This function gets a reference to the workspace specified by 
        ' the user in the options menu - used for DBF table output

        Dim pFWorkspace As IFeatureWorkspace
        Dim pWorkspace As IWorkspace

        ' Not sure if workspace name is actually necessary anymore.
        Dim pWorkspaceName As IWorkspaceName = New WorkspaceName
        pWorkspaceName.PathName = sGDB
        Dim pWSFactory As IWorkspaceFactory

        If InStr(sGDB, ".mdb") <> 0 Then
            pWSFactory = New AccessWorkspaceFactory
        ElseIf InStr(sGDB, ".gdb") <> 0 Then
            pWSFactory = New FileGDBWorkspaceFactory
        Else
            pFWorkspace = Nothing
            GetWorkspace = pFWorkspace
            Exit Function
        End If

        Try
            pWorkspace = pWSFactory.OpenFromFile(sGDB, 0)
            pFWorkspace = CType(pWorkspace, IFeatureWorkspace)
            GetWorkspace = pFWorkspace
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show("The geodatabase for DBF output was not found.  Please check the DST options and add an existing geodatabase." + ex.Message, "Geodatbase Not Found")
            GetWorkspace = Nothing
            Exit Function
        End Try

    End Function

    Private Function flagcheck(ByRef pBarriersList As IEnumNetEID, ByRef pEdgeFlags As IEnumNetEID, ByRef pJuncFlags As IEnumNetEID) As String
        ' Function:     Flag Check
        ' Author:       Greig Oldford
        ' Date Created: March 26th, 2008
        ' Date Translated: May 11 - 19, 2009 
        ' Description:  This function will check to see if initially the flags are on barriers
        '               or not. It should stop the analysis if some flags are on barriers and some
        '               are not - it should be one or the other.
        '               It will return one of three strings - "barrier", "nonbarr", or "error"
        '
        ' Notes:   March 27, 2008 -> Not currently checking for edge flags since there is no support for
        '                      them yet.
        Dim i As Integer
        Dim m As Integer
        Dim pFlagsOnBarrGEN As IEnumNetEIDBuilderGEN  ' list holds flags on barriers
        Dim pFlagsNoBarrGEN As IEnumNetEIDBuilderGEN  ' list holds flag not on barriers
        pFlagsOnBarrGEN = New EnumNetEIDArray
        pFlagsNoBarrGEN = New EnumNetEIDArray

        Dim pFlagsOnBarr As IEnumNetEID
        Dim pFlagsNoBarr As IEnumNetEID
        Dim flagBarrier As Boolean
        Dim iEID As Integer

        pJuncFlags.Reset()
        i = 0

        ' For each flag
        For i = 0 To pJuncFlags.Count - 1

            flagBarrier = False     ' assume flag is not on barrier
            iEID = pJuncFlags.Next  ' get the EID of flag
            m = 0
            pBarriersList.Reset()

            ' For each barrier
            For m = 0 To pBarriersList.Count - 1
                'If endEID = pOriginalBarriersList(m) Then 'VB.NET
                If iEID = pBarriersList.Next Then
                    flagBarrier = True
                End If
            Next

            If flagBarrier = True Then  'put EID in flags on barrier list

                ' THIS LIST COULD BE USED IN FUTURE TO FILTER BAD FLAGS OUT
                ' I.E. - check which flags are on barriers and remove only those ones automatically.
                pFlagsOnBarrGEN.Add(iEID)

            Else   ' put EID in flags not on barrier list
                pFlagsNoBarrGEN.Add(iEID)
            End If
        Next

        ' QI to get "next" and "count"
        pFlagsOnBarr = CType(pFlagsOnBarrGEN, IEnumNetEID)
        pFlagsNoBarr = CType(pFlagsNoBarrGEN, IEnumNetEID)

        If pFlagsOnBarr.Count = pJuncFlags.Count Then
            flagcheck = "barriers"
            'return "barriers"? ' should be a return in VB.Net I think... but this works
        ElseIf pFlagsNoBarr.Count = pJuncFlags.Count Then
            flagcheck = "nonbarr"
        Else
            MsgBox("Inconsistent flag placement." + vbCrLf + _
            "Barrier flags: " & pFlagsOnBarr.Count & vbCrLf & _
            " Non-barrier flags: " & pFlagsNoBarr.Count)
            flagcheck = "error"
        End If
    End Function

    Private Function DownStreamConnected(ByRef pUpConnected As IEnumNetEID, ByRef pConnected As IEnumNetEID) As IEnumNetEID

        ' =====================================================
        ' Function:     downstream connected
        ' Author:       Greig Oldford
        ' Date Created: October 11, 2010
        ' Description:  This function accepts two lists of edge or junction elements:
        '               (1) the upstream connected and (2) the connected.  It subtracts
        '               1 from 2 to give the downstream connected and returns this list. 
        ' Note:         This function uses the same logic as flagcheck, essentially. 
        ' =====================================================

        Dim i As Integer
        Dim m As Integer
        Dim pDownstreamConnectedGEN As IEnumNetEIDBuilderGEN  ' list holds flags on barriers
        pDownstreamConnectedGEN = New EnumNetEIDArray

        Dim pDownstreamConnected As IEnumNetEID
        Dim bCommonElement As Boolean
        Dim iEID As Integer

        pConnected.Reset()
        i = 0

        ' For each of the connected elements
        For i = 0 To pConnected.Count - 1

            bCommonElement = False  ' assume flag is not on barrier
            iEID = pConnected.Next  ' get the EID of flag
            m = 0
            pUpConnected.Reset()

            ' For each upstream element
            For m = 0 To pUpConnected.Count - 1
                'If endEID = pOriginalBarriersList(m) Then 'VB.NET
                If iEID = pUpConnected.Next Then
                    bCommonElement = True
                End If
            Next

            If bCommonElement = False Then  'put EID on downstream connected list
                ' THIS LIST COULD BE USED IN FUTURE TO FILTER BAD FLAGS OUT
                ' I.E. - check which flags are on barriers and remove only those ones automatically.
                pDownstreamConnectedGEN.Add(iEID)
            End If
        Next

        ' QI 
        pDownstreamConnected = CType(pDownstreamConnectedGEN, IEnumNetEID)
        DownStreamConnected = pDownstreamConnected

    End Function

    Private Function TableName(ByVal sKeyword As String, ByVal pFWorkspace As IFeatureWorkspace, ByRef sPrefix As String) As String
        ' Function:    Table Name
        ' Created By:  Greig Oldford
        ' Update Date: October 5, 2010
        ' Purpose:     1) To check for table name conflicts in output
        '                 workspace
        ' Keyword: "Habitat","Metrics","DCI","Connectivity"
        '

        Dim pWorkspace As IWorkspace
        Dim sFilepath As String
        Dim pWorkspaceFactory As IWorkspaceFactory
        Dim pWorkspace2 As IWorkspace2
        Dim message As String
        Dim title As String
        Dim defaultValue As String
        Dim myTableName As Object
        Dim reg As New Regex("^[A-Za-z0-9_]+$") ' checks if prefix contains allowed characters
        Dim reg2 As New Regex("^[0-9]")         ' for checking if string starts with numbers
        Dim sName As String

        pWorkspace = CType(pFWorkspace, IWorkspace)
        sFilepath = pWorkspace.PathName

        ' Need to connect to the personal or file geodatabase workspace
        ' to check to see if tablename already exists.
        Dim strCategory As String
        Dim pFGDBWFactory As New FileGDBWorkspaceFactory
        Dim pAccessWFactory As New AccessWorkspaceFactory

        ' Check what kind of workspace it is
        strCategory = GetCategory(pWorkspace)

        ' TODO: add code for if workspace is not one of these two types
        If strCategory = "File Geodatabase" Then
            pWorkspaceFactory = pFGDBWFactory
        ElseIf strCategory = "Personal Geodatabase" Then
            pWorkspaceFactory = pAccessWFactory
        End If

        ' Check if name prefix starts with numbers (not allowed)
        Dim bNumCheck As Boolean = False
        Dim bLengthCheck As Boolean = True
        Dim bCharCheck As Boolean = True
        Dim bValidate As Boolean = False

        Dim sNumMsg As String
        Dim sLengthMsg As String
        Dim sCharMsg As String

        ' Check for invalid characters
        ' Check for table names beginning with numbers
        ' Check that table name does not exist in workspace
        ' THIS SECTION HAS REPEATED CODE - INEFFICIENT AND COULD BE IMPROVED
        Do Until bValidate = True

            'Check that user hasn't entered invalid text for tablename
            bCharCheck = reg.IsMatch(sPrefix) 'For VB.NET
            ' Check if prefix starts with numbers (not allowed in ArcGIS for table names)
            bNumCheck = reg2.IsMatch(sPrefix)
            ' Check if table name is too long (>55)
            sName = sPrefix + "_" + sKeyword
            ' Check that length of table name isn't too long
            If Len(sName) > 55 Then
                bLengthCheck = False
            Else
                bLengthCheck = True
            End If

            If bCharCheck = False Or bNumCheck = True Or bLengthCheck = False Then

                title = "Problem with table name"
                If bCharCheck = False Then
                    sCharMsg = "Invalid character in table name. Table name may only include spaces, numbers, or _"
                Else
                    sCharMsg = "OK"
                End If
                If bNumCheck = True Then
                    sNumMsg = "Table names cannot begin with numbers in ArcGIS."
                Else
                    sNumMsg = "OK"
                End If
                If bLengthCheck = False Then
                    sLengthMsg = "Table name is too long.  Name cannot exceed 55 characters in ArcGIS"
                Else
                    sLengthMsg = "OK"
                End If

                message = "Invalid table name, please enter a new prefix." & Environment.NewLine & _
                "Characters: " & sCharMsg & Environment.NewLine _
                & "First Character: " & sNumMsg & Environment.NewLine _
                & "Length: " & sLengthMsg

                defaultValue = ""
                myTableName = InputBox(message, title, defaultValue)

                sName = myTableName.ToString
                If sName = "" Then
                    Return "Cancel"
                End If

                bValidate = False
            Else
                bValidate = True
            End If

        Loop

        Dim bExists As Boolean = True
        Dim iUnderIndex As Integer
        Dim sTrimmedStrRight As String
        Dim sTrimmedStrLeft As String
        Dim iTrimmedSuffix As Integer

        Do Until bExists = False
            ' Open the database and check if name exists
            pWorkspace2 = CType(pWorkspaceFactory.OpenFromFile(sFilepath, 0), IWorkspace2)
            bExists = pWorkspace2.NameExists(esriDatasetType.esriDTTable, sName)

            ' If the table exists then rename it by either auto-incrementing the number
            ' on the end or tacking a _1 on the end.  
            If bExists = True Then
                iUnderIndex = sName.LastIndexOf("_")
                sTrimmedStrRight = sName.Substring(iUnderIndex + 1)
                If IsNumeric(sTrimmedStrRight) Then
                    iTrimmedSuffix = Convert.ToInt16(sTrimmedStrRight)
                    iTrimmedSuffix += 1
                    sTrimmedStrLeft = sName.Remove(iUnderIndex + 1, sTrimmedStrRight.Length)
                    sName = sTrimmedStrLeft + CStr(iTrimmedSuffix)
                Else
                    sName = sName + "_1"
                End If
            End If
        Loop

        ' make the sPrefix global so it persists in next loop
        ' to prevent userInput box from popping up all the time
        'm_sPrefix = sPrefix

        Return sName ' VB.NET

        'TableName = sName
    End Function
    ' This function returns the kind of workspace the geometric network is in
    Public Function GetCategory(ByVal pWorkspace As IWorkspace) As String
        Dim pClassID As New UID
        pClassID = pWorkspace.WorkspaceFactory.GetClassID
        Select Case pClassID.Value.ToString
            Case "{DD48C96A-D92A-11D1-AA81-00C04FA33A15}" ' pGDB
                'GetCategory = "Personal Geodatabase"
                Return "Personal Geodatabase"
            Case "{71FE75F0-EA0C-4406-873E-B7D53748AE7E}" ' fGDB
                'GetCategory = "File Geodatabase"
                Return "File Geodatabase"
            Case "{D9B4FA40-D6D9-11D1-AA81-00C04FA33A15}" ' GDB
                'GetCategory = "SDE Database"
                Return "SDE Database"
            Case "{A06ADB96-D95C-11D1-AA81-00C04FA33A15}" ' Shape
                'GetCategory = "Shapefile Workspace"
                Return "Shapefile Workspace"
            Case "{1D887452-D9F2-11D1-AA81-00C04FA33A15}" ' Coverage
                'GetCategory = "ArcInfo Coverage Workspace"
                Return "ArcInfo Coverage Workspace"
            Case Else
                'GetCategory = "Unknown Workspace Category"
                Return "Unknown Workspace Category"
        End Select
    End Function



End Class
