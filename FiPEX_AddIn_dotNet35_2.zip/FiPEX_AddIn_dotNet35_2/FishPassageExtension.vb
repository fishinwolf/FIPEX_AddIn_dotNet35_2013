﻿
Imports ESRI.ArcGIS.ADF.CATIDs
Imports ESRI.ArcGIS.esriSystem
Imports System.Runtime.InteropServices
'Imports System.Windows.Data.Binding
Imports System.IO
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.EditorExt
Imports ESRI.ArcGIS.NetworkAnalysis
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Desktop.AddIns
Imports System.Windows.Forms


'Namespace PersistExtensionAddIn
Public Class FishPassageExtension
    Inherits ESRI.ArcGIS.Desktop.AddIns.Extension


    ' =================
    '==================
    'Imports system.windows.forms

    'Implements IExtension
    'Implements IExtensionConfig
    'Implements IPersistVariant

    ' self-reference for inter component communication 
    ' from http://help.arcgis.com/en/sdk/10.0/arcobjects_net/conceptualhelp/index.html#/Add_in_coding_patterns/0001000000zz000000/
    Private Shared s_extension As FishPassageExtension
    Private Shared m_UNAextension As ESRI.ArcGIS.EditorExt.IUtilityNetworkAnalysisExt



    Private m_bHasNetworks As Boolean = False
    Private m_application As IApplication
    Public m_enableState As ExtensionState

    Public pPropset As ESRI.ArcGIS.esriSystem.IPropertySet = New PropertySet
    'Public _sDictionary As New Dictionary(Of String, String)
    Public m_bLoaded As Boolean = False ' variable to check whether this is a new document or a loaded document.
    Public m_bFlagsLoaded As Boolean = False
    Public m_bBarriersLoaded As Boolean = False

    Private Const RequiredProductCode As esriLicenseProductCode = esriLicenseProductCode.esriLicenseProductCodeArcInfo


    Public Sub New()
        s_extension = Me
    End Sub
    Public Property ToolsEnabledProp() As Boolean
        ' used to tell tools whether they're enabled or disabled.  
        ' tied to the 
        Get

        End Get
        Set(ByVal value As Boolean)

        End Set
    End Property
    Public Property HasNetworkProp() As Boolean
        Get
            Return m_bHasNetworks
        End Get
        Set(ByVal value As Boolean)
            m_bHasNetworks = value
        End Set
    End Property


    Friend Shared Function GetExtension() As FishPassageExtension
        ' Extension loads just in time, call FindExtension to load it.
        ' this gets a reference to the instance of this extension occuring in the '
        ' map application
        If s_extension Is Nothing Then
            Dim extID As UID = New UIDClass()
            extID.Value = "DFO_Maritimes__FiPEX_AddIn_dotNet35_2_FishPassageExtension"
            My.ArcMap.Application.FindExtensionByCLSID(extID)
        End If
        Return s_extension
    End Function

    Friend Shared Function GetUNAExt() As ESRI.ArcGIS.EditorExt.IUtilityNetworkAnalysisExt

        If m_UNAextension Is Nothing Then

            ' sets the guid of the utility network analyst extension
            Dim pUID As New ESRI.ArcGIS.esriSystem.UID
            pUID.Value = "{98528F9B-B971-11D2-BABD-00C04FA33C20}"

            Dim pExtension As ESRI.ArcGIS.esriSystem.IExtension
            pExtension = My.ArcMap.Application.FindExtensionByCLSID(pUID)

            m_UNAextension = TryCast(pExtension, ESRI.ArcGIS.EditorExt.IUtilityNetworkAnalysisExt)

        End If
        Return m_UNAextension
    End Function

    Friend Sub DoWork()
        System.Windows.Forms.MessageBox.Show("Do work")
    End Sub


    Protected Overrides Sub OnStartup()
        '
        ' TODO: Uncomment to start listening to document events
        '
        WireDocumentEvents()
        s_extension = Me

        GetUNAExt()
        Initialize()

        'Dim pNetworkAnalysisExt As INetworkAnalysisExt
        'pNetworkAnalysisExt = CType(m_UNAextension, INetworkAnalysisExt)
        'Dim iNetworkCountSource As Integer = pNetworkAnalysisExt.NetworkCount

        'Dim myBinding As New Binding("MyDataProperty")

    End Sub

    Private Sub Initialize()
        If s_extension Is Nothing Or Me.State <> ExtensionState.Enabled Then
            Return
        End If

        ' Reset event handlers
        Dim avEvent As IActiveViewEvents_Event = TryCast(My.ArcMap.Document.FocusMap, IActiveViewEvents_Event)
        AddHandler avEvent.ItemAdded, AddressOf AvEvent_ItemAdded
        AddHandler avEvent.ItemDeleted, AddressOf AvEvent_ItemAdded
        AddHandler avEvent.ContentsChanged, AddressOf MapEvents_ContentsChanged

        ' Wire up events
        AddHandler My.ArcMap.Events.NewDocument, AddressOf ArcMap_NewOpenDocument
        AddHandler My.ArcMap.Events.OpenDocument, AddressOf ArcMap_NewOpenDocument

        ' Update the UI
        'm_map = ArcMap.Document.FocusMap
        m_bHasNetworks = CheckNetworkCount()

        'If m_bLoaded = False Then
        '    m_bLoaded = True
        'End If
        If m_bLoaded = False Then
            With pPropset
                ' Load defaults
                .SetProperty("direction", "up")
                .SetProperty("ordernum", Convert.ToInt32(999))
                .SetProperty("maximum", Convert.ToBoolean("True"))
                .SetProperty("connecttab", Convert.ToBoolean("False"))
                .SetProperty("barrierperm", Convert.ToBoolean("False"))
                .SetProperty("naturalyn", Convert.ToBoolean("False"))
                .SetProperty("dciyn", Convert.ToBoolean("False"))
                .SetProperty("dcisectionalyn", Convert.ToBoolean("False"))
                .SetProperty("sDCIModelDir", Convert.ToString("not set"))
                .SetProperty("sRInstallDir", Convert.ToString("not set"))
                .SetProperty("bDBF", Convert.ToBoolean("False"))
                .SetProperty("sGDB", Convert.ToString("not set"))
                .SetProperty("TabPrefix", Convert.ToString("not set"))

                .SetProperty("UpHab", Convert.ToBoolean("True"))
                .SetProperty("TotalUpHab", Convert.ToBoolean("True"))
                .SetProperty("DownHab", Convert.ToBoolean("False"))
                .SetProperty("TotalDownHab", Convert.ToBoolean("False"))
                .SetProperty("PathDownHab", Convert.ToBoolean("False"))
                .SetProperty("TotalPathDownHab", Convert.ToBoolean("False"))

                .SetProperty("numPolys", Convert.ToInt32(0))
                .SetProperty("numLines", Convert.ToInt32(0))
                .SetProperty("numExclusions", Convert.ToInt32(0))
                .SetProperty("numBarrierIDs", Convert.ToInt32(0))
                .SetProperty("barrierEIDsLoadedyn", Convert.ToBoolean("False"))
                .SetProperty("numBarrierEIDs", Convert.ToInt32(0))
                .SetProperty("flagEIDsLoadedyn", Convert.ToBoolean("False"))
                .SetProperty("numFlagEIDs", Convert.ToInt32(0))

                .SetProperty("bGLPKTables", Convert.ToBoolean("False"))

                m_bLoaded = True
                m_bFlagsLoaded = False
                m_bBarriersLoaded = False
            End With
        End If

    End Sub
    Private Sub Uninitialize()
        If s_extension Is Nothing Then
            Return
        End If

        ' Detach event handlers
        Dim avEvent As IActiveViewEvents_Event = TryCast(My.Document.FocusMap, IActiveViewEvents_Event)
        RemoveHandler avEvent.ItemAdded, AddressOf AvEvent_ItemAdded
        RemoveHandler avEvent.ItemDeleted, AddressOf AvEvent_ItemAdded
        RemoveHandler avEvent.ContentsChanged, AddressOf MapEvents_ContentsChanged
        avEvent = Nothing

        ' Update UI
        ' set all the buttons disabled.
        '.SetEnabled(False)
    End Sub
    Protected Overrides Function OnGetState() As ExtensionState
        m_enableState = Me.State
        Return Me.State
    End Function
    Protected Overrides Function OnSetState(ByVal state As ExtensionState) As Boolean
        ' Optionally check for a license here

        Me.State = state
        m_enableState = state

        If state = ExtensionState.Enabled Then
            Initialize()
        Else
            Uninitialize()
        End If

        Return MyBase.OnSetState(state)
    End Function
    Private Sub AvEvent_ItemAdded(ByVal Item As Object)
        'm_map = ArcMap.Document.FocusMap
        'FillComboBox()
        'UpdateSelCountDockWin()
        m_bHasNetworks = CheckNetworkCount()
    End Sub

    Protected Overrides Sub OnShutdown()

    End Sub

    Private Sub ArcMap_NewOpenDocument()
        Dim pageLayoutEvent As IActiveViewEvents_Event = TryCast(My.ArcMap.Document.PageLayout, IActiveViewEvents_Event)
        AddHandler pageLayoutEvent.FocusMapChanged, AddressOf AVEvents_FocusMapChanged

        'Initialize()

        'If m_bHasNetworks = True Then
        '    If m_bFlagsLoaded = False Then

        '        Dim iFlagEIDCount As Integer = pPropset.GetProperty("numFlagEIDs")
        '        If iFlagEIDCount > 0 Then

        '            ' Get the active network
        '            ' The network shouldn't be empty because the extension wouldn't be enabled otherwise
        '            Dim pNetworkAnalysisExt As INetworkAnalysisExt
        '            Dim pUNAExt As IUtilityNetworkAnalysisExt
        '            pUNAExt = GetUNAExt()

        '            Dim pGeometricNetwork As IGeometricNetwork
        '            pNetworkAnalysisExt = CType(pUNAExt, INetworkAnalysisExt)
        '            pGeometricNetwork = pNetworkAnalysisExt.CurrentNetwork

        '            ' Get the network elements for EID retrieval
        '            Dim pNetwork As INetwork
        '            Dim pNetElements As INetElements
        '            pNetwork = pGeometricNetwork.Network
        '            pNetElements = CType(pNetwork, INetElements)

        '            Dim pNetworkAnalysisExtFlags As INetworkAnalysisExtFlags
        '            pNetworkAnalysisExtFlags = CType(pUNAExt, INetworkAnalysisExtFlags)

        '            ' if current network has no flags loaded (double ensure this isn't run twice - 
        '            '  only at the document load)
        '            If pNetworkAnalysisExtFlags.JunctionFlagCount = 0 Then

        '                Dim i As Integer = 0
        '                Dim iEID, iFID, iFCID, iSubID As Integer
        '                Dim lFlagEIDs As New List(Of Integer)
        '                For i = 0 To iFlagEIDCount - 1
        '                    iEID = Convert.ToInt32(pPropset.GetProperty("flagEID" + i.ToString))
        '                    lFlagEIDs.Add(iEID)
        '                Next

        '                Dim pFlagDisplay As IFlagDisplay
        '                Dim pRgbColor As ESRI.ArcGIS.Display.IRgbColor
        '                pRgbColor = New ESRI.ArcGIS.Display.RgbColor

        '                ' Set the flag symbol color and parameters
        '                Dim pSimpleMarkerSymbol As ESRI.ArcGIS.Display.ISimpleMarkerSymbol
        '                ' For the Flag marker
        '                With pRgbColor
        '                    .Red = 0
        '                    .Green = 255
        '                    .Blue = 0
        '                End With
        '                pSimpleMarkerSymbol = New ESRI.ArcGIS.Display.SimpleMarkerSymbol
        '                With pSimpleMarkerSymbol
        '                    .Color = pRgbColor
        '                    .Style = ESRI.ArcGIS.Display.esriSimpleMarkerStyle.esriSMSSquare
        '                    .Outline = True
        '                    .Size = 10
        '                End With

        '                ' Result is a global variable containing a flag marker
        '                'm_FlagSymbol4 = pSimpleMarkerSymbol
        '                Dim pSymbol As ESRI.ArcGIS.Display.ISymbol
        '                Dim pJuncFlagDisplay As IJunctionFlagDisplay

        '                i = 0
        '                For i = 0 To lFlagEIDs.Count - 1
        '                    iEID = lFlagEIDs(i)
        '                    ' just a safe guard against a screwup - ieid = 0
        '                    If iEID <> 0 Then
        '                        pNetElements.QueryIDs(iEID, esriElementType.esriETJunction, iFCID, iFID, iSubID)

        '                        ' Display the flags as a JunctionFlagDisplay type
        '                        pFlagDisplay = New JunctionFlagDisplay
        '                        pSymbol = CType(pSimpleMarkerSymbol, ESRI.ArcGIS.Display.ISymbol)
        '                        With pFlagDisplay
        '                            .FeatureClassID = iFCID
        '                            .FID = iFID
        '                            .Geometry = pGeometricNetwork.GeometryForJunctionEID(iEID)
        '                            .Symbol = pSymbol
        '                        End With

        '                        ' Add the flags to the logical network
        '                        pJuncFlagDisplay = CType(pFlagDisplay, IJunctionFlagDisplay)
        '                        pNetworkAnalysisExtFlags.AddJunctionFlag(pJuncFlagDisplay)
        '                    End If ' ieid = 0
        '                Next
        '                ' flag count > 0 
        '            End If 'there were any flags set for this network

        '        End If
        '        m_bFlagsLoaded = True
        '    End If
        ' End If

    End Sub

    Private Sub AVEvents_FocusMapChanged()


        Initialize()
    End Sub
    Private Sub WireDocumentEvents()
        '
        ' TODO: Sample document event wiring code. Change as needed.
        '
        'AddHandler My.ArcMap.Events.NewDocument, AddressOf ArcMapNewDocument

    End Sub

    Private Sub ArcMapNewDocument()
        ' TODO: Add code to handle new document event
    End Sub

    ''' <summary>
    ''' Determine extension state
    ''' </summary>
    'Private Function StateCheck(ByVal requestEnable As Boolean) As esriExtensionState
    '    'Turn on or off extension directly 
    '    If requestEnable Then
    '        'Check if the correct product is licensed
    '        'Dim aoInitTestProduct As IAoInitialize = New AoInitializeClass()
    '        'Dim prodCode As esriLicenseProductCode = aoInitTestProduct.InitializedProduct()
    '        'If prodCode = RequiredProductCode Then _
    '        Return esriExtensionState.esriESEnabled

    '        'Return esriExtensionState.esriESUnavailable
    '    Else
    '        Return esriExtensionState.esriESDisabled
    '    End If
    'End Function

    '#Region "IExtension Members"
    '    ''' <summary>
    '    ''' Name of extension. Do not exceed 31 characters
    '    ''' </summary>
    '    Public ReadOnly Property Name() As String Implements ESRI.ArcGIS.esriSystem.IExtension.Name
    '        Get
    '            Return "DFOBarriersAnalysisExtension"
    '        End Get
    '    End Property

    '    Public Sub Shutdown() Implements ESRI.ArcGIS.esriSystem.IExtension.Shutdown
    '        m_application = Nothing
    '    End Sub

    '    Public Sub Startup(ByRef initializationData As Object) Implements ESRI.ArcGIS.esriSystem.IExtension.Startup
    '        m_application = CType(initializationData, IApplication)
    '        If m_application Is Nothing Then Return

    '    End Sub
    '#End Region

    '#Region "IExtensionConfig Members"
    '    Public ReadOnly Property Description() As String Implements ESRI.ArcGIS.esriSystem.IExtensionConfig.Description
    '        Get
    '            Return "DFO Maritimes Fish Passage Extension"
    '        End Get
    '    End Property

    '    ''' <summary>
    '    ''' Friendly name shown in the Extensions dialog
    '    ''' </summary>
    '    Public ReadOnly Property ProductName() As String Implements ESRI.ArcGIS.esriSystem.IExtensionConfig.ProductName
    '        Get
    '            Return "DFO Maritimes Fish Passage Extension"
    '        End Get
    '    End Property

    '    Public Property State() As ESRI.ArcGIS.esriSystem.esriExtensionState Implements ESRI.ArcGIS.esriSystem.IExtensionConfig.State
    '        Get
    '            Return m_enableState
    '        End Get
    '        Set(ByVal value As ESRI.ArcGIS.esriSystem.esriExtensionState)
    '            If m_enableState <> 0 And value = m_enableState Then Exit Property

    '            'Check if ok to enable or disable extension
    '            Dim requestState As esriExtensionState = value
    '            If requestState = esriExtensionState.esriESEnabled Then
    '                'Cannot enable if it's already in unavailable state
    '                If m_enableState = esriExtensionState.esriESUnavailable Then
    '                    Throw New COMException("Not running the appropriate product license.")
    '                End If

    '                'Determine if state can be changed
    '                Dim checkState As esriExtensionState = StateCheck(True)
    '                m_enableState = checkState

    '                If m_enableState = esriExtensionState.esriESUnavailable Then
    '                    Throw New COMException("Not running the appropriate product license.")
    '                End If

    '            ElseIf requestState = esriExtensionState.esriESDisabled Then
    '                'Determine if state can be changed
    '                Dim checkState As esriExtensionState = StateCheck(False)
    '                If (m_enableState <> checkState) Then m_enableState = checkState
    '            End If
    '        End Set
    '    End Property
    '#End Region

    '#Region "Persistence Members"

    '    Public ReadOnly Property ID() As ESRI.ArcGIS.esriSystem.UID Implements ESRI.ArcGIS.esriSystem.IPersistVariant.ID
    '        Get
    '            Dim extUID As New UIDClass()
    '            extUID.Value = Me.GetType().GUID.ToString("B") '"b" is a format - not sure what it is exactly from object def
    '            Return extUID
    '        End Get
    '    End Property
    ' this sub is run at the time the mxd document is loaded

    Protected Overloads Overrides Sub OnLoad(ByVal inStrm As Stream)
        'Public Sub Load(ByVal Stream As ESRI.ArcGIS.esriSystem.IVariantStream) Implements ESRI.ArcGIS.esriSystem.IPersistVariant.Load

        ' ================================================
        ' Purpose: Load Extension settings to property set
        '
        ' 1) Check the first item from the stream
        '   2) If it says "check" then
        '   3) Populate Propertyset with stream properties
        '   4) Set the PUBLIC variable bLoaded = True
        '
        ' NOTE: Be careful when adding new properties then 
        '       accessing a document that has properties saved
        '       from old stream - will not match!

        Dim iPolysCount As Integer = 0   ' number of polygon layers currently using
        Dim i As Integer = 0             ' loop counter
        Dim iLinesCount As Integer = 0   ' number of lines layers currently using
        Dim j As Integer = 0             ' loop counter
        Dim iExclusions As Integer = 0
        Dim iBarrierIDs As Integer = 0
        Dim iBarrierEIDCount As Integer = 0
        Dim lBarrierEIDs As List(Of Integer) = New List(Of Integer)
        Dim iFlagEIDCount As Integer = 0

        'Dim sDictionary As New Dictionary(Of String, String)
        Dim sDictionary As New Dictionary(Of String, String)
        Dim bf = New System.Runtime.Serialization.Formatters.Binary.BinaryFormatter()
        sDictionary = CType(bf.Deserialize(inStrm), Dictionary(Of String, String))

        ' '' Load the stream of properties into a property set
        ''Dim propcheck As String = Convert.ToString(Stream.Read())
        ''If propcheck = "yes" Then
        'Dim streamCheck As String ' to check if extension settings have been saved in mxd
        '    streamCheck = Convert.ToString(inStrm.)

        If sDictionary.Item("check") = "check" Then
            With pPropset
                .SetProperty("direction", sDictionary.Item("direction"))
                .SetProperty("ordernum", Convert.ToInt32(sDictionary.Item("ordernum")))
                .SetProperty("maximum", Convert.ToBoolean(sDictionary.Item("maximum")))
                .SetProperty("connecttab", Convert.ToBoolean(sDictionary.Item("connecttab")))
                .SetProperty("barrierperm", Convert.ToBoolean(sDictionary.Item("barrierperm")))
                .SetProperty("naturalyn", Convert.ToBoolean(sDictionary.Item("naturalyn")))
                .SetProperty("dciyn", Convert.ToBoolean(sDictionary.Item("dciyn")))
                .SetProperty("dcisectionalyn", Convert.ToBoolean(sDictionary.Item("dcisectionalyn")))
                .SetProperty("sDCIModelDir", Convert.ToString(sDictionary.Item("sDCIModelDir")))
                .SetProperty("sRInstallDir", Convert.ToString(sDictionary.Item("sRInstallDir")))
                .SetProperty("bDBF", Convert.ToBoolean(sDictionary.Item("bDBF")))
                .SetProperty("sGDB", Convert.ToString(sDictionary.Item("sGDB")))
                .SetProperty("TabPrefix", Convert.ToString(sDictionary.Item("TabPrefix")))

                .SetProperty("UpHab", Convert.ToBoolean(sDictionary.Item("UpHab")))
                .SetProperty("TotalUpHab", Convert.ToBoolean(sDictionary.Item("TotalUpHab")))
                .SetProperty("DownHab", Convert.ToBoolean(sDictionary.Item("DownHab")))
                .SetProperty("TotalDownHab", Convert.ToBoolean(sDictionary.Item("TotalDownHab")))
                .SetProperty("PathDownHab", Convert.ToBoolean(sDictionary.Item("PathDownHab")))
                .SetProperty("TotalPathDownHab", Convert.ToBoolean(sDictionary.Item("TotalPathDownHab")))

                .SetProperty("numPolys", Convert.ToInt32(sDictionary.Item("numPolys")))

                ' Add each polygon and respective hab quan and qual fields as a property
                ' Add each habitat class and quantity field as property
                iPolysCount = Convert.ToInt32(pPropset.GetProperty("numPolys"))
                If iPolysCount > 0 Then
                    i = 0
                    For i = 0 To iPolysCount - 1
                        .SetProperty("IncPoly" + i.ToString, Convert.ToString(sDictionary.Item("IncPoly" + i.ToString)))
                        .SetProperty("PolyClassField" + i.ToString, Convert.ToString(sDictionary.Item("PolyClassField" + i.ToString)))
                        .SetProperty("PolyQuanField" + i.ToString, Convert.ToString(sDictionary.Item("PolyQuanField" + i.ToString)))
                        .SetProperty("PolyUnitField" + i.ToString, Convert.ToString(sDictionary.Item("PolyUnitField" + i.ToString)))
                    Next
                End If

                .SetProperty("numLines", Convert.ToInt32(sDictionary.Item("numLines")))

                ' Add each line included as a property
                ' Add each habitat class and quantity field as property
                iLinesCount = Convert.ToInt32(pPropset.GetProperty("numLines"))
                If iLinesCount > 0 Then
                    j = 0
                    For j = 0 To iLinesCount - 1
                        .SetProperty("IncLine" + j.ToString, Convert.ToString(sDictionary.Item("IncLine" + j.ToString)))
                        .SetProperty("LineClassField" + j.ToString, Convert.ToString(sDictionary.Item("LineClassField" + j.ToString)))
                        .SetProperty("LineQuanField" + j.ToString, Convert.ToString(sDictionary.Item("LineQuanField" + j.ToString)))
                        .SetProperty("LineUnitField" + j.ToString, Convert.ToString(sDictionary.Item("LineUnitField" + j.ToString)))
                    Next
                End If

                .SetProperty("numExclusions", Convert.ToInt32(sDictionary.Item("numExclusions")))

                ' Add each line included as a property
                ' Add each habitat class and quantity field as property
                iExclusions = Convert.ToInt32(pPropset.GetProperty("numExclusions"))
                If iExclusions > 0 Then
                    i = 0
                    For i = 0 To iExclusions - 1
                        .SetProperty("ExcldLayer" + i.ToString, Convert.ToString(sDictionary.Item("ExcldLayer" + i.ToString)))
                        .SetProperty("ExcldFeature" + i.ToString, Convert.ToString(sDictionary.Item("ExcldFeature" + i.ToString)))
                        .SetProperty("ExcldValue" + i.ToString, Convert.ToString(sDictionary.Item("ExcldValue" + i.ToString)))
                    Next
                End If

                .SetProperty("numBarrierIDs", Convert.ToInt32(sDictionary.Item("numBarrierIDs")))

                ' Add each line included as a property
                ' Add each habitat class and quantity field as property
                iBarrierIDs = Convert.ToInt32(pPropset.GetProperty("numBarrierIDs"))
                If iBarrierIDs > 0 Then
                    i = 0
                    For i = 0 To iBarrierIDs - 1
                        .SetProperty("BarrierIDLayer" + i.ToString, Convert.ToString(sDictionary.Item("BarrierIDLayer" + i.ToString)))
                        .SetProperty("BarrierIDField" + i.ToString, Convert.ToString(sDictionary.Item("BarrierIDField" + i.ToString)))
                        .SetProperty("BarrierPermField" + i.ToString, Convert.ToString(sDictionary.Item("BarrierPermField" + i.ToString)))
                        .SetProperty("BarrierNaturalYNField" + i.ToString, Convert.ToString(sDictionary.Item("BarrierNaturalYNField" + i.ToString)))
                    Next
                End If

                '.SetProperty("barrierEIDsLoadedyn", Convert.ToBoolean(sDictionary.Item("barrierEIDsLoadedyn")))
                .SetProperty("barrierEIDsLoadedyn", Convert.ToBoolean("false"))

                .SetProperty("numBarrierEIDs", Convert.ToInt32(sDictionary.Item("numBarrierEIDs")))

                iBarrierEIDCount = Convert.ToInt32(pPropset.GetProperty("numBarrierEIDs"))
                If iBarrierEIDCount > 0 Then
                    i = 0
                    For i = 0 To iBarrierEIDCount - 1
                        .SetProperty("BarrierEID" + i.ToString, Convert.ToInt32(sDictionary.Item("BarrierEID" + i.ToString)))
                    Next
                End If

                '.SetProperty("flagEIDsLoadedyn", Convert.ToBoolean(sDictionary.Item("flagEIDsLoadedyn")))
                .SetProperty("flagEIDsLoadedyn", Convert.ToBoolean("false"))
                .SetProperty("numFlagEIDs", Convert.ToInt32(sDictionary.Item("numFlagEIDs")))

                iFlagEIDCount = Convert.ToInt32(pPropset.GetProperty("numFlagEIDs"))
                If iFlagEIDCount > 0 Then
                    i = 0
                    For i = 0 To iFlagEIDCount - 1
                        .SetProperty("FlagEID" + i.ToString, Convert.ToInt32(sDictionary.Item("FlagEID" + i.ToString)))
                    Next
                End If

                Dim bGLPKTables As Boolean
                Try
                    bGLPKTables = sDictionary.Item("bGLPKTables")

                    .SetProperty("bGLPKTables", Convert.ToBoolean(sDictionary.Item("bGLPKTables")))
                    .SetProperty("sGLPKModelDir", Convert.ToString(sDictionary.Item("sGLPKModelDir")))
                    .SetProperty("sGnuWinDir", Convert.ToString(sDictionary.Item("sGnuWinDir")))
                Catch ex As Exception

                End Try

            End With

            m_bLoaded = True
        Else
            With pPropset
                ' Load defaults
                .SetProperty("direction", "up")
                .SetProperty("ordernum", Convert.ToInt32(999))
                .SetProperty("maximum", Convert.ToBoolean("True"))
                .SetProperty("connecttab", Convert.ToBoolean("False"))
                .SetProperty("barrierperm", Convert.ToBoolean("False"))
                .SetProperty("naturalyn", Convert.ToBoolean("False"))
                .SetProperty("dciyn", Convert.ToBoolean("False"))
                .SetProperty("dcisectionalyn", Convert.ToBoolean("False"))
                .SetProperty("sDCIModelDir", Convert.ToString("not set"))
                .SetProperty("sRInstallDir", Convert.ToString("not set"))
                .SetProperty("bDBF", Convert.ToBoolean("False"))
                .SetProperty("sGDB", Convert.ToString("not set"))
                .SetProperty("TabPrefix", Convert.ToString("not set"))

                .SetProperty("UpHab", Convert.ToBoolean("True"))
                .SetProperty("TotalUpHab", Convert.ToBoolean("True"))
                .SetProperty("DownHab", Convert.ToBoolean("False"))
                .SetProperty("TotalDownHab", Convert.ToBoolean("False"))
                .SetProperty("PathDownHab", Convert.ToBoolean("False"))
                .SetProperty("TotalPathDownHab", Convert.ToBoolean("False"))

                .SetProperty("numPolys", Convert.ToInt32(0))
                .SetProperty("numLines", Convert.ToInt32(0))
                .SetProperty("numExclusions", Convert.ToInt32(0))
                .SetProperty("numBarrierIDs", Convert.ToInt32(0))
                .SetProperty("barrierEIDsLoadedyn", Convert.ToBoolean("False"))
                .SetProperty("numBarrierEIDs", Convert.ToInt32(0))
                .SetProperty("flagEIDsLoadedyn", Convert.ToBoolean("False"))
                .SetProperty("numFlagEIDs", Convert.ToInt32(0))

                .SetProperty("bGLPKTables", Convert.ToBoolean("False"))
                .SetProperty("sGLPKModelDir", Convert.ToString("not set"))
                .SetProperty("sGnuWinDir", Convert.ToString("not set"))

            End With


            m_bLoaded = True
        End If

        'If streamCheck = "check" Then
        '    With pPropset
        '        .SetProperty("direction", Convert.ToString(Stream.Read()))
        '        .SetProperty("ordernum", Convert.ToInt32(Stream.Read()))
        '        .SetProperty("maximum", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("connecttab", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("barrierperm", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("naturalyn", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("dciyn", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("dcisectionalyn", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("sDCIModelDir", Convert.ToString(Stream.Read()))
        '        .SetProperty("sRInstallDir", Convert.ToString(Stream.Read()))
        '        .SetProperty("bDBF", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("sGDB", Convert.ToString(Stream.Read()))
        '        .SetProperty("TabPrefix", Convert.ToString(Stream.Read()))

        '        .SetProperty("UpHab", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("TotalUpHab", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("DownHab", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("TotalDownHab", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("PathDownHab", Convert.ToBoolean(Stream.Read()))
        '        .SetProperty("TotalPathDownHab", Convert.ToBoolean(Stream.Read()))

        '        .SetProperty("numPolys", Convert.ToInt32(Stream.Read()))

        '        ' Add each polygon and respective hab quan and qual fields as a property
        '        ' Add each habitat class and quantity field as property
        '        iPolysCount = Convert.ToInt32(pPropset.GetProperty("numPolys"))
        '        If iPolysCount > 0 Then
        '            For i = 0 To iPolysCount - 1
        '                .SetProperty("IncPoly" + i.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("PolyClassField" + i.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("PolyQuanField" + i.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("PolyUnitField" + i.ToString, Convert.ToString(Stream.Read()))
        '            Next
        '        End If

        '        .SetProperty("numLines", Convert.ToInt32(Stream.Read()))

        '        ' Add each line included as a property
        '        ' Add each habitat class and quantity field as property
        '        iLinesCount = Convert.ToInt32(pPropset.GetProperty("numLines"))
        '        If iLinesCount > 0 Then
        '            For j = 0 To iLinesCount - 1
        '                .SetProperty("IncLine" + j.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("LineClassField" + j.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("LineQuanField" + j.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("LineUnitField" + j.ToString, Convert.ToString(Stream.Read()))
        '            Next
        '        End If

        '        .SetProperty("numExclusions", Convert.ToInt32(Stream.Read()))

        '        ' Add each line included as a property
        '        ' Add each habitat class and quantity field as property
        '        iExclusions = Convert.ToInt32(pPropset.GetProperty("numExclusions"))
        '        If iExclusions > 0 Then
        '            For i = 0 To iExclusions - 1
        '                .SetProperty("ExcldLayer" + i.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("ExcldFeature" + i.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("ExcldValue" + i.ToString, Convert.ToString(Stream.Read()))
        '            Next
        '        End If

        '        .SetProperty("numBarrierIDs", Convert.ToInt32(Stream.Read()))

        '        ' Add each line included as a property
        '        ' Add each habitat class and quantity field as property
        '        iBarrierIDs = Convert.ToInt32(pPropset.GetProperty("numBarrierIDs"))
        '        If iBarrierIDs > 0 Then
        '            For i = 0 To iBarrierIDs - 1
        '                .SetProperty("BarrierIDLayer" + i.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("BarrierIDField" + i.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("BarrierPermField" + i.ToString, Convert.ToString(Stream.Read()))
        '                .SetProperty("BarrierNaturalYNField" + i.ToString, Convert.ToString(Stream.Read()))
        '            Next
        '        End If

        '    End With
        '    'End If
        '    bLoaded = True
        'End If
        ''MessageBox.Show("setting1: " + pPropset.GetProperty("setting1"))
        'Marshal.ReleaseComObject(Stream) 'this releases the data stream 
    End Sub
    ' this sub is run at the time the document is saved
    Protected Overloads Overrides Sub OnSave(ByVal outStrm As Stream)
        'As ESRI.ArcGIS.esriSystem.IVariantStream) Implements ESRI.ArcGIS.esriSystem.IPersistVariant.Save

        Dim iPolysCount As Integer = 0   ' number of polygon layers currently using
        Dim i As Integer = 0             ' loop counter
        Dim iLinesCount As Integer = 0   ' number of lines layers currently using
        Dim j As Integer = 0             ' loop counter
        Dim iExclusions As Integer = 0
        Dim iBarrierIDs As Integer = 0

        Dim sDictionary As New Dictionary(Of String, String)
        Dim iEID As Integer = 0
        Dim iBarrierEIDCount As Integer = 0
        Dim lBarrierEIDs As List(Of Integer) = New List(Of Integer)
        Dim iFlagEIDCount As Integer = 0
        Dim lFlagEIDs As List(Of Integer) = New List(Of Integer)

        ' =========  BEGIN GRAB OF BARRIERS IN CURRENT NETWORK =========
        ' this section sets the property set with barriers in current network. 

        ' THIS NEEDS CHECKING ON
        If Me.State = ExtensionState.Enabled Then

            Dim FiPEx__1 As FishPassageExtension = FishPassageExtension.GetExtension

            Dim pUtilityNetworkAnalysisExt As IUtilityNetworkAnalysisExt
            pUtilityNetworkAnalysisExt = FishPassageExtension.GetUNAExt

            Dim pGeometricNetwork As IGeometricNetwork

            ' Get the active network
            ' The network shouldn't be empty because the extension wouldn't be enabled otherwise
            Dim pNetworkAnalysisExt As INetworkAnalysisExt
            pNetworkAnalysisExt = CType(pUtilityNetworkAnalysisExt, INetworkAnalysisExt)

            ' If there is a network, and only one network then 
            ' save the barriers of the current network
            ' save the flags of the current network
            If pNetworkAnalysisExt.NetworkCount <> 0 Then

                pGeometricNetwork = pNetworkAnalysisExt.CurrentNetwork

                ' Get the network elements for EID retrieval
                Dim pNetwork As INetwork
                Dim pNetElements As INetElements
                pNetwork = pGeometricNetwork.Network
                pNetElements = CType(pNetwork, INetElements)

                'Dim pOriginalBarriersListGEN As IEnumNetEIDBuilderGEN
                'pOriginalBarriersListGEN = New EnumNetEIDArray
                Dim pNetworkAnalysisExtBarriers As INetworkAnalysisExtBarriers
                Dim pFlagDisplay As IFlagDisplay

                'pNetworkAnalysisExtFlags = CType(pUtilityNetworkAnalysisExt, INetworkAnalysisExtFlags)
                pNetworkAnalysisExtBarriers = CType(pUtilityNetworkAnalysisExt, INetworkAnalysisExtBarriers)

                '' coclass of geomtricnetwork
                'Dim pGeometricNetworkName As IGeometricNetworkName
                'pGeometricNetworkName = CType(pGeometricNetwork, IGeometricNetworkName)

                ' Get barriers from network (junction only)
                i = 0
                iBarrierEIDCount = pNetworkAnalysisExtBarriers.JunctionBarrierCount
                For i = 0 To pNetworkAnalysisExtBarriers.JunctionBarrierCount - 1
                    ' Use pFlagDisplay to retrieve EIDs of the barriers for later
                    pFlagDisplay = CType(pNetworkAnalysisExtBarriers.JunctionBarrier(i), IFlagDisplay)
                    iEID = pNetElements.GetEID(pFlagDisplay.FeatureClassID, pFlagDisplay.FID, pFlagDisplay.SubID, esriElementType.esriETJunction)
                    lBarrierEIDs.Add(iEID)
                    'pOriginalBarriersListGEN.Add(iEID)
                    'originalBarriersList(i) = bEID
                Next


                'Dim pOriginalflagsListGEN As IEnumNetEIDBuilderGEN
                'pOriginalflagsListGEN = New EnumNetEIDArray
                Dim pNetworkAnalysisExtflags As INetworkAnalysisExtFlags

                'pNetworkAnalysisExtFlags = CType(pUtilityNetworkAnalysisExt, INetworkAnalysisExtFlags)
                pNetworkAnalysisExtflags = CType(pUtilityNetworkAnalysisExt, INetworkAnalysisExtFlags)

                '' coclass of geomtricnetwork
                'Dim pGeometricNetworkName As IGeometricNetworkName
                'pGeometricNetworkName = CType(pGeometricNetwork, IGeometricNetworkName)

                ' Get flags from network (junction only)
                i = 0
                iFlagEIDCount = pNetworkAnalysisExtflags.JunctionFlagCount
                For i = 0 To pNetworkAnalysisExtflags.JunctionFlagCount - 1
                    ' Use pFlagDisplay to retrieve EIDs of the flags for later
                    pFlagDisplay = CType(pNetworkAnalysisExtflags.JunctionFlag(i), IFlagDisplay)
                    iEID = pNetElements.GetEID(pFlagDisplay.FeatureClassID, pFlagDisplay.FID, pFlagDisplay.SubID, esriElementType.esriETJunction)
                    lFlagEIDs.Add(iEID)
                    'pOriginalBarriersListGEN.Add(iEID)
                    'originalBarriersList(i) = bEID
                Next

            End If
        End If

        ' =========  END GRAB OF BARRIERS IN CURRENT NETWORK ===========

        ' Write to pPropset now for immediate retrieval
        ' seems redundant but for saving of barriers to document stream it's correct

        ' Save the barrier count and iEIDs if any
        With pPropset
            .SetProperty("numBarrierEIDs", Convert.ToInt32(iBarrierEIDCount))
            ' Add each EID to the propertyset if there are any
            If iBarrierEIDCount > 0 Then
                i = 0
                For i = 0 To lBarrierEIDs.Count - 1
                    .SetProperty("BarrierEID" + i.ToString, lBarrierEIDs(i))
                Next
            End If

            .SetProperty("numFlagEIDs", iFlagEIDCount)
            ' Add each EID to the propertyset if there are any
            If iFlagEIDCount > 0 Then
                i = 0
                For i = 0 To lFlagEIDs.Count - 1
                    .SetProperty("flagEID" + i.ToString, lFlagEIDs(i))
                Next
            End If

        End With

        ' ========== BEGIN ADD PROPERTIES TO DICTIONARY OBJECT =============
        'If there are any properties to write then save them to the stream
        If m_bLoaded = True Then

            ' load the properties into a data dictionary for serialization to the stream
            ' (there may be a better way to do this, but for add-ins the system.io.stream
            ' seems to limit us to a binary format for write/reads
            ' all of these are converted to string format to keep it simple
            ' some of them will be strings already but ohhh wellll

            sDictionary.Add("check", "check")
            sDictionary.Add("direction", Convert.ToString(pPropset.GetProperty("direction")))
            sDictionary.Add("ordernum", Convert.ToString(pPropset.GetProperty("ordernum")))
            sDictionary.Add("maximum", Convert.ToString(pPropset.GetProperty("maximum")))
            sDictionary.Add("connecttab", Convert.ToString(pPropset.GetProperty("connecttab")))
            sDictionary.Add("barrierperm", Convert.ToString(pPropset.GetProperty("barrierperm")))
            sDictionary.Add("naturalyn", Convert.ToString(pPropset.GetProperty("naturalyn")))
            sDictionary.Add("dciyn", Convert.ToString(pPropset.GetProperty("dciyn")))
            sDictionary.Add("dcisectionalyn", Convert.ToString(pPropset.GetProperty("dcisectionalyn")))
            sDictionary.Add("sDCIModelDir", Convert.ToString(pPropset.GetProperty("sDCIModelDir")))
            sDictionary.Add("sRInstallDir", Convert.ToString(pPropset.GetProperty("sRInstallDir")))
            sDictionary.Add("bDBF", Convert.ToString(pPropset.GetProperty("bDBF")))
            sDictionary.Add("sGDB", Convert.ToString(pPropset.GetProperty("sGDB")))
            sDictionary.Add("TabPrefix", Convert.ToString(pPropset.GetProperty("TabPrefix")))
            sDictionary.Add("UpHab", Convert.ToString(pPropset.GetProperty("UpHab")))
            sDictionary.Add("TotalUpHab", Convert.ToString(pPropset.GetProperty("TotalUpHab")))
            sDictionary.Add("DownHab", Convert.ToString(pPropset.GetProperty("DownHab")))
            sDictionary.Add("TotalDownHab", Convert.ToString(pPropset.GetProperty("TotalDownHab")))
            sDictionary.Add("PathDownHab", Convert.ToString(pPropset.GetProperty("PathDownHab")))
            sDictionary.Add("TotalPathDownHab", Convert.ToString(pPropset.GetProperty("TotalPathDownHab")))
            sDictionary.Add("numPolys", Convert.ToString(pPropset.GetProperty("numPolys")))

            iPolysCount = Convert.ToInt32(pPropset.GetProperty("numPolys"))
            If iPolysCount > 0 Then
                i = 0
                For i = 0 To iPolysCount - 1
                    sDictionary.Add("IncPoly" + i.ToString, Convert.ToString(pPropset.GetProperty("IncPoly" + i.ToString)))
                    sDictionary.Add("PolyClassField" + i.ToString, Convert.ToString(pPropset.GetProperty("PolyClassField" + i.ToString)))
                    sDictionary.Add("PolyQuanField" + i.ToString, Convert.ToString(pPropset.GetProperty("PolyQuanField" + i.ToString)))
                    sDictionary.Add("PolyUnitField" + i.ToString, Convert.ToString(pPropset.GetProperty("PolyUnitField" + i.ToString)))
                Next
            End If

            sDictionary.Add("numLines", Convert.ToString(pPropset.GetProperty("numLines")))

            iLinesCount = Convert.ToInt32(pPropset.GetProperty("numLines"))
            If iLinesCount > 0 Then
                j = 0
                For j = 0 To iLinesCount - 1
                    sDictionary.Add("IncLine" + j.ToString, Convert.ToString(pPropset.GetProperty("IncLine" + j.ToString)))
                    sDictionary.Add("LineClassField" + j.ToString, Convert.ToString(pPropset.GetProperty("LineClassField" + j.ToString)))
                    sDictionary.Add("LineQuanField" + j.ToString, Convert.ToString(pPropset.GetProperty("LineQuanField" + j.ToString)))
                    sDictionary.Add("LineUnitField" + j.ToString, Convert.ToString(pPropset.GetProperty("LineUnitField" + j.ToString)))
                Next
            End If

            sDictionary.Add("numExclusions", Convert.ToString(pPropset.GetProperty("numExclusions")))

            iExclusions = Convert.ToInt32(pPropset.GetProperty("numExclusions"))
            If iExclusions > 0 Then
                i = 0
                For i = 0 To iExclusions - 1

                    sDictionary.Add("ExcldLayer" + i.ToString, Convert.ToString(pPropset.GetProperty("ExcldLayer" + i.ToString)))
                    sDictionary.Add("ExcldFeature" + i.ToString, Convert.ToString(pPropset.GetProperty("ExcldFeature" + i.ToString)))
                    sDictionary.Add("ExcldValue" + i.ToString, Convert.ToString(pPropset.GetProperty("ExcldValue" + i.ToString)))
                Next
            End If

            sDictionary.Add("numBarrierIDs", Convert.ToString(pPropset.GetProperty("numBarrierIDs")))
            iBarrierIDs = Convert.ToInt32(pPropset.GetProperty("numBarrierIDs"))
            If iBarrierIDs > 0 Then
                i = 0
                For i = 0 To iBarrierIDs - 1

                    sDictionary.Add("BarrierIDLayer" + i.ToString, Convert.ToString(pPropset.GetProperty("BarrierIDLayer" + i.ToString)))
                    sDictionary.Add("BarrierIDField" + i.ToString, Convert.ToString(pPropset.GetProperty("BarrierIDField" + i.ToString)))
                    sDictionary.Add("BarrierPermField" + i.ToString, Convert.ToString(pPropset.GetProperty("BarrierPermField" + i.ToString)))
                    sDictionary.Add("BarrierNaturalYNField" + i.ToString, Convert.ToString(pPropset.GetProperty("BarrierNaturalYNField" + i.ToString)))
                Next
            End If

            sDictionary.Add("barrierEIDsLoadedyn", "false")
            sDictionary.Add("numBarrierEIDs", Convert.ToString(pPropset.GetProperty("numBarrierEIDs")))

            iBarrierEIDCount = Convert.ToInt32(pPropset.GetProperty("numBarrierEIDs"))

            If iBarrierEIDCount > 0 Then
                i = 0
                For i = 0 To iBarrierEIDCount - 1
                    sDictionary.Add("BarrierEID" + i.ToString, Convert.ToString(pPropset.GetProperty("BarrierEID" + i.ToString)))
                Next
            End If

            sDictionary.Add("flagEIDsLoadedyn", "false")
            sDictionary.Add("numFlagEIDs", Convert.ToString(pPropset.GetProperty("numFlagEIDs")))

            iFlagEIDCount = Convert.ToInt32(pPropset.GetProperty("numFlagEIDs"))

            If iFlagEIDCount > 0 Then
                i = 0
                For i = 0 To iFlagEIDCount - 1
                    sDictionary.Add("FlagEID" + i.ToString, Convert.ToString(pPropset.GetProperty("FlagEID" + i.ToString)))
                Next
            End If

            sDictionary.Add("bGLPKTables", Convert.ToString(pPropset.GetProperty("bGLPKTables")))
            sDictionary.Add("sGLPKModelDir", Convert.ToString(pPropset.GetProperty("sGLPKModelDir")))
            sDictionary.Add("sGnuWinDir", Convert.ToString(pPropset.GetProperty("sGnuWinDir")))


        Else ' if (for some weird reason) the extension hasn't been loaded
            '  (the bloaded var is set as false) then save defaults to stream

            sDictionary.Add("check", "check")
            sDictionary.Add("direction", "up")
            sDictionary.Add("ordernum", Convert.ToString(999))
            sDictionary.Add("maximum", Convert.ToString("True"))
            sDictionary.Add("connecttab", Convert.ToString(False))
            sDictionary.Add("barrierperm", Convert.ToString(False))
            sDictionary.Add("naturalyn", Convert.ToString(False))
            sDictionary.Add("dciyn", Convert.ToString(False))
            sDictionary.Add("dcisectionalyn", Convert.ToString(False))
            sDictionary.Add("sDCIModelDir", "not set")
            sDictionary.Add("sRInstallDir", "not set")
            sDictionary.Add("bDBF", Convert.ToString(False))
            sDictionary.Add("sGDB", "not set")
            sDictionary.Add("TabPrefix", "not set")
            sDictionary.Add("UpHab", Convert.ToString(True))
            sDictionary.Add("TotalUpHab", Convert.ToString(True))
            sDictionary.Add("DownHab", Convert.ToString(False))
            sDictionary.Add("TotalDownHab", Convert.ToString(False))
            sDictionary.Add("PathDownHab", Convert.ToString(False))
            sDictionary.Add("TotalPathDownHab", Convert.ToString(False))
            sDictionary.Add("numPolys", Convert.ToString(0))
            sDictionary.Add("numLines", Convert.ToString(0))
            sDictionary.Add("numExclusions", Convert.ToString(0))
            sDictionary.Add("numBarrierIDs", Convert.ToString(0))
            sDictionary.Add("barrierEIDsLoadedyn", "false")
            sDictionary.Add("numBarrierEIDs", Convert.ToString(0))
            sDictionary.Add("flagEIDsLoadedyn", "false")
            sDictionary.Add("numFlagEIDs", Convert.ToString(0))

            sDictionary.Add("bGLPKTables", Convert.ToString(False))
            sDictionary.Add("sGLPKModelDir", Convert.ToString("not set"))
            sDictionary.Add("sGnuWinDir", Convert.ToString("not set"))

        End If
        ' ========== END ADD PROPERTIES TO DICTIONARY OBJECT =============

        Dim bf = New System.Runtime.Serialization.Formatters.Binary.BinaryFormatter()
        bf.Serialize(outStrm, sDictionary)

        '' write the streamcheck option - shows that something has been saved to mxd
        'Stream.Write("check")

        ''write the property set values to the stream
        'Stream.Write(pPropset.GetProperty("direction"))
        'Stream.Write(pPropset.GetProperty("ordernum"))
        'Stream.Write(pPropset.GetProperty("maximum"))
        'Stream.Write(pPropset.GetProperty("connecttab"))
        'Stream.Write(pPropset.GetProperty("barrierperm"))
        'Stream.Write(pPropset.GetProperty("naturalyn"))
        'Stream.Write(pPropset.GetProperty("dciyn"))
        'Stream.Write(pPropset.GetProperty("dcisectionalyn"))
        'Stream.Write(pPropset.GetProperty("sDCIModelDir"))
        'Stream.Write(pPropset.GetProperty("sRInstallDir"))
        'Stream.Write(pPropset.GetProperty("bDBF"))
        'Stream.Write(pPropset.GetProperty("sGDB"))
        'Stream.Write(pPropset.GetProperty("TabPrefix"))

        'Stream.Write(pPropset.GetProperty("UpHab"))
        'Stream.Write(pPropset.GetProperty("TotalUpHab"))
        'Stream.Write(pPropset.GetProperty("DownHab"))
        'Stream.Write(pPropset.GetProperty("TotalDownHab"))
        'Stream.Write(pPropset.GetProperty("PathDownHab"))
        'Stream.Write(pPropset.GetProperty("TotalPathDownHab"))

        'Stream.Write(pPropset.GetProperty("numPolys"))

        '' Write the variable number of included polygons to stream
        '' Write the habitat class and quantity fields to stream
        'iPolysCount = Convert.ToInt32(pPropset.GetProperty("numPolys"))
        'If iPolysCount > 0 Then
        '    i = 0
        '    For i = 0 To iPolysCount - 1
        '        Stream.Write(pPropset.GetProperty("IncPoly" + i.ToString))
        '        Stream.Write(pPropset.GetProperty("PolyClassField" + i.ToString))
        '        Stream.Write(pPropset.GetProperty("PolyQuanField" + i.ToString))
        '        Stream.Write(pPropset.GetProperty("PolyUnitField" + i.ToString))
        '    Next
        'End If

        'Stream.Write(pPropset.GetProperty("numLines"))

        '' Write the variable number of included lines to stream
        '' Write the habitat class and quantity fields to stream
        'iLinesCount = Convert.ToInt32(pPropset.GetProperty("numLines"))
        'If iLinesCount > 0 Then
        '    For j = 0 To iLinesCount - 1
        '        Stream.Write(pPropset.GetProperty("IncLine" + j.ToString))
        '        Stream.Write(pPropset.GetProperty("LineClassField" + j.ToString))
        '        Stream.Write(pPropset.GetProperty("LineQuanField" + j.ToString))
        '        Stream.Write(pPropset.GetProperty("LineUnitField" + j.ToString))
        '    Next
        'End If

        'Stream.Write(pPropset.GetProperty("numExclusions"))

        'iExclusions = Convert.ToInt32(pPropset.GetProperty("numExclusions"))
        'If iExclusions > 0 Then
        '    For i = 0 To iExclusions - 1
        '        Stream.Write(pPropset.GetProperty("ExcldLayer" + i.ToString))
        '        Stream.Write(pPropset.GetProperty("ExcldFeature" + i.ToString))
        '        Stream.Write(pPropset.GetProperty("ExcldValue" + i.ToString))
        '    Next
        'End If

        'Stream.Write(pPropset.GetProperty("numBarrierIDs"))

        'iBarrierIDs = Convert.ToInt32(pPropset.GetProperty("numBarrierIDs"))
        'If iBarrierIDs > 0 Then
        '    For i = 0 To iBarrierIDs - 1
        '        Stream.Write(pPropset.GetProperty("BarrierIDLayer" + i.ToString))
        '        Stream.Write(pPropset.GetProperty("BarrierIDField" + i.ToString))
        '        Stream.Write(pPropset.GetProperty("BarrierPermField" + i.ToString))
        '        Stream.Write(pPropset.GetProperty("BarrierNaturalYNField" + i.ToString))
        '    Next
        'End If

        'Marshal.ReleaseComObject(Stream) 'this releases the data stream
        'End If
    End Sub


    Friend Function CheckNetworkCount() As Boolean

        'Dim FiPEx__1 As FishPassageExtension = FishPassageExtension.GetExtension

        Dim pNetworkAnalysisExt As INetworkAnalysisExt
        pNetworkAnalysisExt = CType(m_UNAextension, INetworkAnalysisExt)

        If pNetworkAnalysisExt.NetworkCount > 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    '#End Region

    Private Sub MapEvents_ContentsChanged()
        m_bHasNetworks = CheckNetworkCount()
    End Sub


    Friend Function HasNetwork() As Boolean
        Return m_bHasNetworks
    End Function

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class

'End Namespace


